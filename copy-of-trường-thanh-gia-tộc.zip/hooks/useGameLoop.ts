
import { useState, useCallback, useEffect } from 'react';
import { Clan, GameDate, Event, Location, LocationData, Force, BattleReport, GameState, Character, RankType } from '../types/index.ts';
import { processGameTick } from '../logic/gameTick.ts';
import { getPredefinedLocations, generateLocalLocationData } from '../logic/location.ts';
import { FIXED_FORCES } from '../constants.ts';
import { initializeNewClan } from '../logic/clanSetup.ts';
import { generateRandomForces } from '../logic/forces.ts';
import { useGameActions } from './useGameActions.ts';
import type { GameActions, ActionResult } from './useGameActions.ts';

// Re-export the type for external components like App.tsx and CharacterDetailModal.tsx
export type { GameActions };

type NewGameConfig = { ho: string; ten: string; boiPhan: string[]; founder: Character; };

export const useGameLoop = (initialState?: GameState, newGameConfig?: NewGameConfig) => {
    const [locations, setLocations] = useState<Location[]>(() => initialState?.locations || getPredefinedLocations());
    const [forces, setForces] = useState<Force[]>(() => initialState?.forces || []);
    const [locationDataCache, setLocationDataCache] = useState<Record<string, LocationData>>(() => initialState?.locationDataCache || {});
    const [clan, setClan] = useState<Clan | null>(() => initialState?.clan || null);
    const [gameDate, setGameDate] = useState<GameDate>(() => initialState?.gameDate || { year: 1, month: 1 });
    const [isRunning, setIsRunning] = useState(false);
    const [gameSpeed, setGameSpeed] = useState(1);
    const [events, setEvents] = useState<Event[]>(() => initialState?.events || []);
    const [battleReports, setBattleReports] = useState<BattleReport[]>(() => initialState?.battleReports || []);

    const addEvent = useCallback((eventData: Omit<Event, 'id'>) => {
        setEvents(prevEvents => [{ id: crypto.randomUUID(), ...eventData }, ...prevEvents].slice(0, 200));
    }, []);

    const addBattleReport = useCallback((reportData: BattleReport) => {
        setBattleReports(prev => [reportData, ...prev]);
    }, []);

    const executeAction = useCallback((action: (clan: Clan, ...args: any[]) => ActionResult, ...args: any[]) => {
        setClan(currentClan => {
            if (!currentClan) return null;
            const result = action(currentClan, ...args);
            if (result.error) {
                addEvent({ description: result.error, date: gameDate });
                return currentClan;
            }
            if (result.newEvents) {
                result.newEvents.forEach(e => addEvent({ ...e, date: gameDate }));
            }
            if (result.newBattleReport) {
                addBattleReport(result.newBattleReport);
            }
            return result.updatedClan || currentClan;
        });
    }, [addEvent, gameDate, addBattleReport]);
    
    const actions = useGameActions(executeAction, gameDate);

    useEffect(() => {
        // Only run initial setup if it's a new game (no initial state provided)
        if (!initialState) {
            const predefinedLocations = getPredefinedLocations();
            const initialPoints = [...predefinedLocations, ...FIXED_FORCES];
            const randomForces = generateRandomForces(5, initialPoints);

            setLocations(predefinedLocations);
            setForces([...FIXED_FORCES, ...randomForces]);

            const initialCache: Record<string, LocationData> = {};
            for (const loc of predefinedLocations) { initialCache[loc.id] = generateLocalLocationData(loc); }
            setLocationDataCache(initialCache);

            addEvent({description: 'Một thế giới mới đang chờ được khám phá. Hãy chọn Tổ Địa để bắt đầu hành trình của gia tộc.', date: { year: 1, month: 1 }});
        }
    }, [initialState, addEvent]);

    const gameLoop = useCallback(() => {
        setGameDate(currentDate => {
            const newDate = {
                month: currentDate.month === 12 ? 1 : currentDate.month + 1,
                year: currentDate.month === 12 ? currentDate.year + 1 : currentDate.year,
            };
            
            setClan(currentClan => {
                if (!currentClan) return null;
                const { nextClan, newEvents } = processGameTick(currentClan, newDate);
                if (newEvents.length > 0) {
                     setEvents(prevEvents => {
                        const allNewEvents = newEvents.map(e => ({ id: crypto.randomUUID(), ...e, date: newDate }));
                        return [...allNewEvents, ...prevEvents].slice(0, 200);
                    });
                }
                return nextClan;
            });
            
            // Filter battle reports older than 2 years
            const twoYearsAgo = { year: newDate.year - 2, month: newDate.month };
            setBattleReports(prev => prev.filter(report => 
                report.date.year > twoYearsAgo.year || 
                (report.date.year === twoYearsAgo.year && report.date.month >= twoYearsAgo.month)
            ));

            return newDate;
        });
    }, []);

    useEffect(() => {
        if (!isRunning) return;
        const intervalId = setInterval(gameLoop, 2000 / gameSpeed);
        return () => clearInterval(intervalId);
    }, [isRunning, gameSpeed, gameLoop]);

    const handleSelectLocation = useCallback(async (location: Location) => {
        if (location.isAncestral && !clan && newGameConfig) {
            const { ho, ten, boiPhan, founder } = newGameConfig;
            const clanName = `${ho} Gia`;
            
            const finalFounder = founder;
            finalFounder.name = `${ho} ${ten}`;
            finalFounder.isPatriarch = true;
            finalFounder.rank = RankType.TOC_TRUONG;
            finalFounder.loyalty = 100;
            
            const newClan = initializeNewClan(location, clanName, finalFounder, boiPhan);
            setClan(newClan);
            addEvent({description: `'${newClan.name}' đã được kiến lập tại ${location.name}, do Lão tộc trưởng ${newClan.members[0].name} dẫn dắt.`, date: gameDate, characterIds: [newClan.members[0].id]});
        }
    }, [clan, addEvent, gameDate, newGameConfig]);
    
    const handleTogglePlay = () => setIsRunning(!isRunning);
    const handleSetSpeed = (speed: number) => setGameSpeed(speed);
    
    const fullGameState: GameState = {
         locations, forces, locationDataCache, clan, gameDate, isRunning, gameSpeed, events, battleReports, handleSelectLocation, handleTogglePlay, handleSetSpeed
    };

    return {
        gameState: fullGameState,
        actions,
    };
};