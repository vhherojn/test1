
import { useCallback } from 'react';
import type { Clan, Event, GameDate, Character, RankType, MeritShopItem, WelcomePackageItem, PromotionRule, Formation, ItemQuality, BattleReport } from '../types/index.ts';

// Import all action functions
import * as buildingActions from '../logic/actions/buildingActions.ts';
import * as clanActions from '../logic/actions/clanActions.ts';
import * as itemActions from '../logic/actions/itemActions.ts';
import * as taskActions from '../logic/actions/taskActions.ts';
import * as techniqueActions from '../logic/actions/techniqueActions.ts';
import * as equipmentActions from '../logic/actions/equipmentActions.ts';
import * as meritShopActions from '../logic/actions/meritShopActions.ts';
import * as recruitmentActions from '../logic/actions/recruitmentActions.ts';
import * as combatActions from '../logic/actions/combatActions.ts';

export interface ActionResult { 
  updatedClan?: Clan; 
  newEvents?: Omit<Event, 'id'|'date'>[]; 
  newBattleReport?: BattleReport;
  error?: string; 
};

export interface GameActions {
    upgradeLinhMach: () => void;
    upgradeBuilding: (buildingId: string) => void;
    assignToBuilding: (buildingId: string, characterId: string | null, slotType: 'worker' | 'apprentice', tier: ItemQuality, slotIndex: number, apprenticeSlotIndex?: 0 | 1) => void;
    assignToHuntingParty: (characterId: string | null, tier: ItemQuality, slotIndex: number) => void;
    startCrafting: (buildingId: string, stationIndex: number, recipeId: string) => void;
    setBuildingRecipe: (buildingId: string, recipeId: string | null) => void;
    sparring: (char1Id: string, char2Id: string) => void;
    lifeAndDeathBattle: (char1Id: string, char2Id: string) => void;
    assignTask: (characterIds: string[], taskId: string) => void;
    setCharacterRank: (characterId: string, rank: RankType) => void;
    setRankStipend: (rank: RankType, itemId: string, amount: number) => void;
    storeTechnique: (techniqueId: string) => void;
    patriarchLearnTechnique: (techniqueId: string) => void;
    equipItem: (characterId: string, itemId: string) => void;
    unequipItem: (characterId: string, equipmentSlot: keyof Character['equipment'] | string) => void;
    useItem: (characterId: string, itemId: string) => void;
    storeToMeritShop: (itemId: string, count: number, cost: number) => void;
    buyFromMeritShop: (characterId: string, meritShopItem: MeritShopItem) => void;
    storeItemToClan: (characterId: string, itemId: string) => void;
    unequipTechnique: (characterId: string, techniqueId: string) => void;
    discoverRecruits: () => void;
    confirmRecruitment: (recruitId: string) => void;
    awardLibraryToken: (characterId: string) => void;
    setMandatoryQuestFrequency: (rank: RankType, frequency: number) => void;
    startElection: () => void;
    castVote: (voterId: string, candidateId: string) => void;
    endElection: () => void;
    assignToLinhMach: (characterId: string | null, role: "miner" | "supervisor", slotIndex?: number | undefined) => void;
    equipTechnique: (characterId: string, techniqueId: string, slotType: "mainCultivation" | "subCultivation" | "secretArts" | "spells", slotIndex: number) => void;
    setWelcomePackage: (items: WelcomePackageItem[]) => void;
    addPromotionRule: (rule: Omit<PromotionRule, 'id'>) => void;
    removePromotionRule: (ruleId: string) => void;
    arrangeMarriage: (char1Id: string, char2Id: string) => void;
    deployFormation: (formationId: string) => void;
    undeployFormation: () => void;
    awardToCharacter: (characterId: string, contribution: number, itemId?: string, count?: number) => void;
}

type ExecuteActionFunc = (action: (clan: Clan, ...args: any[]) => ActionResult, ...args: any[]) => void;

export const useGameActions = (executeAction: ExecuteActionFunc, gameDate: GameDate): GameActions => {
    return {
        upgradeLinhMach: useCallback(() => executeAction(clanActions.upgradeLinhMach), [executeAction]),
        upgradeBuilding: useCallback((buildingId: string) => executeAction(buildingActions.upgradeBuilding, buildingId), [executeAction]),
        assignToBuilding: useCallback((buildingId: string, characterId: string | null, slotType: 'worker' | 'apprentice', tier: ItemQuality, slotIndex: number, apprenticeSlotIndex?: 0 | 1) => {
             executeAction(buildingActions.assignToCraftingStation, buildingId, slotIndex, slotType, characterId, apprenticeSlotIndex);
        }, [executeAction]),
        assignToHuntingParty: useCallback((characterId: string | null, tier: ItemQuality, slotIndex: number) => executeAction(buildingActions.assignToHuntingParty, characterId, tier, slotIndex), [executeAction]),
        startCrafting: useCallback((buildingId: string, stationIndex: number, recipeId: string) => executeAction(buildingActions.startCrafting, buildingId, stationIndex, recipeId), [executeAction]),
        setBuildingRecipe: useCallback((buildingId: string, recipeId: string | null) => {
             if (buildingId === 'herb_garden') {
                executeAction(buildingActions.setGardenPlanting, buildingId, recipeId);
            }
        }, [executeAction]),
        assignTask: useCallback((characterIds: string[], taskId: string) => executeAction(taskActions.assignTask, characterIds, taskId, gameDate), [executeAction, gameDate]),
        setCharacterRank: useCallback((characterId: string, rank: RankType) => executeAction(clanActions.setCharacterRank, characterId, rank), [executeAction]),
        setRankStipend: useCallback((rank: RankType, itemId: string, amount: number) => executeAction(clanActions.setRankStipend, rank, itemId, amount), [executeAction]),
        storeTechnique: useCallback((techniqueId: string) => executeAction(techniqueActions.storeTechnique, techniqueId), [executeAction]),
        patriarchLearnTechnique: useCallback((techniqueId: string) => executeAction(techniqueActions.patriarchLearnTechnique, techniqueId), [executeAction]),
        equipItem: useCallback((characterId: string, itemId: string) => executeAction(equipmentActions.equipItem, characterId, itemId), [executeAction]),
        unequipItem: useCallback((characterId: string, equipmentSlot: keyof Character['equipment'] | string) => executeAction(equipmentActions.unequipItem, characterId, equipmentSlot), [executeAction]),
        useItem: useCallback((characterId: string, itemId: string) => executeAction(itemActions.useItem, characterId, itemId), [executeAction]),
        storeToMeritShop: useCallback((itemId: string, count: number, cost: number) => executeAction(meritShopActions.storeToMeritShop, itemId, count, cost), [executeAction]),
        buyFromMeritShop: useCallback((characterId: string, meritShopItem: MeritShopItem) => executeAction(meritShopActions.buyFromMeritShop, characterId, meritShopItem), [executeAction]),
        storeItemToClan: useCallback((characterId: string, itemId: string) => executeAction(itemActions.storeItemToClan, characterId, itemId), [executeAction]),
        unequipTechnique: useCallback((characterId: string, techniqueId: string) => executeAction(techniqueActions.unequipTechnique, characterId, techniqueId), [executeAction]),
        discoverRecruits: useCallback(() => executeAction(recruitmentActions.discoverNewTalent), [executeAction]),
        confirmRecruitment: useCallback((recruitId: string) => executeAction(recruitmentActions.recruitNewMember, recruitId), [executeAction]),
        awardLibraryToken: useCallback((characterId: string) => executeAction(clanActions.awardLibraryToken, characterId, 'library_token_1'), [executeAction]),
        setMandatoryQuestFrequency: useCallback((rank: RankType, frequency: number) => executeAction(clanActions.setMandatoryQuestFrequency, rank, frequency), [executeAction]),
        sparring: useCallback((char1Id: string, char2Id: string) => executeAction(combatActions.spar, char1Id, char2Id, gameDate), [executeAction, gameDate]),
        lifeAndDeathBattle: useCallback((char1Id: string, char2Id: string) => executeAction(combatActions.lifeAndDeathBattle, char1Id, char2Id, gameDate), [executeAction, gameDate]),
        assignToLinhMach: useCallback((characterId: string | null, role: 'miner' | 'supervisor', slotIndex?: number) => executeAction(clanActions.assignToLinhMach, characterId, role, slotIndex), [executeAction]),
        equipTechnique: useCallback((characterId: string, techniqueId: string, slotType: 'mainCultivation' | 'subCultivation' | 'secretArts' | 'spells', slotIndex: number) => executeAction(techniqueActions.equipTechnique, characterId, techniqueId, slotType, slotIndex), [executeAction]),
        startElection: useCallback(() => executeAction(clanActions.startElection), [executeAction]),
        castVote: useCallback((voterId: string, candidateId: string) => executeAction(clanActions.castVote, voterId, candidateId), [executeAction]),
        endElection: useCallback(() => executeAction(clanActions.endElection), [executeAction]),
        setWelcomePackage: useCallback((items: WelcomePackageItem[]) => executeAction(clanActions.setWelcomePackage, items), [executeAction]),
        addPromotionRule: useCallback((rule: Omit<PromotionRule, 'id'>) => executeAction(clanActions.addPromotionRule, rule), [executeAction]),
        removePromotionRule: useCallback((ruleId: string) => executeAction(clanActions.removePromotionRule, ruleId), [executeAction]),
        arrangeMarriage: useCallback((char1Id: string, char2Id: string) => executeAction(clanActions.arrangeMarriage, char1Id, char2Id), [executeAction]),
        deployFormation: useCallback((formationId: string) => executeAction(clanActions.deployFormation, formationId), [executeAction]),
        undeployFormation: useCallback(() => executeAction(clanActions.undeployFormation), [executeAction]),
        awardToCharacter: useCallback((characterId: string, contribution: number, itemId?: string, count?: number) => executeAction(clanActions.awardToCharacter, characterId, contribution, itemId, count), [executeAction]),
    };
}
