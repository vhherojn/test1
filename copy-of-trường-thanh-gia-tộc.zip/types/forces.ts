
import { ForceRank } from './enums.ts';

export interface Force {
  id: string;
  name: string;
  description: string;
  type: 'fixed' | 'random';
  x: number;
  y: number;
  icon: 'righteous' | 'evil';
  rank: ForceRank;
}