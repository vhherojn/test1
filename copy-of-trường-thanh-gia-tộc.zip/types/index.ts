


export * from './enums.ts';
export * from './world.ts';
export * from './items.ts';
export * from './needs.ts';
export * from './character.ts';
export * from './clan.ts';
export * from './activity.ts';
export * from './forces.ts';
export * from './battle.ts';

import type { Clan, GameDate, Event, Location, LocationData, Force, BattleReport } from './index.ts';

// Represents the full savable state of the game
export interface GameState {
    locations: Location[];
    forces: Force[];
    locationDataCache: Record<string, LocationData>;
    clan: Clan | null;
    gameDate: GameDate;
    isRunning: boolean;
    gameSpeed: number;
    events: Event[];
    battleReports: BattleReport[];
    handleSelectLocation: (location: Location) => void;
    handleTogglePlay: () => void;
    handleSetSpeed: (speed: number) => void;
}
