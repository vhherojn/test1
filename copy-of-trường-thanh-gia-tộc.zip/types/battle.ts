
import type { GameDate } from './world.ts';

export type BattleActionType = 'attack' | 'spell' | 'dodge' | 'escape' | 'start' | 'end';

export interface BattleTurn {
    turnNumber: number;
    description: string;
}

export interface BattleReport {
    id: string;
    date: GameDate;
    type: 'sparring' | 'life_and_death';
    participants: { id: string; name: string }[];
    winnerId: string | null;
    log: BattleTurn[];
}
