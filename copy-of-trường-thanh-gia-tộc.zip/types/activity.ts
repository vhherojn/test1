export enum CharacterActivity {
    IDLE = 'Rảnh rỗi',
    CULTIVATING = 'Tu Luyện',
    WORKING = 'Làm Việc',
    SECLUDED = 'Bế Quan',
    TRIBULATION = 'Độ Kiếp',
}