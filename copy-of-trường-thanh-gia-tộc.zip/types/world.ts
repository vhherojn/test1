
export interface Location { id: string; name: string; x: number; y: number; isAncestral?: boolean; prefab?: 'palace' | 'mountains' | 'city' | 'forest' | 'ruins'; }
export interface LocationData { name:string; type: string; description: string; linh_khi: string; tai_nguyen: string[]; gia_toc_anh_huong: string[]; }
export interface GameDate { year: number; month: number; }
export interface Event { id: string; date: GameDate; description: string; characterIds?: string[]; }
