
import type { Force } from './types/index.ts';
import { ForceRank } from './types/index.ts';

/**
 * Thế Lực Cố Định: Các thế lực có sẵn, sẽ xuất hiện ở vị trí cố định.
 */
export const FIXED_FORCES: Force[] = [
    { 
        id: 'force_fixed_1', 
        name: 'Chính Khí Minh', 
        description: 'Một liên minh các gia tộc chính đạo, mục tiêu là diệt trừ ma đạo, bảo vệ nhân gian.', 
        type: 'fixed',
        x: 22,
        y: 35,
        icon: 'righteous',
        rank: ForceRank.TAM_GIAI,
    },
    { 
        id: 'force_fixed_2', 
        name: 'Thiên Sát Lâu', 
        description: 'Tổ chức sát thủ thần bí, chỉ cần trả đủ giá, bất cứ ai cũng có thể giết.', 
        type: 'fixed',
        x: 88,
        y: 18,
        icon: 'evil',
        rank: ForceRank.NHI_GIAI,
    },
];

/**
 * Dữ liệu để tạo Thế Lực Ngẫu Nhiên
 */
export const RANDOM_FORCE_DATA = {
    PREFIXES: ["Hắc Phong", "Thiên Ưng", "Huyết Sát", "Linh Hư", "Phi Vân", "Thiên Cơ", "Vô Tình", "U Minh", "Bích Huyết", "Cuồng Phong"],
    SUFFIXES: ["Môn", "Bảo", "Lâu", "Đoàn", "Hội", "Cốc", "Cung", "Tông", "Phủ", "Các"],
    DESCRIPTIONS: [
        "Một thế lực mới nổi, hành sự bí ẩn, không rõ lai lịch.",
        "Môn phái tà đạo chuyên luyện công pháp âm độc, người trong giang hồ nghe tên đã sợ mất mật.",
        "Gia tộc ẩn thế lâu đời, đột nhiên xuất hiện, thực lực không thể coi thường.",
        "Một thương hội lớn, nắm giữ nhiều tài nguyên và thông tin tình báo quan trọng.",
        "Thế lực trung lập, không tham gia vào tranh đấu, chỉ tập trung phát triển.",
    ]
};
