import { CultivationStage, CombatStats, Character, Clan, Event, CharacterStatus, CharacterActivity } from '../../../types/index.ts';
import type { ICanhGioiState, BreakthroughResult } from '../ICanhGioiState.ts';
import { deepClone } from '../../utils/clone.ts';
import { recalculateAllStats } from '../../character.ts';

export class KetDanState implements ICanhGioiState {
    stage: CultivationStage = CultivationStage.CORE_FORMATION;
    levels: number = 10;
    progressPerLevel: number = 8000;
    upkeep: number = 100;
    baseHealth: number = 50000;
    baseMana: number = 35000;
    baseNguyenKhi: number = 800;
    baseSpeed: number = 30;
    baseMaxAge: number = 600;
    combatStatModifiers: Omit<CombatStats, 'critChance' | 'critDamage'> = { 
        physicalAttack: 8000,
        magicalAttack: 7000,
        physicalDefense: 6000,
        magicalDefense: 5000
    };

    getExpForLevel(level: number): number {
        if (level < 1) return this.progressPerLevel;
        // Increase by 20% for each level after the first one.
        return Math.floor(this.progressPerLevel * Math.pow(1.2, level - 1));
    }

    getBreakthroughSuccessChance(character: Character, clan: Clan): number {
        if (character.cultivationLevel < this.levels) return 1;
        
        let baseChance = Math.min(0.9, (character.daoTam + character.khiVan) / 250); // Tâm Ma Kiếp (Inner Demon Trial)
    
        const impurityPenalty = (character.bodyImpurity || 0) / 600; // 120 impurity = 20% reduction
        baseChance -= impurityPenalty;
        
        return Math.max(0.1, baseChance);
    }

    handleBreakthrough(character: Character, clan: Clan): BreakthroughResult {
        if (character.cultivationLevel < this.levels) {
            return { success: true, newEvents: [], clan };
        }
        
        const newClan = deepClone(clan);
        const memberToUpdate = newClan.members.find(m => m.id === character.id)!;
        
        const attempts = memberToUpdate.breakthroughAttempts?.[this.stage] || 0;
        const isFinalAttempt = memberToUpdate.maxAge - memberToUpdate.age <= 1;
        if (attempts >= 3 && !isFinalAttempt) {
            memberToUpdate.isMeditatingForBreakthrough = false;
            return { success: false, newEvents: [{ description: `Đã dùng hết 3 cơ hội đột phá Nguyên Anh, ${character.name} không thể tiếp tục.`, characterIds: [character.id] }], clan: newClan };
        }
        if (attempts >= 4) {
            memberToUpdate.isMeditatingForBreakthrough = false;
            return { success: false, newEvents: [{ description: `Đã hết tất cả cơ hội, ${character.name} Nguyên Anh vô vọng.`, characterIds: [character.id] }], clan: newClan };
        }

        if (character.nguyenKhi < character.maxNguyenKhi) {
            return { success: false, newEvents: [{ description: `Nguyên khí của ${character.name} chưa viên mãn, không thể đột phá Nguyên Anh.`, characterIds: [character.id] }], clan };
        }
        
        // --- START TRIBULATION PROCESS ---
        memberToUpdate.breakthroughAttempts = memberToUpdate.breakthroughAttempts || {};
        memberToUpdate.breakthroughAttempts[this.stage] = (memberToUpdate.breakthroughAttempts[this.stage] || 0) + 1;
        
        memberToUpdate.isMeditatingForBreakthrough = false; // No longer meditating, now facing tribulation
        memberToUpdate.tribulationState = { turnsRemaining: 3 };
        memberToUpdate.activity = CharacterActivity.TRIBULATION;

        const newEvents: Omit<Event, 'id' | 'date'>[] = [{
            description: `Thiên địa biến sắc, mây đen kéo đến! ${character.name} cảm ứng được thiên kiếp, chuẩn bị đối mặt với Lôi Kiếp để phá đan thành anh!`,
            characterIds: [character.id]
        }];
        
        // Return a non-conclusive success, the actual breakthrough happens in characterTick
        return { success: false, newEvents, clan: newClan };
    }
}