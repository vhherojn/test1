
import { CultivationStage, CombatStats, Character, Clan, Event } from '../../../types/index.ts';
import type { ICanhGioiState, BreakthroughResult } from '../ICanhGioiState.ts';
import { deepClone } from '../../utils/clone.ts';
import { recalculateAllStats } from '../../character.ts';

// Tỉ lệ đột phá Trúc Cơ cơ bản, do Thiên Đạo quy định.
const TRUC_CO_BASE_SUCCESS_CHANCE = 0.4; // 4 Thành (40%)

export class LuyenKhiState implements ICanhGioiState {
    stage: CultivationStage = CultivationStage.QI_REFINEMENT;
    levels: number = 13;
    progressPerLevel: number = 100;
    upkeep: number = 5;
    baseHealth: number = 100;
    baseMana: number = 50;
    baseNguyenKhi: number = 10;
    baseSpeed: number = 10;
    baseMaxAge: number = 150;
    combatStatModifiers: Omit<CombatStats, 'critChance' | 'critDamage'> = { 
        physicalAttack: 10, 
        magicalAttack: 5, 
        physicalDefense: 8, 
        magicalDefense: 4 
    };

    getExpForLevel(level: number): number {
        if (level < 1) return this.progressPerLevel;
        // Increase by 20% for each level after the first one.
        return Math.floor(this.progressPerLevel * Math.pow(1.2, level - 1));
    }

    getBreakthroughSuccessChance(character: Character, clan: Clan): number {
        if (character.cultivationLevel < this.levels) return 1;
        
        const hasPill = (character.inventory['truc_co_dan'] || 0) > 0;
        let baseChance = TRUC_CO_BASE_SUCCESS_CHANCE;
        if (hasPill) baseChance += 0.3; // +3 thành, tổng 7 thành
        
        const impurityPenalty = (character.bodyImpurity || 0) / 400; // 100 impurity = 25% reduction
        baseChance -= impurityPenalty;
        
        // Age penalty
        if (character.age > 65) {
            baseChance *= 0.1; // Reduce chance by 90%
        }
    
        return Math.max(0.01, baseChance); // Don't let it go below 1%
    }

    handleBreakthrough(character: Character, clan: Clan): BreakthroughResult {
        if (character.cultivationLevel < this.levels) {
            return { success: true, newEvents: [], clan };
        }
        
        const newClan = deepClone(clan);
        const memberToUpdate = newClan.members.find(m => m.id === character.id)!;

        // Check breakthrough attempts
        const attempts = memberToUpdate.breakthroughAttempts?.[this.stage] || 0;
        const isFinalAttempt = memberToUpdate.maxAge - memberToUpdate.age <= 1;
        if (attempts >= 3 && !isFinalAttempt) {
             memberToUpdate.isMeditatingForBreakthrough = false;
             return { 
                success: false, 
                newEvents: [{
                    description: `Đã dùng hết 3 cơ hội đột phá, ${character.name} không thể tiếp tục, chỉ có thể chờ đợi cơ duyên cuối cùng khi thọ nguyên sắp cạn.`,
                    characterIds: [character.id]
                }],
                clan: newClan,
            };
        }
        if (attempts >= 4) {
             memberToUpdate.isMeditatingForBreakthrough = false;
             return { 
                success: false, 
                newEvents: [{
                    description: `Đã hết tất cả cơ hội, ${character.name} Trúc Cơ vô vọng.`,
                    characterIds: [character.id]
                }],
                clan: newClan,
            };
        }

        if (character.nguyenKhi < character.maxNguyenKhi) {
            return { 
                success: false, 
                newEvents: [{
                    description: `Nguyên khí của ${character.name} chưa viên mãn, không thể đột phá Trúc Cơ.`,
                    characterIds: [character.id]
                }],
                clan,
            };
        }
        
        const hasPill = (memberToUpdate.inventory['truc_co_dan'] || 0) > 0;
        
        // Consume pill on attempt
        if (hasPill) {
            memberToUpdate.inventory['truc_co_dan'] -= 1;
            if (memberToUpdate.inventory['truc_co_dan'] <= 0) {
                delete memberToUpdate.inventory['truc_co_dan'];
            }
        }

        // Increment attempt count BEFORE the roll
        memberToUpdate.breakthroughAttempts = memberToUpdate.breakthroughAttempts || {};
        const newAttemptsCount = (memberToUpdate.breakthroughAttempts[this.stage] || 0) + 1;
        memberToUpdate.breakthroughAttempts[this.stage] = newAttemptsCount;
        
        const successChance = this.getBreakthroughSuccessChance(character, clan);
        const isSuccess = Math.random() < successChance;
        
        memberToUpdate.nguyenKhi = 0; // Reset Nguyên Khí on attempt
        memberToUpdate.isMeditatingForBreakthrough = false; // Reset state regardless of outcome

        if (isSuccess) {
            memberToUpdate.cultivationProgress = 0;
            memberToUpdate.cultivationStage = CultivationStage.FOUNDATION_ESTABLISHMENT;
            memberToUpdate.cultivationLevel = 1;
            memberToUpdate.thanThuc = 10; // Khởi tạo Thần Thức
            
            let eventDesc = '';
            if (hasPill) {
                eventDesc = `${character.name} đã sử dụng Trúc Cơ Đan, thành công đột phá bình cảnh, tiến vào Trúc Cơ Kỳ!`;
            } else {
                // Natural breakthrough bonus
                memberToUpdate.statModifiers = { ...(memberToUpdate.statModifiers || {}), baseMultiplier: 1.4 };
                eventDesc = `Thiên địa chúc phúc! ${character.name} đã dựa vào căn cơ của bản thân để Trúc Cơ thành công, căn cơ trở nên vô cùng vững chắc!`;
            }

            const finalMemberState = recalculateAllStats(memberToUpdate);
            Object.assign(memberToUpdate, finalMemberState);
            memberToUpdate.health = memberToUpdate.maxHealth;
            memberToUpdate.mana = memberToUpdate.maxMana;
            
            return { 
                success: true, 
                newEvents: [{ description: eventDesc, characterIds: [character.id] }],
                clan: newClan,
            };
        } else {
            // Handle failure
            memberToUpdate.injuryTurnsRemaining = 6;
            const eventDesc = `${character.name} ý đồ đột phá Trúc Cơ Kỳ nhưng thất bại (lần ${newAttemptsCount}). Nguyên khí đại thương, rơi vào trạng thái Trọng Thương, cần 6 tháng để hồi phục.`;
            
            return { 
                success: false, 
                newEvents: [{ description: eventDesc, characterIds: [character.id] }],
                clan: newClan,
            };
        }
    }
}
