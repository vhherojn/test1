import { CultivationStage, CombatStats, Character, Clan, Event } from '../../../types/index.ts';
import type { ICanhGioiState, BreakthroughResult } from '../ICanhGioiState.ts';
import { deepClone } from '../../utils/clone.ts';
import { recalculateAllStats } from '../../character.ts';

export class TrucCoState implements ICanhGioiState {
    stage: CultivationStage = CultivationStage.FOUNDATION_ESTABLISHMENT;
    levels: number = 10;
    progressPerLevel: number = 800;
    upkeep: number = 20;
    baseHealth: number = 4000;
    baseMana: number = 2000;
    baseNguyenKhi: number = 100;
    baseSpeed: number = 20;
    baseMaxAge: number = 250;
    combatStatModifiers: Omit<CombatStats, 'critChance' | 'critDamage'> = { 
        physicalAttack: 400,
        magicalAttack: 350,
        physicalDefense: 300,
        magicalDefense: 250
    };

    getExpForLevel(level: number): number {
        if (level < 1) return this.progressPerLevel;
        // Increase by 20% for each level after the first one.
        return Math.floor(this.progressPerLevel * Math.pow(1.2, level - 1));
    }

    getBreakthroughSuccessChance(character: Character, clan: Clan): number {
        if (character.cultivationLevel < this.levels) return 1;
        
        let baseChance = Math.min(0.95, 0.5 + (character.daoTam / 250)); // Base chance is 50%, increased by Dao Tam
    
        const impurityPenalty = (character.bodyImpurity || 0) / 500; // 100 impurity = 20% reduction
        baseChance -= impurityPenalty;
        
        return Math.max(0.1, baseChance); // Don't let it go below 10%
    }

    handleBreakthrough(character: Character, clan: Clan): BreakthroughResult {
        if (character.cultivationLevel < this.levels) {
            return { success: true, newEvents: [], clan };
        }
        
        const newClan = deepClone(clan);
        const memberToUpdate = newClan.members.find(m => m.id === character.id)!;

        // Check breakthrough attempts
        const attempts = memberToUpdate.breakthroughAttempts?.[this.stage] || 0;
        const isFinalAttempt = memberToUpdate.maxAge - memberToUpdate.age <= 1;
        if (attempts >= 3 && !isFinalAttempt) {
            memberToUpdate.isMeditatingForBreakthrough = false;
            return { 
                success: false, 
                newEvents: [{
                    description: `Đã dùng hết 3 cơ hội đột phá Kết Đan, ${character.name} không thể tiếp tục.`,
                    characterIds: [character.id]
                }],
                clan: newClan,
            };
        }
         if (attempts >= 4) {
             memberToUpdate.isMeditatingForBreakthrough = false;
             return { 
                success: false, 
                newEvents: [{
                    description: `Đã hết tất cả cơ hội, ${character.name} Kết Đan vô vọng.`,
                    characterIds: [character.id]
                }],
                clan: newClan,
            };
        }

        if (character.nguyenKhi < character.maxNguyenKhi) {
             return { 
                success: false, 
                newEvents: [{
                    description: `Nguyên khí của ${character.name} chưa viên mãn, không thể đột phá Kết Đan.`,
                    characterIds: [character.id]
                }],
                clan,
            };
        }

        // Increment attempt count BEFORE the roll
        memberToUpdate.breakthroughAttempts = memberToUpdate.breakthroughAttempts || {};
        const newAttemptsCount = (memberToUpdate.breakthroughAttempts[this.stage] || 0) + 1;
        memberToUpdate.breakthroughAttempts[this.stage] = newAttemptsCount;

        const successChance = this.getBreakthroughSuccessChance(character, clan);
        const isSuccess = Math.random() < successChance;
        memberToUpdate.nguyenKhi = 0; // Reset Nguyên Khí on attempt
        memberToUpdate.isMeditatingForBreakthrough = false; // Reset state

        if (isSuccess) {
            memberToUpdate.cultivationProgress = 0;
            memberToUpdate.cultivationStage = CultivationStage.CORE_FORMATION;
            memberToUpdate.cultivationLevel = 1;

            const finalMemberState = recalculateAllStats(memberToUpdate);
            Object.assign(memberToUpdate, finalMemberState);
            memberToUpdate.health = memberToUpdate.maxHealth;
            memberToUpdate.mana = memberToUpdate.maxMana;

            return {
                success: true,
                newEvents: [{
                    description: `${character.name} bế quan thành công, linh lực hoá lỏng, chính thức ngưng tụ Kim Đan, bước vào Kết Đan Kỳ!`,
                    characterIds: [character.id]
                }],
                clan: newClan
            };
        } else {
            memberToUpdate.injuryTurnsRemaining = 9;
            const eventDesc = `Dù đã cố gắng, ${character.name} vẫn không thể ngưng tụ Kim Đan, đột phá thất bại (lần ${newAttemptsCount}). Thân thể bị phản phệ, rơi vào trạng thái Trọng Thương, cần 9 tháng để hồi phục.`;
             return {
                success: false,
                newEvents: [{
                    description: eventDesc,
                    characterIds: [character.id]
                }],
                clan: newClan
            };
        }
    }
}