import { CultivationStage, CombatStats, Character, Clan, Event, CharacterStatus } from '../../../types/index.ts';
import type { ICanhGioiState, BreakthroughResult } from '../ICanhGioiState.ts';
import { deepClone } from '../../utils/clone.ts';
import { recalculateAllStats } from '../../character.ts';

export class NguyenAnhState implements ICanhGioiState {
    stage: CultivationStage = CultivationStage.NASCENT_SOUL;
    levels: number = 10;
    progressPerLevel: number = 40000;
    upkeep: number = 500;
    baseHealth: number = 250000;
    baseMana: number = 180000;
    baseNguyenKhi: number = 4000;
    baseSpeed: number = 45;
    baseMaxAge: number = 1200;
    combatStatModifiers: Omit<CombatStats, 'critChance' | 'critDamage'> = { 
        physicalAttack: 30000,
        magicalAttack: 28000,
        physicalDefense: 20000,
        magicalDefense: 18000
    };

    getExpForLevel(level: number): number {
        if (level < 1) return this.progressPerLevel;
        // Increase by 20% for each level after the first one.
        return Math.floor(this.progressPerLevel * Math.pow(1.2, level - 1));
    }

    getBreakthroughSuccessChance(character: Character, clan: Clan): number {
        if (character.cultivationLevel < this.levels) return 1;
        
        let baseChance = (character.comprehension + character.khiVan) > 185 ? 0.05 : 0.005; // "Pháp tắc thiên địa không hoàn chỉnh" logic
    
        const impurityPenalty = (character.bodyImpurity || 0) / 800;
        baseChance -= impurityPenalty;
        
        return Math.max(0, baseChance);
    }

    handleBreakthrough(character: Character, clan: Clan): BreakthroughResult {
        if (character.cultivationLevel < this.levels) {
            return { success: true, newEvents: [], clan };
        }
        
        const newClan = deepClone(clan);
        const memberToUpdate = newClan.members.find(m => m.id === character.id)!;
        
        // Check breakthrough attempts
        const attempts = memberToUpdate.breakthroughAttempts?.[this.stage] || 0;
        const isFinalAttempt = memberToUpdate.maxAge - memberToUpdate.age <= 1;
        if (attempts >= 3 && !isFinalAttempt) {
            memberToUpdate.isMeditatingForBreakthrough = false;
            return { success: false, newEvents: [{ description: `Đã dùng hết 3 cơ hội đột phá Hóa Thần, ${character.name} không thể tiếp tục.`, characterIds: [character.id] }], clan: newClan };
        }
        if (attempts >= 4) {
             memberToUpdate.isMeditatingForBreakthrough = false;
             return { success: false, newEvents: [{ description: `Đã hết tất cả cơ hội, ${character.name} Hóa Thần vô vọng.`, characterIds: [character.id] }], clan: newClan };
        }

        const hoaThanCount = newClan.members.filter(m => m.cultivationStage === CultivationStage.SOUL_FORMATION).length;
        if (hoaThanCount >= 15) {
            memberToUpdate.isMeditatingForBreakthrough = false;
            return { success: false, newEvents: [{ description: `Thiên đạo có hạn, thế gian này đã đủ 15 vị Hóa Thần Kỳ. ${character.name} không thể cảm ứng pháp tắc, đột phá thất bại.`, characterIds: [character.id] }], clan: newClan };
        }

        if (character.nguyenKhi < character.maxNguyenKhi) {
            return { success: false, newEvents: [{ description: `Nguyên khí của ${character.name} chưa viên mãn, không thể đột phá Hóa Thần.`, characterIds: [character.id] }], clan };
        }
        
        const newEvents: Omit<Event, 'id' | 'date'>[] = [];

        // Increment attempt count BEFORE the roll
        memberToUpdate.breakthroughAttempts = memberToUpdate.breakthroughAttempts || {};
        const newAttemptsCount = (memberToUpdate.breakthroughAttempts[this.stage] || 0) + 1;
        memberToUpdate.breakthroughAttempts[this.stage] = newAttemptsCount;
        
        const successChance = this.getBreakthroughSuccessChance(character, clan);
        const isSuccess = Math.random() < successChance;
        memberToUpdate.nguyenKhi = 0;
        memberToUpdate.isMeditatingForBreakthrough = false;
        
        if (isSuccess) {
            memberToUpdate.cultivationProgress = 0;
            memberToUpdate.cultivationStage = CultivationStage.SOUL_FORMATION;
            memberToUpdate.cultivationLevel = 1;

            const finalMemberState = recalculateAllStats(memberToUpdate);
            Object.assign(memberToUpdate, finalMemberState);
            memberToUpdate.health = memberToUpdate.maxHealth;
            memberToUpdate.mana = memberToUpdate.maxMana;

            newEvents.push({ description: `Trong lúc nguy nan, ${character.name} đã thành công cảm ngộ được một tia thiên địa pháp tắc! Nguyên Anh dung hợp, chính thức bước vào Hóa Thần Kỳ!`, characterIds: [character.id] });
            return { success: true, newEvents, clan: newClan };
        } else {
             const backlashSeverity = Math.random();
            if (backlashSeverity < 0.3) { // 30% chance of death
                memberToUpdate.status = CharacterStatus.DECEASED;
                newEvents.push({ description: `Hóa Thần thất bại (lần ${newAttemptsCount}), thiên địa pháp tắc phản phệ, ${character.name} không thể chống cự, nguyên thần vỡ nát, thân tử đạo tiêu!`, characterIds: [character.id] });
            } else if (backlashSeverity < 0.7) { // 40% chance of crippling
                memberToUpdate.hasGivenUpCultivation = true;
                newEvents.push({ description: `Đột phá Hóa Thần thất bại (lần ${newAttemptsCount})! ${character.name} bị pháp tắc phản phệ, đạo tâm tan vỡ, căn cơ hủy hết, từ nay không thể tu luyện.`, characterIds: [character.id] });
            } else { // 30% chance of level drop
                 memberToUpdate.cultivationProgress = memberToUpdate.cultivationProgress * 0.5; // Lose half of the progress
                 newEvents.push({ description: `Thiên địa pháp tắc mờ mịt, không thể cảm ứng. ${character.name} đột phá Hóa Thần thất bại (lần ${newAttemptsCount}), tu vi bị hao tổn.`, characterIds: [character.id] });
            }
            return { success: false, newEvents, clan: newClan };
        }
    }
}