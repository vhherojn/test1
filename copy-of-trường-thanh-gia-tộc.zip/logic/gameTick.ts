
import type { Clan, GameDate, Event } from '../types/index.ts';
import { deepClone } from './utils/clone.ts';
import { processClanTick } from './tick/clanTick.ts';
import { processBuildingsTick } from './tick/buildingTick.ts';
import { processCharactersTick } from './tick/characterTick.ts';

export const processGameTick = (clan: Clan, newDate: GameDate): { nextClan: Clan, newEvents: Omit<Event, 'id' | 'date'>[] } => {
    let nextClan: Clan = deepClone(clan);
    const allNewEvents: Omit<Event, 'id' | 'date'>[] = [];

    // Process clan-level updates (resources, tasks, etc.)
    const clanResult = processClanTick(nextClan, newDate);
    nextClan = clanResult.updatedClan;
    allNewEvents.push(...clanResult.newEvents);
    
    // Process building-specific updates (production, etc.)
    const buildingResult = processBuildingsTick(nextClan, newDate);
    nextClan = buildingResult.updatedClan;
    allNewEvents.push(...buildingResult.newEvents);

    // Process updates for each character (aging, cultivation, actions, etc.)
    const characterResult = processCharactersTick(nextClan, newDate);
    nextClan = characterResult.updatedClan;
    allNewEvents.push(...characterResult.newEvents);

    return { nextClan, newEvents: allNewEvents };
};
