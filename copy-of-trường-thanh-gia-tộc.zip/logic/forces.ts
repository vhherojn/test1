
import type { Force, Location } from '../types/index.ts';
import { RANDOM_FORCE_DATA } from '../constants.ts';
import { ForceRank } from '../types/index.ts';

// Helper to check for distance to avoid clustering
function isTooClose(x1: number, y1: number, points: (Location | Force)[], minDistance: number): boolean {
    for (const point of points) {
        const dist = Math.sqrt(Math.pow(point.x - x1, 2) + Math.pow(point.y - y1, 2));
        if (dist < minDistance) {
            return true;
        }
    }
    return false;
}

export const generateRandomForces = (count: number, existingPoints: (Location | Force)[]): Force[] => {
    const forces: Force[] = [];
    let attempts = 0;

    while (forces.length < count && attempts < 100) {
        const prefix = RANDOM_FORCE_DATA.PREFIXES[Math.floor(Math.random() * RANDOM_FORCE_DATA.PREFIXES.length)]!;
        const suffix = RANDOM_FORCE_DATA.SUFFIXES[Math.floor(Math.random() * RANDOM_FORCE_DATA.SUFFIXES.length)]!;
        const description = RANDOM_FORCE_DATA.DESCRIPTIONS[Math.floor(Math.random() * RANDOM_FORCE_DATA.DESCRIPTIONS.length)]!;
        
        // Generate coordinates within a certain range to avoid edges
        const x = 15 + Math.random() * 70;
        const y = 15 + Math.random() * 70;
        
        // Check if it's too close to existing locations or other new forces
        if (!isTooClose(x, y, [...existingPoints, ...forces], 10)) {
            const randomRoll = Math.random();
            let rank: ForceRank;
            if (randomRoll < 0.6) { // 60% chance for Hạ lưu
                rank = ForceRank.HA_LUU;
            } else if (randomRoll < 0.9) { // 30% chance for Nhất giai
                rank = ForceRank.NHAT_GIAI;
            } else { // 10% chance for Nhị giai
                rank = ForceRank.NHI_GIAI;
            }
            
            forces.push({
                id: `force_random_${crypto.randomUUID()}`,
                name: `${prefix} ${suffix}`,
                description: description,
                type: 'random',
                x: x,
                y: y,
                icon: Math.random() > 0.4 ? 'evil' : 'righteous', // More evil forces for drama
                rank: rank,
            });
        }
        attempts++;
    }

    return forces;
};