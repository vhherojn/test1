import type { Character, Clan, CharacterNeed, EquippableItem, Talisman } from '../types/index.ts';
import { NeedType, ItemType, ItemQuality, EquipmentQuality } from '../types/index.ts';
import { ALL_ITEMS } from '../constants.ts';

const qualityToNumber = (item: { quality: ItemQuality, equipmentQuality: EquipmentQuality }): number => {
    const tierOrder = Object.values(ItemQuality);
    const qualityOrder = Object.values(EquipmentQuality);

    const tierValue = tierOrder.indexOf(item.quality) * 10;
    const qualityValue = qualityOrder.indexOf(item.equipmentQuality);
    
    return tierValue + qualityValue;
}

const checkEquipmentNeeds = (character: Character, clan: Clan): CharacterNeed[] => {
    const needs: CharacterNeed[] = [];
    const equipmentSlots: (keyof Character['equipment'])[] = ['weapon', 'head', 'chest', 'feet', 'accessory1', 'accessory2'];

    // Check for empty slots
    for (const slot of equipmentSlots) {
        if (!character.equipment[slot as 'weapon']) { // Type assertion to access equipment properties
            needs.push({
                type: NeedType.EQUIPMENT,
                urgency: 30,
                detail: `Ô trang bị ${slot} đang trống.`
            });
        }
    }

    // Check for potential upgrades in clan inventory
    for (const [itemId, count] of Object.entries(clan.itemInventory)) {
        if (count < 1) continue;
        
        const itemInfo = ALL_ITEMS[itemId];
        if (!itemInfo || !('equipmentQuality' in itemInfo)) continue;

        let currentItem: (EquippableItem | Talisman) | null = null;
        let slotToCompare: keyof Character['equipment'] | null = null;
        
        switch (itemInfo.type) {
            case ItemType.WEAPON: currentItem = character.equipment.weapon; slotToCompare = 'weapon'; break;
            case ItemType.HELMET: currentItem = character.equipment.head; slotToCompare = 'head'; break;
            case ItemType.CHESTPLATE: currentItem = character.equipment.chest; slotToCompare = 'chest'; break;
            case ItemType.BOOTS: currentItem = character.equipment.feet; slotToCompare = 'feet'; break;
            case ItemType.TALISMAN: 
                // Check both accessory slots
                if (!character.equipment.accessory1 || qualityToNumber(itemInfo) > qualityToNumber(character.equipment.accessory1)) {
                    currentItem = character.equipment.accessory1;
                } else if (!character.equipment.accessory2 || qualityToNumber(itemInfo) > qualityToNumber(character.equipment.accessory2)) {
                    currentItem = character.equipment.accessory2;
                }
                break;
        }

        if (currentItem === null || qualityToNumber(itemInfo) > qualityToNumber(currentItem)) {
            const urgency = currentItem ? (qualityToNumber(itemInfo) - qualityToNumber(currentItem)) * 5 : 40;
            needs.push({
                type: NeedType.EQUIPMENT,
                urgency: Math.min(90, urgency),
                detail: `${itemInfo.name} là một nâng cấp.`
            });
        }
    }


    return needs;
};


export const processCharacterNeeds = (character: Character, clan: Clan): CharacterNeed[] => {
    let currentNeeds = [...character.needs];

    // Remove fulfilled or outdated needs (for now, we just regenerate)
    currentNeeds = [];

    const equipmentNeeds = checkEquipmentNeeds(character, clan);
    currentNeeds.push(...equipmentNeeds);

    // Sort by urgency, descending
    return currentNeeds.sort((a, b) => b.urgency - a.urgency);
};