import type { Clan, Event, Character, Pill, Blueprint, Recipe, Talisman } from '../../types/index.ts';
import { ItemQuality, ItemType, EquipmentQuality, ProfessionType, TalentType } from '../../types/index.ts';
import { ALL_RECIPES, BUILDINGS, ALL_ITEMS } from '../../constants.ts';
import { deepClone } from '../utils/clone.ts';

type ItemActionResult = { updatedClan?: Clan; newEvents?: Omit<Event, 'id' | 'date'>[]; error?: string; };

export function storeItemToClan(clan: Clan, characterId: string, itemId: string): ItemActionResult {
    const newClan = deepClone(clan);
    const character = newClan.members.find((m: Character) => m.id === characterId);
    const itemInfo = ALL_ITEMS[itemId as keyof typeof ALL_ITEMS];

    if (!character) return { error: "Không tìm thấy tộc nhân." };
    if (!itemInfo) return { error: "Vật phẩm không tồn tại." };
    if ((character.inventory[itemId] || 0) < 1) return { error: `Trong túi đồ không có ${itemInfo.name}.` };

    character.inventory[itemId] -= 1;
    if (character.inventory[itemId] === 0) {
        delete character.inventory[itemId];
    }
    newClan.itemInventory[itemId] = (newClan.itemInventory[itemId] || 0) + 1;
    character.loyalty = Math.max(0, character.loyalty - 1);

    return {
        updatedClan: newClan,
        newEvents: [{
            description: `Tịch thu 1 ${itemInfo.name} từ ${character.name}, lòng trung thành giảm 1.`,
            characterIds: [character.id]
        }]
    };
}

export function useItem(clan: Clan, characterId: string, itemId: string): ItemActionResult {
    const newClan = deepClone(clan);
    const character = newClan.members.find((m: Character) => m.id === characterId);
    
    if (!character) return { error: "Không tìm thấy tộc nhân." };
    const itemInfo = ALL_ITEMS[itemId as keyof typeof ALL_ITEMS];
    if (!itemInfo) return { error: "Vật phẩm không tồn tại."};

    if ((character.inventory[itemId] || 0) < 1) return { error: `Trong túi đồ không có ${itemInfo.name}.` };

    if (itemInfo.type === ItemType.PILL) {
        character.inventory[itemId] -= 1;
        if (character.inventory[itemId] === 0) delete character.inventory[itemId];

        const pillInfo = itemInfo as Pill;
        let eventDescription = `${character.name} đã sử dụng ${pillInfo.name}.`;

        if (pillInfo.effects.cultivation_progress_gain) {
            character.cultivationProgress += pillInfo.effects.cultivation_progress_gain;
            eventDescription += ` Tu vi tăng ${pillInfo.effects.cultivation_progress_gain}.`;
        }
        if (pillInfo.effects.health_recovery) {
            character.health = Math.min(character.maxHealth, character.health + pillInfo.effects.health_recovery);
            eventDescription += ` Hồi phục ${pillInfo.effects.health_recovery} khí huyết.`;
        }
        if (pillInfo.effects.mana_recovery) {
            character.mana = Math.min(character.maxMana, character.mana + pillInfo.effects.mana_recovery);
            eventDescription += ` Hồi phục ${pillInfo.effects.mana_recovery} linh lực.`;
        }
        if (pillInfo.impurity && pillInfo.impurity > 0) {
            character.bodyImpurity = (character.bodyImpurity || 0) + pillInfo.impurity;
            eventDescription += ` Tạp chất trong cơ thể tăng lên.`;
        }

        return { updatedClan: newClan, newEvents: [{ description: eventDescription, characterIds: [characterId] }] };
    }
    
    if (itemInfo.type === ItemType.TALISMAN) {
        character.inventory[itemId] -= 1;
        if (character.inventory[itemId] === 0) delete character.inventory[itemId];

        const talismanInfo = itemInfo as Talisman;
        const eventDescription = `${character.name} đã sử dụng ${talismanInfo.name}. (Hiệu ứng sẽ được áp dụng trong chiến đấu)`;

        return { updatedClan: newClan, newEvents: [{ description: eventDescription, characterIds: [characterId] }] };
    }


    return { error: "Vật phẩm không thể sử dụng." };
}