import React from 'react';
import type { AnyItem, EquippableItem, TechniqueItem, Pill, MasteryProgress } from '../../types/index.ts';
import { ItemType, TechniqueMastery } from '../../types/index.ts';
import { ITEM_QUALITY_COLORS, TECHNIQUE_MASTERY_DATA, ALL_TECHNIQUES } from '../../constants.ts';

const StatRow: React.FC<{ label: string; value: string | number; color?: string, originalValue?: string | number }> = ({ label, value, color = 'text-green-400', originalValue }) => (
    <li>{label}: <span className={`font-semibold ${color}`}>{value}</span> {originalValue && <span className='text-gray-400 text-xs'>({originalValue})</span>}</li>
);

const EFFECT_TRANSLATIONS: Record<string, string> = {
    // Stats Modifiers
    healthModifier: 'Tăng Khí Huyết',
    manaModifier: 'Tăng Linh Lực',
    cultivationSpeedModifier: 'Tốc Độ Tu Luyện',
    manaRecoveryRate: 'Tốc Độ Hồi Linh Lực',
    magicalAttackModifier: 'Hệ Số Pháp Lực',
    areaMagicalAttackModifier: 'Hệ Số Pháp Lực (Diện Rộng)',
    physicalAttackModifier: 'Hệ Số Công Kích',
    
    // Stats Flat
    maxHealth: 'Khí Huyết Tối Đa',
    maxMana: 'Linh Lực Tối Đa',
    speed: 'Tốc Độ',
    physicalAttack: 'Công Kích',
    magicalAttack: 'Pháp Lực',
    physicalDefense: 'Phòng Ngự',
    magicalDefense: 'Hộ Thể',
    critChance: 'Tỷ Lệ Bạo Kích',
    critDamage: 'Sát Thương Bạo Kích',
    
    // Pill Effects
    mana_recovery: 'Hồi Phục Linh Lực',
    cultivation_progress_gain: 'Tăng Tu Vi',
    health_recovery: 'Hồi Phục Khí Huyết',
    
    // Spell/Secret Art Effects
    manaCost: 'Tiêu hao Linh Lực',
    stunChance: 'Tỷ Lệ Choáng',
    areaSpeedDebuff: 'Làm Chậm (Diện Rộng)',
    damageOverTime: 'Sát Thương Theo Thời Gian',
    speedDebuff: 'Làm Chậm',
    healthCost: 'Tiêu hao Khí Huyết',
    lifespanCost: 'Tiêu hao Tuổi Thọ',
    temporaryDefense: 'Phòng Ngự Tạm Thời',
    temporarySpeed: 'Tốc Độ Tạm Thời',
    temporaryAttack: 'Công Kích Tạm Thời',
    
    // Misc
    professionUnlock: 'Mở Khóa Nghề',
    explorationRange: 'Phạm Vi Thăm Dò',
    soulAttack: 'Công Kích Nguyên Thần',

    // Profession Bonuses
    alchemySuccessRateBonus: 'Tỷ lệ Luyện Đan thành công',
    alchemyTimeReduction: 'Giảm thời gian Luyện Đan',
    blacksmithingSuccessRateBonus: 'Tỷ lệ Luyện Khí thành công',
    blacksmithingTimeReduction: 'Giảm thời gian Luyện Khí',
    talismanSuccessRateBonus: 'Tỷ lệ Chế Phù thành công',
    talismanTimeReduction: 'Giảm thời gian Chế Phù',
    formationSuccessRateBonus: 'Tỷ lệ Chế Trận thành công',
    formationTimeReduction: 'Giảm thời gian Chế Trận',
};


export function generateTooltipContent(item: AnyItem, masteryProgress?: MasteryProgress): React.ReactNode {
    const qualityColor = ITEM_QUALITY_COLORS[item.quality] || 'text-white';
    const masteryData = masteryProgress ? TECHNIQUE_MASTERY_DATA[masteryProgress.mastery] : null;

    const renderBaseInfo = () => (
        <>
            <p className={`font-bold text-lg ${qualityColor}`}>{item.name}</p>
             {masteryData && <p className="text-md font-bold text-purple-300">Cảnh giới: {masteryData.name}</p>}
            {'equipmentQuality' in item && <p className="text-sm text-gray-400 mb-2">{item.type} - {item.quality} - {item.equipmentQuality}</p>}
            {!('equipmentQuality' in item) && item.type !== ItemType.RESOURCE && <p className="text-sm text-gray-400 mb-2">{item.type} - {item.quality}</p>}
            <p className="text-sm text-white/90 italic p-3 bg-black/20 rounded-md mb-4">"{item.description}"</p>
             {'history' in item && item.history && <p className="text-xs text-amber-200/70 italic mb-3">"{item.history}"</p>}
        </>
    );

    const renderEffects = (effects: Record<string, any>) => (
        <>
            <h4 className="font-bold text-amber-300 mb-1">Hiệu ứng:</h4>
            <ul className="text-xs text-white/80 list-disc list-inside space-y-1">
                {Object.entries(effects).map(([key, baseValue]) => {
                    const formattedKey = EFFECT_TRANSLATIONS[key] || key.replace(/([A-Z])/g, ' $1').replace(/_/g, ' ').replace(/^./, str => str.toUpperCase());
                    
                    let finalValue = baseValue;
                    let originalValueStr: string | null = null;
                    
                    if (masteryData && typeof baseValue === 'number') {
                        if (key.toLowerCase().includes('cost')) {
                            finalValue = Math.round(baseValue * masteryData.costMultiplier);
                        } else if (key !== 'professionUnlock') { // Don't multiply non-stat effects
                             finalValue = baseValue * masteryData.effectMultiplier;
                        }
                        if (Math.abs(finalValue - baseValue) > 0.01) {
                             originalValueStr = baseValue.toFixed(0);
                        }
                    }

                    if (key.includes('Modifier') || key.includes('Reduction') || key.includes('Bonus')) {
                        const valueToFormat = key.includes('Modifier') ? finalValue - 1 : finalValue;
                        const originalValueToFormat = originalValueStr ? (baseValue - 1) : null;
                        
                        const percentage = Math.round(valueToFormat * 100);
                        const originalPercentage = originalValueToFormat !== null ? `${Math.round(originalValueToFormat * 100)}%` : null;

                        const sign = percentage > 0 ? '+' : '';
                        const color = key.includes('Reduction') ? 'text-green-400' : (percentage > 0 ? 'text-green-400' : 'text-red-400');

                        return <StatRow key={key} label={formattedKey} value={`${sign}${percentage}%`} color={color} originalValue={originalPercentage}/>;
                    }
                     if (key === 'critChance' || key === 'stunChance') {
                        return <StatRow key={key} label={formattedKey} value={`${(finalValue * 100).toFixed(0)}%`} originalValue={originalValueStr ? `${(baseValue * 100).toFixed(0)}%` : null}/>;
                    }
                    if (key === 'critDamage' || key === 'manaRecoveryRate') {
                        return <StatRow key={key} label={formattedKey} value={`x${finalValue.toFixed(2)}`} originalValue={originalValueStr ? `x${baseValue.toFixed(2)}` : null}/>;
                    }
                    if (typeof finalValue === 'number' && finalValue > 0) {
                        return <StatRow key={key} label={formattedKey} value={`+${Math.floor(finalValue)}`} originalValue={originalValueStr ? `+${originalValueStr}` : null} />;
                    }
                     if (typeof finalValue === 'number' && finalValue < 0) {
                        return <StatRow key={key} label={formattedKey} value={`${Math.floor(finalValue)}`} color="text-red-400" originalValue={originalValueStr} />;
                    }
                    return <li key={key}>{formattedKey}: {JSON.stringify(finalValue)}</li>;
                })}
            </ul>
        </>
    );

    const renderRequirements = (requirements: TechniqueItem['requirements']) => (
        <>
            <h4 className="font-bold text-amber-300 mt-2 mb-1">Yêu cầu tu luyện:</h4>
            <ul className="text-xs text-white/80 list-disc list-inside space-y-1">
                {requirements.cultivationStage && <StatRow label="Cảnh giới" value={requirements.cultivationStage} color="text-yellow-400" />}
                {requirements.comprehension && <StatRow label="Ngộ tính" value={requirements.comprehension} color="text-yellow-400" />}
                {requirements.elements && <StatRow label="Linh căn" value={requirements.elements.join(', ')} color="text-yellow-400" />}
                 {requirements.daoTam && <StatRow label="Đạo tâm" value={requirements.daoTam} color="text-yellow-400" />}
            </ul>
        </>
    );

    const mainContent = () => {
        switch (item.type) {
            case ItemType.WEAPON:
            case ItemType.HELMET:
            case ItemType.CHESTPLATE:
            case ItemType.BOOTS:
            case ItemType.TALISMAN:
                const equip = item as EquippableItem;
                return renderEffects(equip.effects);
            
            case ItemType.CULTIVATION_METHOD:
            case ItemType.SECRET_ART:
            case ItemType.SPELL:
                const tech = item as TechniqueItem;
                return (
                    <>
                        {Object.keys(tech.effects).length > 0 && renderEffects(tech.effects)}
                        {Object.keys(tech.requirements).length > 0 && renderRequirements(tech.requirements)}
                    </>
                );

            case ItemType.PILL:
                const pill = item as Pill;
                return (
                     <>
                        {renderEffects(pill.effects)}
                        {pill.impurity && pill.impurity > 0 && (
                            <div className='mt-2'>
                                <h4 className="font-bold text-red-400/80 mb-1 text-xs">Tác Dụng Phụ:</h4>
                                <ul className="text-xs text-white/80 list-disc list-inside space-y-1">
                                     <li>Tăng Tạp Chất: <span className="font-semibold text-red-400">{pill.impurity}</span></li>
                                </ul>
                            </div>
                        )}
                    </>
                );

            default:
                return null;
        }
    };
    
    return (
        <div>
            {renderBaseInfo()}
            {mainContent()}
        </div>
    );
}