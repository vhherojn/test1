import type { Character, Recipe, TechniqueItem } from '../../types/index.ts';
import { ItemQuality, EquipmentQuality, TalentType, ProfessionType } from '../../types/index.ts';
import { ALL_TECHNIQUES, PROFESSION_CRAFTING_SUCCESS_RATES } from '../../constants.ts';

const TALENT_MAP: Partial<Record<ProfessionType, TalentType>> = {
    [ProfessionType.ALCHEMIST]: TalentType.ALCHEMY,
    [ProfessionType.BLACKSMITH]: TalentType.BLACKSMITHING,
    [ProfessionType.TALISMAN_MASTER]: TalentType.TALISMAN_MAKING,
    [ProfessionType.FORMATION_MASTER]: TalentType.FORMATION_MAKING,
};

const TECHNIQUE_BONUS_MAP: Partial<Record<ProfessionType, string>> = {
    [ProfessionType.ALCHEMIST]: 'alchemySuccessRateBonus',
    [ProfessionType.BLACKSMITH]: 'blacksmithingSuccessRateBonus',
    [ProfessionType.TALISMAN_MASTER]: 'talismanSuccessRateBonus',
    [ProfessionType.FORMATION_MASTER]: 'formationSuccessRateBonus',
};

export const calculateCraftingSuccessChance = (crafter: Character, recipe: Recipe, professionType: ProfessionType): number => {
    const profession = crafter.professions.find(p => p.type === professionType);
    if (!profession) return 0.01; // Không thể chế tạo nếu không có nghề

    // 1. Lấy tỷ lệ thành công cơ bản từ cấp bậc nghề nghiệp của nhân vật
    let baseChance = PROFESSION_CRAFTING_SUCCESS_RATES[profession.tier]?.[profession.quality] || 0.05;

    // 2. Phạt nếu chế vật phẩm có yêu cầu cấp nghề cao hơn
    const tierDifference = Object.values(ItemQuality).indexOf(recipe.requiredProfessionTier) - Object.values(ItemQuality).indexOf(profession.tier);
    if (tierDifference > 0) {
        baseChance -= tierDifference * 0.25; // Phạt 25% cho mỗi Giai chênh lệch
    }
    
    // 3. Cộng thưởng từ Thiên phú
    const talentType = TALENT_MAP[professionType];
    if (talentType) {
        // 100 điểm thiên phú sẽ cộng thêm 20% tỷ lệ
        baseChance += (crafter.talents[talentType] || 0) / 500; 
    }
    
    // 4. Cộng thưởng từ các Công pháp/Bí thuật đã học và trang bị
    const bonusKey = TECHNIQUE_BONUS_MAP[professionType];
    if (bonusKey) {
        const allTechs = [...Object.values(crafter.techniques).flat().filter(Boolean), ...crafter.learnedTechniques, ...crafter.professionTechniques];
        const uniqueTechIds = [...new Set(allTechs)];

        for (const techId of uniqueTechIds) {
            const tech = ALL_TECHNIQUES[techId] as TechniqueItem;
            if (tech && tech.effects && typeof (tech.effects as any)[bonusKey] === 'number') {
                baseChance += (tech.effects as any)[bonusKey];
            }
        }
    }

    // 5. Cộng thưởng từ Thần Thức
    if (crafter.thanThuc) {
        // 100 điểm thần thức cộng thêm 10% tỷ lệ
        baseChance += crafter.thanThuc / 1000;
    }

    return Math.min(0.95, Math.max(0.01, baseChance)); // Giới hạn tỷ lệ trong khoảng 1% đến 95%
};