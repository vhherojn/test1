import { ItemQuality, EquipmentQuality } from '../../types/index.ts';

// Thời gian (tháng) cần thiết để hoàn thành học việc cho một cấp bậc nghề nghiệp
export const PROFESSION_APPRENTICESHIP_DURATIONS: Record<ItemQuality, { min: number, max: number }> = {
    [ItemQuality.NHAT_GIAI]: { min: 6, max: 8 },      // Nhập môn
    [ItemQuality.NHI_GIAI]: { min: 12, max: 24 },    // Lên Nhị Giai
    [ItemQuality.TAM_GIAI]: { min: 36, max: 48 },    // Lên Tam Giai
    [ItemQuality.TU_GIAI]: { min: 120, max: 240 },   // Lên Tứ Giai
    [ItemQuality.NGU_GIAI]: { min: 1200, max: 2400 }, // Lên Ngũ Giai
};

// Tỷ lệ thành công cơ bản khi chế tạo, dựa trên cấp bậc và phẩm chất của nghề
export const PROFESSION_CRAFTING_SUCCESS_RATES: Record<ItemQuality, Record<EquipmentQuality, number>> = {
    [ItemQuality.NHAT_GIAI]: {
        [EquipmentQuality.HA_PHAM]: 0.40,
        [EquipmentQuality.TRUNG_PHAM]: 0.50,
        [EquipmentQuality.THUONG_PHAM]: 0.60,
    },
    [ItemQuality.NHI_GIAI]: {
        [EquipmentQuality.HA_PHAM]: 0.35,
        [EquipmentQuality.TRUNG_PHAM]: 0.45,
        [EquipmentQuality.THUONG_PHAM]: 0.55,
    },
    [ItemQuality.TAM_GIAI]: {
        [EquipmentQuality.HA_PHAM]: 0.30,
        [EquipmentQuality.TRUNG_PHAM]: 0.40,
        [EquipmentQuality.THUONG_PHAM]: 0.50,
    },
     [ItemQuality.TU_GIAI]: {
        [EquipmentQuality.HA_PHAM]: 0.25,
        [EquipmentQuality.TRUNG_PHAM]: 0.35,
        [EquipmentQuality.THUONG_PHAM]: 0.45,
    },
     [ItemQuality.NGU_GIAI]: {
        [EquipmentQuality.HA_PHAM]: 0.20,
        [EquipmentQuality.TRUNG_PHAM]: 0.30,
        [EquipmentQuality.THUONG_PHAM]: 0.40,
    },
};