
import type { Clan, GameDate, Event, Character, EquippableItem, TechniqueItem, PromotionRule, Formation } from '../../types/index.ts';
import { CultivationStage, CharacterStatus, ItemType, TechniqueMastery, CharacterActivity, RelationshipClass, ItemQuality, TalentType } from '../../types/index.ts';
import {
    LINH_MACH_DATA, PHYSIQUES,
    TASKS, ALL_ITEMS, TECHNIQUE_MASTERY_DATA, ALL_TECHNIQUES, CULTIVATION_STAGES, MASTERY_EXP_REQUIREMENTS
} from '../../constants.ts';
import { recalculateAllStats, createCharacter } from '../character.ts';
import { processCharacterNeeds } from '../characterNeeds.ts';
import { cultivationStateFactory } from '../cultivation/stateFactory.ts';
import { performAutonomousActions } from './autonomousActions.ts';


type CharacterTickResult = {
    updatedClan: Clan;
    newEvents: Omit<Event, 'id' | 'date'>[];
};

const checkAndApplyPromotions = (character: Character, clan: Clan): Omit<Event, 'id' | 'date'> | null => {
    const applicableRule = clan.promotionRules.find(rule => 
        rule.fromRank === character.rank &&
        (!rule.conditions.stage || Object.values(CultivationStage).indexOf(character.cultivationStage) >= Object.values(CultivationStage).indexOf(rule.conditions.stage)) &&
        (!rule.conditions.contribution || character.contribution >= rule.conditions.contribution)
    );

    if (applicableRule) {
        const oldRank = character.rank;
        character.rank = applicableRule.toRank;
        return {
            description: `Do đạt đủ điều kiện, ${character.name} đã được tự động tấn thăng từ ${oldRank} lên ${applicableRule.toRank}!`,
            characterIds: [character.id]
        };
    }

    return null;
}


export const processCharactersTick = (clan: Clan, newDate: GameDate): CharacterTickResult => {
    const newEvents: Omit<Event, 'id' | 'date'>[] = [];
    let membersToAdd: Character[] = [];

    const linhMachInfo = LINH_MACH_DATA[clan.linhMach.tier]?.[clan.linhMach.quality];
    const linhMachModifier = linhMachInfo?.cultivationModifier || 1.0;
    
    // Get clan-wide formation bonus
    let formationModifier = 1.0;
    if (clan.activeFormationId) {
        const formation = ALL_ITEMS[clan.activeFormationId] as Formation;
        if (formation && formation.effects.clanCultivationSpeedModifier) {
            formationModifier = formation.effects.clanCultivationSpeedModifier;
        }
    }


    for (let i = 0; i < clan.members.length; i++) {
        let member = clan.members[i];
        
        if (member.status !== CharacterStatus.ALIVE) continue;

        // --- Handle Pregnancy and Childbirth ---
        if (member.pregnancy) {
            member.pregnancy.monthsRemaining -= 1;
            if (member.pregnancy.monthsRemaining <= 0) {
                const mother = member;
                const father = clan.members.find(m => m.id === mother.pregnancy!.partnerId);
                
                if (father && father.status === CharacterStatus.ALIVE) {
                    const newChild = createCharacter({
                        familyName: father.name.split(' ')[0],
                        age: 0,
                        isPatriarch: false,
                        cultivationStage: CultivationStage.QI_REFINEMENT,
                        cultivationLevel: 1,
                        parents: { father, mother },
                        clan: clan,
                    });
                    
                    // Add relationship from child to parents
                    newChild.relationships.push({ class: RelationshipClass.FAMILY_CLOSE, characterId: mother.id, affinity: 100, description: "Mẫu thân" });
                    newChild.relationships.push({ class: RelationshipClass.FAMILY_CLOSE, characterId: father.id, affinity: 100, description: "Phụ thân" });

                    // Add relationship from parents to child
                    mother.relationships.push({ class: RelationshipClass.FAMILY_CLOSE, characterId: newChild.id, affinity: 100, description: "Hậu duệ" });
                    father.relationships.push({ class: RelationshipClass.FAMILY_CLOSE, characterId: newChild.id, affinity: 100, description: "Hậu duệ" });
                    
                    membersToAdd.push(newChild);
                    
                    newEvents.push({
                        description: `${mother.name} đã hạ sinh một hài nhi kháu khỉnh, đặt tên là ${newChild.name}. Chúc phúc cho gia tộc lại có thêm nhân tài!`,
                        characterIds: [mother.id, father.id, newChild.id]
                    });
                }
                mother.pregnancy = null;
            }
        }

        // --- Handle DEATH from attempting breakthrough while injured ---
        if (member.isMeditatingForBreakthrough && (member.injuryTurnsRemaining || 0) > 0) {
            member.status = CharacterStatus.DECEASED;
            newEvents.push({ description: `Liều mạng đột phá trong trạng thái Trọng Thương, ${member.name} bị kinh mạch nghịch chuyển, bạo thể mà chết!`, characterIds: [member.id] });
            continue; // Character is dead, end their tick.
        }

        // --- Handle Injury Recovery ---
        if (member.injuryTurnsRemaining && member.injuryTurnsRemaining > 0) {
            member.injuryTurnsRemaining -= 1;
            if (member.injuryTurnsRemaining <= 0) {
                member.injuryTurnsRemaining = undefined; // Clear the status
                newEvents.push({ description: `${member.name} đã hoàn toàn hồi phục sau khi trọng thương.`, characterIds: [member.id] });
                Object.assign(member, recalculateAllStats(member)); // Recalculate stats to restore combat power
            }
        }
        
        const tuLuyenThap = clan.buildings['tu_luyen_thap'];

        // --- Handle Tribulation ---
        if (member.tribulationState) {
            const turn = 3 - member.tribulationState.turnsRemaining + 1;
            member.tribulationState.turnsRemaining -= 1;
            let lightningDamage = member.maxHealth * (0.3 + Math.random() * 0.15); // 30-45% damage per month

            // Equipment can help reduce damage
            const totalDefense = member.combatStats.magicalDefense + member.combatStats.physicalDefense;
            const damageReduction = Math.min(0.5, totalDefense / (totalDefense + 50000)); // Capped at 50% reduction
            lightningDamage *= (1 - damageReduction);

            member.health -= lightningDamage;
            
            let eventDescription = '';
            if (turn === 1) {
                eventDescription = `Đạo lôi kiếp thứ nhất giáng xuống! ${member.name} vận dụng toàn lực phòng ngự, khí huyết chấn động.`;
            } else if (turn === 2) {
                eventDescription = `Đạo lôi kiếp thứ hai mang theo uy thế hủy diệt! ${member.name} cắn răng chống đỡ, toàn thân cháy đen, nhưng vẫn kiên trì.`;
            } else {
                eventDescription = `Đạo lôi kiếp cuối cùng, uy lực kinh thiên! ${member.name} gầm lên một tiếng, dùng hết át chủ bài để đối kháng thiên uy!`;
            }

            newEvents.push({ description: eventDescription, characterIds: [member.id] });
            
            if (member.health <= 0) {
                member.status = CharacterStatus.DECEASED;
                newEvents.push({ description: `Lôi kiếp quá mạnh, ${member.name} không thể chống đỡ, đã hình thần câu diệt, hoá thành tro bụi giữa đất trời!`, characterIds: [member.id] });
                continue; // Character is dead, end their tick.
            }

            if (member.tribulationState.turnsRemaining <= 0) {
                newEvents.push({ description: `Sau 3 tháng, Lôi Kiếp đã qua, ${member.name} thành công vượt qua cửa ải của trời đất, bắt đầu phá đan!`, characterIds: [member.id] });
                
                // Final breakthrough roll after surviving tribulation
                const currentState = cultivationStateFactory.getState(member.cultivationStage);
                const successChance = currentState.getBreakthroughSuccessChance(member, clan);
                const isSuccess = Math.random() < successChance;

                member.tribulationState = null;
                member.nguyenKhi = 0;

                if(isSuccess) {
                     member.cultivationProgress = 0;
                     member.cultivationStage = CultivationStage.NASCENT_SOUL;
                     member.cultivationLevel = 1;

                     const finalMemberState = recalculateAllStats(member);
                     Object.assign(member, finalMemberState);
                     member.health = member.maxHealth;
                     member.mana = member.maxMana;

                     newEvents.push({
                         description: `Tâm ma xâm nhập, nhưng đạo tâm của ${member.name} vững như bàn thạch. Sau khi phá tan tâm ma, kim đan vỡ nát, Nguyên Anh thành hình!`,
                         characterIds: [member.id]
                     });
                } else {
                    const backlashSeverity = Math.random();
                    const daoTamFactor = member.daoTam < 50 ? 'đạo tâm không vững' : (member.daoTam < 75 ? 'đạo tâm có tì vết' : 'đạo tâm vững chắc');
                    if (backlashSeverity < 0.2) {
                        member.status = CharacterStatus.DECEASED;
                        newEvents.push({ description: `Dù đã qua Lôi Kiếp, nhưng do ${daoTamFactor}, ${member.name} đã bị Tâm Ma Kiếp thôn phệ, tẩu hỏa nhập ma, thân tử đạo tiêu!`, characterIds: [member.id] });
                    } else if (backlashSeverity < 0.6) {
                        member.hasGivenUpCultivation = true;
                        newEvents.push({ description: `Tâm ma phản phệ! Do ${daoTamFactor}, ${member.name} không vượt qua được, đạo tâm tan vỡ, căn cơ hủy hết, từ nay không thể tu luyện.`, characterIds: [member.id] });
                    } else {
                        member.cultivationLevel = Math.max(1, member.cultivationLevel - 3);
                        member.injuryTurnsRemaining = 12;
                        newEvents.push({ description: `Tâm ma phản phệ! Tuy may mắn giữ được mạng nhưng do ${daoTamFactor}, ${member.name} bị tu vi đại tổn, rơi xuống ${member.cultivationStage} Tầng ${member.cultivationLevel} và bị Trọng Thương nặng.`, characterIds: [member.id] });
                    }
                }
            }
             continue; // End turn after handling tribulation
        }

        // --- Handle Ongoing Timed Activities First ---
        if (member.activeTaskId) {
            member.taskProgress = (member.taskProgress || 0) + 1;
            const task = TASKS.find(t => t.id === member.activeTaskId);
            if (task && member.taskProgress >= task.duration) {
                if(task.rewards.spirit_stone) clan.resources.spirit_stone = (clan.resources.spirit_stone || 0) + task.rewards.spirit_stone;
                if(task.rewards.contribution) member.contribution += task.rewards.contribution;
                if(task.rewards.items) {
                    for(const [itemId, count] of Object.entries(task.rewards.items)) {
                        clan.itemInventory[itemId] = (clan.itemInventory[itemId] || 0) + count;
                    }
                }
                newEvents.push({ description: `${member.name} đã hoàn thành nhiệm vụ "${task.name}", nhận được ${task.rewards.contribution || 0} điểm cống hiến.`, characterIds: [member.id] });
                member.activeTaskId = null;
                member.taskProgress = 0;
            }
        }
        
        if (member.cultivationTowerState && tuLuyenThap) {
            member.cultivationTowerState.turnsRemaining -= 1;
            if (member.cultivationTowerState.turnsRemaining <= 0) {
                newEvents.push({ description: `${member.name} đã kết thúc tu luyện tại Tu Luyện Tháp.`, characterIds: [member.id] });
                member.cultivationTowerState = null;
                // Find and free the station slot
                for (const station of tuLuyenThap.stations) {
                    if (station.workerId === member.id) {
                        station.workerId = null;
                        break;
                    }
                }
                member.assignedToBuildingId = undefined;
            }
        }

        // --- Breakthrough Handling ---
        if (member.isMeditatingForBreakthrough) {
            const currentState = cultivationStateFactory.getState(member.cultivationStage);
            const breakthroughResult = currentState.handleBreakthrough(member, clan);
            clan = breakthroughResult.clan; // Update clan state from breakthrough result
            newEvents.push(...breakthroughResult.newEvents);
            member = clan.members[i]; // Re-fetch member as clan object might be new
            if (breakthroughResult.success) {
                newEvents.push({ description: `Sau khi đột phá, thực lực của ${member.name} đã tăng vọt!`, characterIds: [member.id] });
            }
            continue; 
        }
        
        // --- Aging & Stat Updates ---
        if (newDate.month === 1) { 
            member.age += 1;
            const promotionEvent = checkAndApplyPromotions(member, clan);
            if (promotionEvent) {
                newEvents.push(promotionEvent);
            }
        }
        member.nguyenKhi = Math.min(member.maxNguyenKhi, member.nguyenKhi + member.maxNguyenKhi * 0.1);
        member.needs = processCharacterNeeds(member, clan);
        
        // --- Determine Activity State & Perform Autonomous Actions ---
        const isWorking = !!(member.activeTaskId || member.assignedToBuildingId);
        const isIdle = !isWorking && !member.isMeditatingForBreakthrough && !member.techniqueTrainingState;
        member.activity = isWorking ? CharacterActivity.WORKING : (member.isMeditatingForBreakthrough ? CharacterActivity.SECLUDED : (member.techniqueTrainingState ? CharacterActivity.CULTIVATING : (member.tribulationState ? CharacterActivity.TRIBULATION : CharacterActivity.IDLE)));


        if (isIdle) {
            // The function now can return multiple events
            const autonomousResult = performAutonomousActions(member, clan, newDate);
            if (autonomousResult) {
                clan = autonomousResult.updatedClan;
                member = clan.members[i]; // Re-fetch member after potential clan state change
                if (autonomousResult.events && autonomousResult.events.length > 0) {
                    newEvents.push(...autonomousResult.events);
                }
            }
        }

        // Master-Disciple Interaction
        if (member.masterId) {
            const master = clan.members.find(m => m.id === member.masterId);
            if (master && Math.random() < 0.2) { // 20% chance per month
                const comprehensionGain = 1;
                member.comprehension = Math.min(100, member.comprehension + comprehensionGain);
                newEvents.push({
                    description: `Nhận được sự chỉ điểm của sư phụ ${master.name}, ${member.name} có điều ngộ ra, ngộ tính tăng ${comprehensionGain}.`,
                    characterIds: [member.id, master.id]
                });
            }
        }
        
        // --- Check for giving up ---
        /*
        if (member.age > 65 && member.cultivationStage === CultivationStage.QI_REFINEMENT && !member.hasGivenUpCultivation) {
            member.hasGivenUpCultivation = true;
            newEvents.push({ description: `Tuổi tác đã cao, khí huyết của ${member.name} dần suy bại. Cảm thấy tiên lộ vô vọng, y đã quyết định từ bỏ tu luyện.`, characterIds: [member.id] });
        }
        */
        if (member.hasGivenUpCultivation) continue;

        // --- Bottleneck Check ---
        const mainCultivationId = member.techniques.mainCultivation;
        const mainCultivation = mainCultivationId ? ALL_TECHNIQUES[mainCultivationId] as TechniqueItem : null;
        let isBlockedByCultivationMethod = false;
        if (!mainCultivation) {
             isBlockedByCultivationMethod = true;
        } else if (mainCultivation && mainCultivation.maxCultivationStage) {
            const stageOrder = Object.values(CultivationStage);
            const currentStageIndex = stageOrder.indexOf(member.cultivationStage);
            const maxStageIndex = stageOrder.indexOf(mainCultivation.maxCultivationStage);
            if (currentStageIndex >= maxStageIndex) {
                isBlockedByCultivationMethod = true;
            }
        }
        member.isCultivationBlocked = isBlockedByCultivationMethod;
        
        let potentialCultivationGain = 0;
        if (!member.isCultivationBlocked) {
            // --- Cultivation Progress ---
            const currentState = cultivationStateFactory.getState(member.cultivationStage);
            const physique = PHYSIQUES[member.physiqueName as keyof typeof PHYSIQUES];
            let totalCultivationModifier = physique.effects.cultivationSpeedModifier;
            if (mainCultivation?.effects.cultivationSpeedModifier) {
                 totalCultivationModifier *= mainCultivation.effects.cultivationSpeedModifier;
            }
            
            let spiritualRootModifier = 1.0;
            const elementCount = member.spiritualRoot.elements.length;
            if (elementCount === 1) { // Thiên & Dị
                spiritualRootModifier = 1.5;
            } else if (elementCount === 2) { // Song
                spiritualRootModifier = 1.3;
            } else if (elementCount === 3) { // Tam
                spiritualRootModifier = 1.15;
            } else if (elementCount === 4) { // Tứ
                spiritualRootModifier = 0.5;
            } else if (elementCount === 5) { // Ngũ
                spiritualRootModifier = 0.2;
            }
            
            let activityModifier = 1.0;
            if (isWorking) {
                activityModifier = 0.5;
            }
    
            potentialCultivationGain = 10 * totalCultivationModifier * (1 + member.comprehension / 200) * linhMachModifier * spiritualRootModifier * activityModifier * formationModifier;
            
            if (member.cultivationTowerState && tuLuyenThap) {
                const towerBonus = 0.5 + (tuLuyenThap.level * 0.5); 
                potentialCultivationGain *= (1 + towerBonus);
            }
            
            const linhKhiCost = (potentialCultivationGain / 10) * currentState.upkeep;
            
            if ((clan.resources.linh_khi || 0) >= linhKhiCost) {
                clan.resources.linh_khi -= linhKhiCost;
                member.cultivationProgress += potentialCultivationGain;
            } else {
                 newEvents.push({ description: `Linh khí gia tộc không đủ, ${member.name} không thể tu luyện.`, characterIds: [member.id] });
            }
        } else {
             if (newDate.month % 6 === 0) {
                const reason = mainCultivation ? `công pháp "${mainCultivation.name}" đã đạt đến giới hạn` : "chưa có công pháp chủ tu";
                newEvents.push({ description: `Tu vi của ${member.name} bị đình trệ do ${reason}.`, characterIds: [member.id] });
            }
        }

        // --- Level Up & Breakthrough Check (Refactored) ---
        const currentState = cultivationStateFactory.getState(member.cultivationStage);
        let hasLeveledUp = false;
        
        // Loop for leveling up within the current stage
        while (member.cultivationLevel < currentState.levels && member.cultivationProgress >= currentState.getExpForLevel(member.cultivationLevel)) {
            member.cultivationProgress -= currentState.getExpForLevel(member.cultivationLevel);
            member.cultivationLevel += 1;
            hasLeveledUp = true;
        }

        if (hasLeveledUp) {
            Object.assign(member, recalculateAllStats(member));
            member.health = member.maxHealth;
            member.mana = member.maxMana;
            newEvents.push({ description: `Sau khi đột phá tiểu cảnh giới lên ${member.cultivationStage} tầng ${member.cultivationLevel}, linh lực và khí huyết của ${member.name} đã hoàn toàn hồi phục.`, characterIds: [member.id] });

            if (member.cultivationStage === CultivationStage.QI_REFINEMENT && member.cultivationLevel === CULTIVATION_STAGES[CultivationStage.QI_REFINEMENT].levels) {
                 if ((clan.itemInventory['truc_co_dan'] || 0) > 0) {
                    clan.itemInventory['truc_co_dan'] -= 1;
                    member.inventory['truc_co_dan'] = (member.inventory['truc_co_dan'] || 0) + 1;
                    newEvents.push({ description: `${member.name} đã tu luyện đến Luyện Khí Đỉnh Phong, gia tộc ban thưởng một viên Trúc Cơ Đan để trợ giúp đột phá.`, characterIds: [member.id] });
                 }
            }
        }
        
        // Check for breakthrough to next stage
        if (member.cultivationLevel === currentState.levels) {
            const requiredExpForPeak = currentState.getExpForLevel(member.cultivationLevel);
            member.breakthroughSuccessChance = currentState.getBreakthroughSuccessChance(member, clan);
            if (member.cultivationProgress >= requiredExpForPeak && !member.isMeditatingForBreakthrough) {
                member.isMeditatingForBreakthrough = true;
                member.activity = CharacterActivity.SECLUDED;
                newEvents.push({ description: `${member.name} đã đạt đến đỉnh phong ${member.cultivationStage}, bắt đầu bế quan chuẩn bị đột phá.`, characterIds: [member.id] });
                continue;
            }
        } else {
            member.breakthroughSuccessChance = 0;
        }

        // --- Technique Mastery Progression (Automatic for equipped) ---
        const allEquippedTechIds = [
            member.techniques.mainCultivation,
            ...member.techniques.subCultivation,
            ...member.techniques.secretArts,
            ...member.techniques.spells,
        ].filter((id): id is string => !!id);

        const uniqueEquippedTechIds = [...new Set(allEquippedTechIds)];
        const cultivationTalentModifier = 1 + ((member.talents[TalentType.CULTIVATION] || 0) / 100);

        for (const techId of uniqueEquippedTechIds) {
            const progress = member.masteredTechniques[techId];
            if (!progress || progress.mastery === TechniqueMastery.VIEN_MAN) {
                continue;
            }

            const technique = ALL_TECHNIQUES[techId] as TechniqueItem | undefined;
            if (!technique) {
                continue;
            }

            const techniqueTier = technique.quality as ItemQuality;
            const expRequirements = MASTERY_EXP_REQUIREMENTS[techniqueTier];
            if (!expRequirements) {
                continue;
            }

            const expToNext = expRequirements[progress.mastery];
            if (expToNext === Infinity) {
                continue;
            }

            progress.exp += 1 * cultivationTalentModifier;

            if (progress.exp >= expToNext) {
                const masteryLevels = Object.values(TechniqueMastery);
                const currentLevelIndex = masteryLevels.indexOf(progress.mastery);
                if (currentLevelIndex < masteryLevels.length - 1) {
                    const newMastery = masteryLevels[currentLevelIndex + 1];
                    progress.mastery = newMastery;
                    progress.exp = 0; // Reset exp after leveling up
                    const techName = technique.name;
                    newEvents.push({
                        description: `Nhờ chăm chỉ tu hành, ${member.name} đã lĩnh ngộ "${techName}" đến cảnh giới ${newMastery}!`,
                        characterIds: [member.id]
                    });
                }
            }
        }
    }

    if (membersToAdd.length > 0) {
        clan.members.push(...membersToAdd);
    }

    return { updatedClan: clan, newEvents };
};