import type { Clan, Character, EquippableItem, TechniqueItem, Event, Building, MeritShopItem, GameDate, Talisman } from '../../types/index.ts';
import { ItemType, CultivationStage, EquipmentQuality, ItemQuality, TechniqueMastery, RelationshipClass, CharacterStatus, Gender, ProfessionType, TalentType } from '../../types/index.ts';
import { ALL_ITEMS, ALL_TECHNIQUES, TASKS, MARRIAGE_AGE_MIN, PREGNANCY_CHANCE_PER_MONTH, MAX_PREGNANCY_AGE, PREGNANCY_DURATION_MONTHS, MARRIAGE_CHANCE_PER_MONTH, BUILDINGS, ALL_RECIPES, CULTIVATION_TOWER_CONFIGS } from '../../constants.ts';
import { recalculateAllStats } from '../character.ts';
import { deepClone } from '../utils/clone.ts';
import * as meritShopActions from '../actions/meritShopActions.ts';
import * as taskActions from '../actions/taskActions.ts';
import { NeedType } from '../../types/index.ts';

type AutonomousActionResult = {
    updatedClan: Clan;
    events: Omit<Event, 'id' | 'date'>[];
} | null;

const TALENT_MAP: Partial<Record<TalentType, ProfessionType>> = {
    [TalentType.ALCHEMY]: ProfessionType.ALCHEMIST,
    [TalentType.BLACKSMITHING]: ProfessionType.BLACKSMITH,
    [TalentType.TALISMAN_MAKING]: ProfessionType.TALISMAN_MASTER,
    [TalentType.SPIRIT_FARMING]: ProfessionType.SPIRIT_FARMER,
    [TalentType.FORMATION_MAKING]: ProfessionType.FORMATION_MASTER,
};

const qualityToNumber = (item: { quality: ItemQuality, equipmentQuality: EquipmentQuality }): number => {
    const tierOrder = Object.values(ItemQuality);
    const qualityOrder = Object.values(EquipmentQuality);
    const tierValue = tierOrder.indexOf(item.quality) * 10;
    const qualityValue = qualityOrder.indexOf(item.equipmentQuality);
    return tierValue + qualityValue;
};

function autoEquipBestGear(character: Character): { updatedCharacter: Character, event: Omit<Event, 'id' | 'date'> } | null {
    for (const itemId in character.inventory) {
        if ((character.inventory[itemId] || 0) < 1) continue;

        const newItem = ALL_ITEMS[itemId];
        const isGear = newItem && 'equipmentQuality' in newItem && ![ItemType.CULTIVATION_METHOD, ItemType.SECRET_ART, ItemType.SPELL].includes(newItem.type);
        if (!isGear) continue;


        let slot: keyof Omit<Character['equipment'], 'belt'> | null = null;
        let slotName = '';

        switch(newItem.type) {
            case ItemType.WEAPON: slot = 'weapon'; slotName = 'Vũ Khí'; break;
            case ItemType.HELMET: slot = 'head'; slotName = 'Đầu'; break;
            case ItemType.CHESTPLATE: slot = 'chest'; slotName = 'Thân'; break;
            case ItemType.BOOTS: slot = 'feet'; slotName = 'Chân'; break;
            case ItemType.TALISMAN: 
                const acc1 = character.equipment.accessory1;
                const acc2 = character.equipment.accessory2;
                if (!acc1) { slot = 'accessory1'; }
                else if (!acc2) { slot = 'accessory2'; }
                else if (qualityToNumber(newItem) > qualityToNumber(acc1)) { slot = 'accessory1'; }
                else if (qualityToNumber(newItem) > qualityToNumber(acc2)) { slot = 'accessory2'; }
                slotName = 'Phụ Kiện';
                break;
        }

        if (slot) {
            const currentItem = character.equipment[slot];
            if (!currentItem || qualityToNumber(newItem) > qualityToNumber(currentItem)) {
                if (currentItem) {
                    character.inventory[currentItem.id] = (character.inventory[currentItem.id] || 0) + 1;
                }
                character.equipment[slot] = newItem as any;
                character.inventory[newItem.id] -= 1;
                
                const updatedCharacter = recalculateAllStats(character);
                const event = {
                    description: `Trong lúc rảnh rỗi, ${character.name} đã sắp xếp lại túi đồ và thay [${slotName}] bằng ${newItem.name}, cảm thấy thực lực tăng lên.`,
                    characterIds: [character.id]
                };
                return { updatedCharacter, event };
            }
        }
    }
    return null;
}

function autoBuyFromMeritShop(character: Character, clan: Clan): { updatedClan: Clan, event: Omit<Event, 'id' | 'date'> } | null {
    const hasEquipmentNeed = character.needs.some(n => n.type === NeedType.EQUIPMENT);
    if (!hasEquipmentNeed || (character.contribution || 0) < 10) {
        return null;
    }
    
    let bestAffordableUpgrade: { shopItem: MeritShopItem; upgradeValue: number } | null = null;

    for (const shopItem of clan.meritShop) {
        if (character.contribution < shopItem.cost) continue;

        const newItem = ALL_ITEMS[shopItem.itemId];
        if (!newItem || !('equipmentQuality' in newItem)) continue;
        
        let targetSlot: keyof Omit<Character['equipment'], 'belt'> | null = null;
        if (newItem.type === ItemType.WEAPON) targetSlot = 'weapon';
        else if (newItem.type === ItemType.CHESTPLATE) targetSlot = 'chest';
        else if (newItem.type === ItemType.HELMET) targetSlot = 'head';
        else if (newItem.type === ItemType.BOOTS) targetSlot = 'feet';
        else if (newItem.type === ItemType.TALISMAN) {
            const acc1 = character.equipment.accessory1;
            const acc2 = character.equipment.accessory2;
            if (!acc1) targetSlot = 'accessory1';
            else if (!acc2) targetSlot = 'accessory2';
            else if (qualityToNumber(acc1) < qualityToNumber(acc2)) targetSlot = 'accessory1';
            else targetSlot = 'accessory2';
        }

        if (targetSlot) {
            const currentItem = character.equipment[targetSlot];
            const newItemValue = qualityToNumber(newItem);
            const currentItemValue = currentItem ? qualityToNumber(currentItem) : -1;

            if (newItemValue > currentItemValue) {
                const upgradeValue = newItemValue - currentItemValue;
                if (!bestAffordableUpgrade || upgradeValue > bestAffordableUpgrade.upgradeValue) {
                    bestAffordableUpgrade = { shopItem, upgradeValue };
                }
            }
        }
    }
    
    if (bestAffordableUpgrade) {
        const result = meritShopActions.buyFromMeritShop(clan, character.id, bestAffordableUpgrade.shopItem);
        if (result.error || !result.updatedClan || !result.newEvents || result.newEvents.length === 0) {
            return null;
        }

        return {
            updatedClan: result.updatedClan,
            event: result.newEvents[0],
        };
    }

    return null;
}


function autoLearnTechnique(character: Character): { updatedCharacter: Character, event: Omit<Event, 'id' | 'date'> } | null {
    for (const itemId in character.inventory) {
        if ((character.inventory[itemId] || 0) < 1) continue;

        const technique = ALL_ITEMS[itemId] as TechniqueItem;
        if (!technique || (technique.type !== ItemType.CULTIVATION_METHOD && technique.type !== ItemType.SECRET_ART && technique.type !== ItemType.SPELL)) {
            continue;
        }

        if (character.learnedTechniques.includes(itemId) || character.professionTechniques.includes(itemId) || Object.values(character.techniques).flat().includes(itemId)) {
            continue;
        }

        const { cultivationStage, elements, comprehension, daoTam } = technique.requirements;
        const currentStageIndex = Object.values(CultivationStage).indexOf(character.cultivationStage);
        const requiredStageIndex = cultivationStage ? Object.values(CultivationStage).indexOf(cultivationStage) : -1;
        
        if (requiredStageIndex !== -1 && currentStageIndex < requiredStageIndex) continue;
        if (comprehension && character.comprehension < comprehension) continue;
        if (daoTam && character.daoTam < daoTam) continue;
        if (elements && !elements.some(e => character.spiritualRoot.elements.includes(e))) continue;

        character.inventory[itemId] -= 1;
        if(character.inventory[itemId] <= 0) delete character.inventory[itemId];
        
        if (technique.effects?.professionUnlock) {
            character.professionTechniques.push(itemId);
        } else {
            character.learnedTechniques.push(itemId);
        }
        character.masteredTechniques[itemId] = { mastery: TechniqueMastery.NHAP_MON, exp: 0 };

        const event = {
            description: `${character.name} trong lúc rảnh rỗi đã lấy bí tịch "${technique.name}" ra tham ngộ và lĩnh ngộ thành công.`,
            characterIds: [character.id]
        };
        return { updatedCharacter: character, event };
    }
    return null;
}

function autoEquipTechnique(character: Character): { updatedCharacter: Character, event: Omit<Event, 'id' | 'date'> } | null {
    for (const techId of [...character.learnedTechniques]) { // Create a copy to iterate over
        const technique = ALL_TECHNIQUES[techId] as TechniqueItem;
        if (!technique) continue;

        let equipped = false;
        
        if (technique.type === ItemType.CULTIVATION_METHOD) {
            if (character.techniques.mainCultivation === null) {
                character.techniques.mainCultivation = techId;
                equipped = true;
            }
        } else if (technique.type === ItemType.SECRET_ART) {
            const emptySlotIndex = character.techniques.secretArts.indexOf(null);
            if (emptySlotIndex !== -1) {
                character.techniques.secretArts[emptySlotIndex] = techId;
                equipped = true;
            }
        } else if (technique.type === ItemType.SPELL) {
            const emptySlotIndex = character.techniques.spells.indexOf(null);
            if (emptySlotIndex !== -1) {
                character.techniques.spells[emptySlotIndex] = techId;
                equipped = true;
            }
        }

        if (equipped) {
            character.learnedTechniques = character.learnedTechniques.filter(id => id !== techId);
            const event = {
                description: `Sau khi lĩnh ngộ, ${character.name} cảm thấy tâm đắc nên đã trang bị "${technique.name}" để sử dụng.`,
                characterIds: [character.id]
            };
            return { updatedCharacter: character, event };
        }
    }
    return null;
}

function autoUseLibraryToken(character: Character, clan: Clan): { updatedCharacter: Character, event: Omit<Event, 'id' | 'date'> } | null {
    const tokenKey = 'library_token_1';
    if ((character.inventory[tokenKey] || 0) < 1) {
        return null;
    }
    
    // For now, only check tier 1 library
    const libraryFloor = clan.library[ItemQuality.NHAT_GIAI];
    if (!libraryFloor) return null;

    const suitableTechniques = libraryFloor.filter((techId): techId is string => {
        if (!techId) return false;
        const technique = ALL_TECHNIQUES[techId] as TechniqueItem;
        if (!technique) return false;

        if (character.learnedTechniques.includes(techId) || character.professionTechniques.includes(techId) || Object.values(character.techniques).flat().includes(techId)) {
            return false;
        }

        const { cultivationStage, elements, comprehension, daoTam } = technique.requirements;
        const currentStageIndex = Object.values(CultivationStage).indexOf(character.cultivationStage);
        const requiredStageIndex = cultivationStage ? Object.values(CultivationStage).indexOf(cultivationStage) : -1;
        
        if (requiredStageIndex !== -1 && currentStageIndex < requiredStageIndex) return false;
        if (comprehension && character.comprehension < comprehension) return false;
        if (daoTam && character.daoTam < daoTam) return false;
        if (elements && !elements.some(e => character.spiritualRoot.elements.includes(e))) return false;

        return true;
    });

    if (suitableTechniques.length === 0) return null;

    const chosenTechId = suitableTechniques[Math.floor(Math.random() * suitableTechniques.length)];
    const chosenTechnique = ALL_TECHNIQUES[chosenTechId] as TechniqueItem;

    character.inventory[tokenKey]! -= 1;
    if (character.inventory[tokenKey] === 0) {
        delete character.inventory[tokenKey];
    }
    
    if (chosenTechnique.effects?.professionUnlock) {
        character.professionTechniques.push(chosenTechId);
    } else {
        character.learnedTechniques.push(chosenTechId);
    }
    character.masteredTechniques[chosenTechId] = { mastery: TechniqueMastery.NHAP_MON, exp: 0 };
    
    const event = {
        description: `${character.name} đã sử dụng Lệnh Bài, tiến vào Tàng Kinh Các Tầng 1 và lĩnh ngộ được "${chosenTechnique.name}"!`,
        characterIds: [character.id]
    };

    return { updatedCharacter: character, event };
}

function autoEnterCultivationTower(character: Character, clan: Clan): AutonomousActionResult | null {
    const tower = clan.buildings['tu_luyen_thap'];
    if (!tower || tower.level === 0 || character.cultivationTowerState) return null;

    if (Math.random() > 0.1) return null; // 10% chance per month to try

    const targetTier = (Object.entries(CULTIVATION_TOWER_CONFIGS).find(([, config]) => config.stage === character.cultivationStage)?.[0]) as ItemQuality | undefined;
    if (!targetTier) return null;
    
    const config = CULTIVATION_TOWER_CONFIGS[targetTier];
    
    // Check cost
    if (config.costType === 'contribution') {
        if ((character.contribution || 0) < config.cost) return null;
    } else {
        if ((character.inventory[config.costType] || 0) < config.cost) return null;
    }

    // Find available slot
    const availableSlot = tower.stations.find(s => s.tier === targetTier && s.workerId === null);
    if (!availableSlot) return null;

    const newClan = deepClone(clan);
    const charToUpdate = newClan.members.find(m => m.id === character.id)!;
    const towerToUpdate = newClan.buildings['tu_luyen_thap']!;
    const slotToUpdate = towerToUpdate.stations.find(s => s.id === availableSlot.id)!;
    
    let costText = '';
    // Deduct cost
    if (config.costType === 'contribution') {
        charToUpdate.contribution -= config.cost;
        costText = `${config.cost} điểm cống hiến`;
    } else {
        charToUpdate.inventory[config.costType] -= config.cost;
        if(charToUpdate.inventory[config.costType] <= 0) delete charToUpdate.inventory[config.costType];
        costText = `1 ${ALL_ITEMS[config.costType]?.name}`;
    }

    // Assign character
    charToUpdate.cultivationTowerState = { turnsRemaining: 1 };
    charToUpdate.assignedToBuildingId = tower.id;
    charToUpdate.assignedToSlotIndex = towerToUpdate.stations.findIndex(s => s.id === slotToUpdate.id);
    slotToUpdate.workerId = charToUpdate.id;
    
    const event = {
        description: `Cảm thấy tu vi đình trệ, ${character.name} đã dùng ${costText} để vào Tu Luyện Tháp tầng ${targetTier.split(' ')[0]} bế quan 1 tháng.`,
        characterIds: [character.id]
    };
    return { updatedClan: newClan, events: [event] };
}


function autoAcceptQuest(character: Character, clan: Clan, date: GameDate): { updatedClan: Clan, event: Omit<Event, 'id' | 'date'> } | null {
    if ((character.contribution || 0) >= 50) {
        return null;
    }
    if (clan.availableTasks.length === 0) {
        return null;
    }

    const suitableTasks = clan.availableTasks.filter(task => {
        if (task.requirements.minCultivationStage) {
            const currentStageIndex = Object.values(CultivationStage).indexOf(character.cultivationStage);
            const requiredStageIndex = Object.values(CultivationStage).indexOf(task.requirements.minCultivationStage);
            if (currentStageIndex < requiredStageIndex) {
                return false;
            }
        }
        if (task.requirements.requiredProfession) {
            const hasProfession = character.professions.some(p =>
                p.type === task.requirements.requiredProfession!.type &&
                Object.values(ItemQuality).indexOf(p.tier) >= Object.values(ItemQuality).indexOf(task.requirements.requiredProfession!.tier)
            );
            if (!hasProfession) {
                return false;
            }
        }
        if (task.requirements.partySize) {
            return false;
        }
        return true;
    });

    if (suitableTasks.length === 0) {
        return null;
    }

    const chosenTask = suitableTasks[Math.floor(Math.random() * suitableTasks.length)];

    // Use the existing action to assign the task
    const result = taskActions.assignTask(clan, [character.id], chosenTask.id, date);

    if (result.error || !result.updatedClan || !result.newEvents) {
        return null;
    }

    return {
        updatedClan: result.updatedClan,
        event: result.newEvents[0],
    };
}

function seekMaster(character: Character, clan: Clan): AutonomousActionResult {
    if (character.masterId || character.age > 25 || character.cultivationStage !== CultivationStage.QI_REFINEMENT) return null;
    if (Math.random() > 0.05) return null; // 5% chance per month

    const potentialMasters = clan.members.filter(m => 
        m.status === CharacterStatus.ALIVE &&
        m.id !== character.id &&
        Object.values(CultivationStage).indexOf(m.cultivationStage) > Object.values(CultivationStage).indexOf(character.cultivationStage) + 1 && // At least 2 stages higher
        (m.discipleIds || []).length < 3 // Max 3 disciples
    );
    if (potentialMasters.length === 0) return null;

    const master = potentialMasters[Math.floor(Math.random() * potentialMasters.length)];
    const newClan = deepClone(clan);
    const charToUpdate = newClan.members.find(m => m.id === character.id)!;
    const masterToUpdate = newClan.members.find(m => m.id === master.id)!;
    
    charToUpdate.masterId = masterToUpdate.id;
    if (!masterToUpdate.discipleIds) masterToUpdate.discipleIds = [];
    masterToUpdate.discipleIds.push(charToUpdate.id);

    charToUpdate.relationships.push({ class: RelationshipClass.MASTER, characterId: masterToUpdate.id, affinity: 60, description: `Bái ${masterToUpdate.name} làm sư phụ.` });
    masterToUpdate.relationships.push({ class: RelationshipClass.DISCIPLE, characterId: charToUpdate.id, affinity: 60, description: `Nhận ${charToUpdate.name} làm đệ tử.` });

    const event = {
        description: `Thấy ${charToUpdate.name} tư chất không tồi, ${masterToUpdate.name} đã nhận y làm đệ tử chân truyền.`,
        characterIds: [charToUpdate.id, masterToUpdate.id]
    };
    return { updatedClan: newClan, events: [event] };
}

function seekApprenticeship(character: Character, clan: Clan): AutonomousActionResult {
    if (character.professions.length > 0 || character.assignedToBuildingId) return null;
    if (Math.random() > 0.1) return null;

    const TALENT_THRESHOLD = 60;
    let bestTalent: TalentType | null = null;
    let maxTalentValue = 0;

    Object.values(TalentType).forEach(talent => {
        if (talent !== TalentType.CULTIVATION && talent !== TalentType.COMPREHENSION) {
            const value = character.talents[talent] || 0;
            if (value > maxTalentValue) {
                maxTalentValue = value;
                bestTalent = talent;
            }
        }
    });

    if (!bestTalent || maxTalentValue < TALENT_THRESHOLD) return null;

    const profType = TALENT_MAP[bestTalent];
    if (!profType) return null;

    const buildingId = Object.keys(BUILDINGS).find(id => BUILDINGS[id].profession === profType);
    if (!buildingId) return null;

    const building = clan.buildings[buildingId];
    if (!building || building.level === 0) return null;

    let emptyApprenticeSlotIndex: number | null = null;
    let emptyStationIndex: number | null = null;
    
    for (let i = 0; i < building.stations.length; i++) {
        const station = building.stations[i];
        const emptyIndex = station.apprenticeIds.indexOf(null);
        if (emptyIndex !== -1) {
            emptyStationIndex = i;
            emptyApprenticeSlotIndex = emptyIndex;
            break;
        }
    }

    if (emptyApprenticeSlotIndex === null || emptyStationIndex === null) return null;

    const newClan = deepClone(clan);
    const charToUpdate = newClan.members.find(m => m.id === character.id)!;
    const buildingToUpdate = newClan.buildings[buildingId]!;
    const stationToUpdate = buildingToUpdate.stations[emptyStationIndex];

    stationToUpdate.apprenticeIds[emptyApprenticeSlotIndex] = charToUpdate.id;
    charToUpdate.assignedToBuildingId = buildingId;
    charToUpdate.assignedToSlotIndex = emptyStationIndex;
    charToUpdate.assignedToSlotType = 'apprentice';
    
    const event = {
        description: `Thấy mình có thiên phú về ${profType}, ${character.name} đã chủ động xin vào ${building.name} để học việc.`,
        characterIds: [character.id]
    };

    return { updatedClan: newClan, events: [event] };
}

function tryToFormMarriage(character: Character, clan: Clan): AutonomousActionResult {
    if (character.age < MARRIAGE_AGE_MIN || Math.random() > 0.05) {
        return null;
    }
    const isMarried = character.relationships.some(r => r.class === RelationshipClass.SPOUSE);
    if (isMarried) return null;

    const existingRelationshipIds = character.relationships.map(r => r.characterId);
    existingRelationshipIds.push(character.id);

    const potentialPartners = clan.members.filter(m => 
        m.status === CharacterStatus.ALIVE &&
        m.id !== character.id && // Don't marry self
        m.gender !== character.gender &&
        m.age >= MARRIAGE_AGE_MIN &&
        !m.relationships.some(r => r.class === RelationshipClass.SPOUSE) &&
        !character.relationships.some(r => r.characterId === m.id && r.class === RelationshipClass.FAMILY_CLOSE) // Don't marry close family
    );
    if (potentialPartners.length === 0) return null;

    const partner = potentialPartners[Math.floor(Math.random() * potentialPartners.length)];
    
    if (Math.random() < MARRIAGE_CHANCE_PER_MONTH) {
        const newClan = deepClone(clan);
        const charToUpdate = newClan.members.find(m => m.id === character.id)!;
        const partnerToUpdate = newClan.members.find(m => m.id === partner.id)!;

        const marriageDesc = `Tình đầu ý hợp, tự nguyện kết thành đạo lữ.`;
        charToUpdate.relationships.push({ class: RelationshipClass.SPOUSE, characterId: partnerToUpdate.id, affinity: 70, description: marriageDesc });
        partnerToUpdate.relationships.push({ class: RelationshipClass.SPOUSE, characterId: charToUpdate.id, affinity: 70, description: marriageDesc });

        const event = {
            description: `Tình trong như đã, mặt ngoài còn e. ${charToUpdate.name} và ${partnerToUpdate.name} đã tự nguyện kết thành đạo lữ.`,
            characterIds: [charToUpdate.id, partnerToUpdate.id],
        };
        return { updatedClan: newClan, events: [event] };
    }
    return null;
}


function tryToConceive(character: Character, clan: Clan): AutonomousActionResult {
    if (character.gender !== Gender.FEMALE || character.pregnancy || character.age > MAX_PREGNANCY_AGE || character.age < MARRIAGE_AGE_MIN) {
        return null;
    }
    const spouseRel = character.relationships.find(r => r.class === RelationshipClass.SPOUSE);
    if (!spouseRel) return null;
    const spouse = clan.members.find(m => m.id === spouseRel.characterId);
    if (!spouse || spouse.status !== CharacterStatus.ALIVE) return null;
    
    if (Math.random() < PREGNANCY_CHANCE_PER_MONTH) {
        const newClan = deepClone(clan);
        const charToUpdate = newClan.members.find(m => m.id === character.id)!;
        charToUpdate.pregnancy = {
            partnerId: spouse.id,
            monthsRemaining: PREGNANCY_DURATION_MONTHS,
        };
        const event = {
            description: `Tin vui! ${character.name} đã mang trong mình giọt máu của gia tộc.`,
            characterIds: [character.id, spouse.id],
        };
        return { updatedClan: newClan, events: [event] };
    }
    return null;
}

function dualCultivation(character: Character, clan: Clan): AutonomousActionResult {
    const spouseRel = character.relationships.find(r => r.class === RelationshipClass.SPOUSE);
    if (!spouseRel) return null;
    if (Math.random() > 0.1) return null; // 10% chance

    const newClan = deepClone(clan);
    const charToUpdate = newClan.members.find(m => m.id === character.id)!;
    const spouse = newClan.members.find(m => m.id === spouseRel.characterId);
    
    if (!spouse || spouse.status !== CharacterStatus.ALIVE || spouse.isMeditatingForBreakthrough || spouse.activeTaskId || spouse.assignedToBuildingId) {
        return null;
    }

    const cultivationGain = 100 * (1 + Object.values(CultivationStage).indexOf(spouse.cultivationStage) * 0.1);
    charToUpdate.cultivationProgress += cultivationGain;
    spouse.cultivationProgress += cultivationGain;

    const charSpouseRel = charToUpdate.relationships.find(r => r.characterId === spouse.id);
    if(charSpouseRel) charSpouseRel.affinity = Math.min(100, charSpouseRel.affinity + 1);

    const spouseCharRel = spouse.relationships.find(r => r.characterId === charToUpdate.id);
    if (spouseCharRel) spouseCharRel.affinity = Math.min(100, spouseCharRel.affinity + 1);

    const event = {
        description: `Trời đêm tĩnh lặng, ${charToUpdate.name} và ${spouse.name} cùng nhau song tu, tu vi cả hai đều có chút tinh tiến.`,
        characterIds: [charToUpdate.id, spouse.id]
    };
    return { updatedClan: newClan, events: [event] };
}


export function performAutonomousActions(character: Character, clan: Clan, date: GameDate): AutonomousActionResult {
    let currentClan = deepClone(clan);
    let member = currentClan.members.find(m => m.id === character.id)!;
    const allEvents: Omit<Event, 'id' | 'date'>[] = [];
    let hasActed = false;

    if (Math.random() < 0.1) {
        return null;
    }

    const actionPipeline = [
        () => autoEnterCultivationTower(member, currentClan),
        () => seekApprenticeship(member, currentClan),
        () => tryToConceive(member, currentClan),
        () => autoBuyFromMeritShop(member, currentClan),
        () => autoEquipBestGear(member),
        () => autoUseLibraryToken(member, currentClan),
        () => autoLearnTechnique(member),
        () => autoEquipTechnique(member),
        () => seekMaster(member, currentClan),
        () => tryToFormMarriage(member, currentClan),
        () => dualCultivation(member, currentClan),
        () => autoAcceptQuest(member, currentClan, date),
    ];

    for (const action of actionPipeline) {
        if(hasActed) break; // Only one autonomous action per tick
        
        const result: any = action();
        if (result) {
            hasActed = true;
            if (result.event) {
                allEvents.push(result.event);
            }
            if (result.events) {
                allEvents.push(...result.events);
            }
            // If the action returned a whole new clan object, update our reference for the next action.
            if (result.updatedClan) {
                currentClan = result.updatedClan;
                member = currentClan.members.find(m => m.id === character.id)!;
            } 
            // If the action returned an updated character, update our reference.
            else if (result.updatedCharacter) {
                member = result.updatedCharacter;
            }
             // If the action returned an updated building
            if (result.updatedBuilding) {
                Object.assign(currentClan.buildings[result.updatedBuilding.id], result.updatedBuilding);
            }
        }
    }

    if (hasActed) {
        const memberIndex = currentClan.members.findIndex(m => m.id === member.id);
        if (memberIndex !== -1) {
            currentClan.members[memberIndex] = recalculateAllStats(member);
        }
        return { updatedClan: currentClan, events: allEvents };
    }
    
    return null;
}
