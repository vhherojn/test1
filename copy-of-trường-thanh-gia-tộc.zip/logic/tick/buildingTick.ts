
import type { Clan, GameDate, Event, Character, Profession } from '../../types/index.ts';
import { ProfessionType, RelationshipClass, TalentType, ItemQuality, EquipmentQuality } from '../../types/index.ts';
import { BUILDINGS, ALL_RECIPES, ALL_ITEMS, ALL_TECHNIQUES } from '../../constants.ts';
import { getNextTierAndQuality } from '../utils/clone.ts';


type BuildingTickResult = {
    updatedClan: Clan;
    newEvents: Omit<Event, 'id' | 'date'>[];
};

const addProfessionExp = (character: Character, profType: ProfessionType, amount: number): {leveledUp: boolean, newTier?: ItemQuality, newQuality?: EquipmentQuality} => {
    const prof = character.professions.find(p => p.type === profType);
    if (prof) {
        prof.exp += amount;
        
        const nextLevel = getNextTierAndQuality(prof.tier, prof.quality);
        if (prof.exp >= prof.expToNext && nextLevel) {
            prof.exp -= prof.expToNext;
            prof.tier = nextLevel.tier;
            prof.quality = nextLevel.quality;
            prof.expToNext = Math.floor(prof.expToNext * 1.5);
            return { leveledUp: true, newTier: prof.tier, newQuality: prof.quality };
        }
    }
    return { leveledUp: false };
};


export const processBuildingsTick = (clan: Clan, newDate: GameDate): BuildingTickResult => {
    const newEvents: Omit<Event, 'id' | 'date'>[] = [];

    for (const building of Object.values(clan.buildings)) {
        if (building.level === 0) continue;
        const buildingDef = BUILDINGS[building.id];

        // Handle Hunting Parties for Tran Yeu Duong
        if (building.id === 'tran_yeu_duong' && building.huntingAssignments) {
            for (const assignment of building.huntingAssignments) {
                const partyMembers = assignment.memberIds.map(id => id ? clan.members.find(m => m.id === id) : null).filter(Boolean) as Character[];
                if (partyMembers.length === 0) continue;

                const tierIndex = Object.values(ItemQuality).indexOf(assignment.tier);
                const totalCombatPower = partyMembers.reduce((sum, m) => sum + m.combatPower, 0);
                
                // Base 5% chance, plus bonus from combat power. 100k CP = +10%
                const lootChance = 0.05 + (totalCombatPower / 1000000);
                
                if (Math.random() < lootChance) {
                    const lootTable: {[key in ItemQuality]: {dan: string, cot: string, bi: string}} = {
                        [ItemQuality.NHAT_GIAI]: {dan: 'yeu_dan_nhat_giai', cot: 'yeu_cot_nhat_giai', bi: 'yeu_bi_nhat_giai'},
                        [ItemQuality.NHI_GIAI]: {dan: 'yeu_dan_nhi_giai', cot: 'yeu_cot_nhi_giai', bi: 'yeu_bi_nhi_giai'},
                        [ItemQuality.TAM_GIAI]: {dan: 'yeu_dan_tam_giai', cot: 'yeu_cot_tam_giai', bi: 'yeu_bi_tam_giai'},
                        [ItemQuality.TU_GIAI]: {dan: 'yeu_dan_tu_giai', cot: 'yeu_cot_tu_giai', bi: 'yeu_bi_tu_giai'},
                        [ItemQuality.NGU_GIAI]: {dan: 'yeu_dan_ngu_giai', cot: 'yeu_cot_ngu_giai', bi: 'yeu_bi_ngu_giai'},
                    };
                    
                    const tierLoot = lootTable[assignment.tier];
                    if (tierLoot) {
                        const itemsFound: Record<string, number> = {};
                        const lootAmount = Math.max(1, Math.floor(partyMembers.length / 2));
                        
                        itemsFound[tierLoot.dan] = (itemsFound[tierLoot.dan] || 0) + lootAmount;
                        itemsFound[tierLoot.cot] = (itemsFound[tierLoot.cot] || 0) + lootAmount;
                        itemsFound[tierLoot.bi] = (itemsFound[tierLoot.bi] || 0) + lootAmount;

                        let lootString = '';
                        for (const [itemId, count] of Object.entries(itemsFound)) {
                            clan.itemInventory[itemId] = (clan.itemInventory[itemId] || 0) + count;
                            lootString += `${count} ${ALL_ITEMS[itemId]?.name}, `;
                        }
                        lootString = lootString.slice(0, -2);
                        
                        const leaderName = partyMembers[0].name;
                        newEvents.push({ description: `Tổ đội của ${leaderName} đã săn giết thành công yêu thú ${assignment.tier}, thu được ${lootString}.` });
                        
                        partyMembers.forEach(member => {
                            member.contribution += (5 * (tierIndex + 1));
                            member.combatExp = (member.combatExp || 0) + (10 * (tierIndex + 1));
                        });
                    }
                }
            }
        }


        if (!building.stations) continue;

        for (const station of building.stations) {
            // Handle crafting progress
            if (station.isActive && station.activeRecipeId) {
                station.progress += 1;
                
                if (station.progress >= station.duration) {
                    const recipe = ALL_RECIPES[station.activeRecipeId];
                    if (!recipe) {
                        station.isActive = false;
                        continue;
                    }

                    const worker = station.workerId ? clan.members.find(m => m.id === station.workerId) : null;
                    
                    const craftedItem = ALL_ITEMS[recipe.itemId];
                    const amountToAdd = recipe.batchOutput ? (recipe.batchOutput.min + Math.floor(Math.random() * (recipe.batchOutput.max - recipe.batchOutput.min + 1))) : 1;
                    
                    clan.itemInventory[recipe.itemId] = (clan.itemInventory[recipe.itemId] || 0) + amountToAdd;
                    newEvents.push({ description: `Lò ${station.id.split('_').pop()} tại ${building.name} đã luyện chế thành công ${amountToAdd} ${craftedItem.name}.` });

                    if (worker && buildingDef?.profession) {
                        const profType = buildingDef.profession;
                        worker.contribution += (5 * Object.values(ItemQuality).indexOf(craftedItem.quality) + 5) * amountToAdd;
                        const { leveledUp, newTier, newQuality } = addProfessionExp(worker, profType, 20 * amountToAdd);
                        if (leveledUp) {
                            newEvents.push({ description: `${worker.name} đã thăng cấp ${profType} lên ${newTier} ${newQuality}!`, characterIds: [worker.id] });
                        }
                    }

                    // Reset station for next craft (if it's not a garden)
                    if (building.id !== 'herb_garden') {
                        station.isActive = false;
                        station.progress = 0;
                        station.activeRecipeId = null;
                        station.duration = 0;
                    } else {
                        // For herb garden, just reset progress for regrowth
                        station.progress = 0;
                    }
                }
            }

            // Handle apprenticeship progress
            if (buildingDef?.profession) {
                for (const apprenticeId of station.apprenticeIds) {
                    if (!apprenticeId) continue;
                    const apprentice = clan.members.find(m => m.id === apprenticeId)!;
                    const prof = apprentice.professions.find(p => p.type === buildingDef.profession);

                    if (prof?.apprenticeship) {
                        prof.apprenticeship.monthsRemaining--;

                        if (prof.apprenticeship.monthsRemaining <= 0) {
                            const oldTier = prof.tier;
                            prof.tier = prof.apprenticeship.targetTier;
                            prof.quality = EquipmentQuality.HA_PHAM;
                            prof.exp = 0;
                            prof.expToNext = 100 * Math.pow(5, Object.values(ItemQuality).indexOf(prof.tier));
                            prof.apprenticeship = undefined;

                            newEvents.push({
                                description: `Sau một thời gian học việc, ${apprentice.name} đã học nghệ thành công, chính thức trở thành ${prof.type} ${prof.tier}!`,
                                characterIds: [apprentice.id]
                            });
                        }
                    }
                }
            }
        }
    }

    return { updatedClan: clan, newEvents };
};
