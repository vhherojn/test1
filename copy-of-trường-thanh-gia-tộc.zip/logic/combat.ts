
import type { Character, BattleReport, BattleTurn, GameDate } from '../types/index.ts';
import { deepClone } from './utils/clone.ts';

// Add a type for combatants to track changing stats
interface Combatant extends Character {
    currentHealth: number;
    currentMana: number;
}

const calculateDodgeChance = (attacker: Combatant, defender: Combatant): number => {
    if (attacker.speed >= defender.speed) return 0.05; // Base 5% dodge chance even if slower
    const speedDiff = defender.speed - attacker.speed;
    // Dodge chance increases with speed difference, capped at 50%
    return Math.min(0.5, 0.05 + (speedDiff / defender.speed) * 0.45);
};

const calculateDamage = (baseDamage: number, critChance: number, critDamage: number): number => {
    let totalDamage = baseDamage;
    // Critical Hit
    if (Math.random() < critChance) {
        totalDamage *= critDamage;
    }
    // Add some randomness
    totalDamage *= (0.9 + Math.random() * 0.2); // 90% to 110% of final damage
    return Math.floor(totalDamage);
};


export function executeBattle(char1: Character, char2: Character, type: 'sparring' | 'life_and_death', date: GameDate): BattleReport {
    // Create copies of characters to modify stats during battle
    let combatant1: Combatant = { ...deepClone(char1), currentHealth: char1.health, currentMana: char1.mana };
    let combatant2: Combatant = { ...deepClone(char2), currentHealth: char2.health, currentMana: char2.mana };
    const log: BattleTurn[] = [];
    let turn = 0;

    log.push({ turnNumber: turn++, description: `Trận chiến giữa ${char1.name} và ${char2.name} bắt đầu!` });

    // Determine who goes first based on speed
    let attacker = combatant1.speed >= combatant2.speed ? combatant1 : combatant2;
    let defender = attacker.id === combatant1.id ? combatant2 : combatant1;

    while (combatant1.currentHealth > 0 && combatant2.currentHealth > 0 && turn < 50) { // turn limit to prevent infinite loops
        // Dodge check
        const dodgeChance = calculateDodgeChance(attacker, defender);
        if (Math.random() < dodgeChance) {
            log.push({ turnNumber: turn, description: `${defender.name} thân pháp nhanh nhẹn, né được đòn tấn công của ${attacker.name}!` });
        } else {
            const manaCost = attacker.maxMana * 0.15; // Magical attacks cost 15% of max mana
            
            // Prioritize magical attacks if enough mana
            if (attacker.currentMana >= manaCost) {
                attacker.currentMana -= manaCost;
                const baseDamage = Math.max(1, attacker.combatStats.magicalAttack - defender.combatStats.magicalDefense);
                const damage = calculateDamage(baseDamage, attacker.combatStats.critChance, attacker.combatStats.critDamage);
                defender.currentHealth -= damage;
                log.push({ turnNumber: turn, description: `${attacker.name} vận dụng linh lực, dùng pháp thuật tấn công, gây cho ${defender.name} ${damage} sát thương!` });
            } else {
                // Not enough mana, use physical attack and recover mana
                const baseDamage = Math.max(1, attacker.combatStats.physicalAttack - defender.combatStats.physicalDefense);
                const damage = calculateDamage(baseDamage, attacker.combatStats.critChance, attacker.combatStats.critDamage);
                defender.currentHealth -= damage;

                const manaRecovery = attacker.maxMana * 0.10; // Recover 10% mana
                attacker.currentMana = Math.min(attacker.maxMana, attacker.currentMana + manaRecovery);

                log.push({ turnNumber: turn, description: `${attacker.name} linh lực cạn kiệt, chuyển sang cận chiến, gây cho ${defender.name} ${damage} sát thương và hồi phục linh lực.` });
            }
        }
        
        // Swap roles for next turn
        [attacker, defender] = [defender, attacker];
        turn++;
    }

    let winnerId: string | null = null;
    if (combatant1.currentHealth <= 0) {
        winnerId = combatant2.id;
        log.push({ turnNumber: turn, description: `${combatant2.name} đã đánh bại ${combatant1.name}!` });
    } else if (combatant2.currentHealth <= 0) {
        winnerId = combatant1.id;
        log.push({ turnNumber: turn, description: `${combatant1.name} đã đánh bại ${combatant2.name}!` });
    } else {
        log.push({ turnNumber: turn, description: `Sau nhiều hiệp đấu, cả hai bất phân thắng bại, trận đấu kết thúc hòa!` });
    }

    return {
        id: crypto.randomUUID(),
        date,
        type,
        participants: [{ id: char1.id, name: char1.name }, { id: char2.id, name: char2.name }],
        winnerId,
        log
    };
}
