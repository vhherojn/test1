
import { ItemQuality } from '../types/index.ts';
import { Recipe } from '../types/index.ts';

// Import all item types from the new modular structure
import { MATERIALS } from './items/constants-materials.ts';
import { SEEDS } from './items/constants-seeds.ts';
import { PILLS } from './items/constants-pills.ts';
import { WEAPONS } from './items/constants-weapons.ts';
import { EQUIPMENT } from './items/constants-equipment.ts';
import { TALISMANS } from './items/constants-talismans.ts';
import { FORMATIONS } from './items/constants-formations.ts';
import { TOKENS } from './items/constants-tokens.ts';
import { CULTIVATION_METHODS } from './items/constants-cultivation-methods.ts';
import { SECRET_ARTS } from './items/constants-secret-arts.ts';
import { SPELLS } from './items/constants-spells.ts';

// Re-export them for easy access throughout the app
export { MATERIALS, SEEDS, PILLS, WEAPONS, EQUIPMENT, TALISMANS, FORMATIONS, TOKENS, CULTIVATION_METHODS, SECRET_ARTS, SPELLS };

// Consolidate all predefined items into single objects for easier lookup
export const PREDEFINED_RESOURCES = { ...MATERIALS };
export const PREDEFINED_PILLS = { ...PILLS };
export const PREDEFINED_EQUIPMENT = { ...WEAPONS, ...EQUIPMENT, ...TALISMANS };
export const PREDEFINED_TECHNIQUES = { ...CULTIVATION_METHODS, ...SECRET_ARTS, ...SPELLS };
export const PREDEFINED_SEEDS = { ...SEEDS };
export const PREDEFINED_TOKENS = { ...TOKENS };


export const ALL_ITEMS = { 
    ...PREDEFINED_RESOURCES, 
    ...PREDEFINED_PILLS, 
    ...PREDEFINED_EQUIPMENT, 
    ...PREDEFINED_TECHNIQUES,
    ...PREDEFINED_SEEDS,
    ...PREDEFINED_TOKENS,
};

export const RECIPES: Record<string, Recipe> = {
    'craft_tu_khi_dan': {
        id: 'craft_tu_khi_dan',
        name: 'Luyện chế Tụ Khí Đan',
        building: 'alchemist_room',
        requiredTier: ItemQuality.NHAT_GIAI,
        requiredProfessionTier: ItemQuality.NHAT_GIAI,
        cost: { 'nap_khi_thao': 3 },
        itemId: 'tu_khi_dan'
    },
    'craft_hoi_khi_dan': {
        id: 'craft_hoi_khi_dan',
        name: 'Luyện chế Hồi Khí Đan',
        building: 'alchemist_room',
        requiredTier: ItemQuality.NHAT_GIAI,
        requiredProfessionTier: ItemQuality.NHAT_GIAI,
        cost: { 'man_da_can': 2, 'nap_khi_thao': 1 },
        itemId: 'hoi_khi_dan'
    },
    'craft_truc_co_dan': {
        id: 'craft_truc_co_dan',
        name: 'Luyện chế Trúc Cơ Đan',
        building: 'alchemist_room',
        requiredTier: ItemQuality.NHI_GIAI,
        requiredProfessionTier: ItemQuality.NHI_GIAI,
        cost: { 'beast_core': 5, 'nap_khi_thao': 10 },
        itemId: 'truc_co_dan'
    },
    'craft_thiet_kiem': {
        id: 'craft_thiet_kiem',
        name: 'Rèn đúc Thiết Kiếm',
        building: 'blacksmith_forge',
        requiredTier: ItemQuality.NHAT_GIAI,
        requiredProfessionTier: ItemQuality.NHAT_GIAI,
        cost: { 'stone': 10, wood: 5 },
        itemId: 'thiet_kiem'
    },
     'craft_huyen_thiet_giap': {
        id: 'craft_huyen_thiet_giap',
        name: 'Rèn đúc Huyền Thiết Giáp',
        building: 'blacksmith_forge',
        requiredTier: ItemQuality.NHI_GIAI,
        requiredProfessionTier: ItemQuality.NHI_GIAI,
        cost: { 'stone': 250, 'beast_core': 2 },
        itemId: 'huyen_thiet_giap'
    },
    'craft_kim_quang_phu': {
        id: 'craft_kim_quang_phu',
        name: 'Chế tác Kim Quang Phù',
        building: 'talisman_house',
        requiredTier: ItemQuality.NHAT_GIAI,
        requiredProfessionTier: ItemQuality.NHAT_GIAI,
        cost: { 'wood': 5, 'spirit_stone': 5 },
        itemId: 'kim_quang_phu'
    },
    'craft_library_token_1': {
        id: 'craft_library_token_1',
        name: 'Chế tạo Lệnh Bài Tầng 1',
        building: 'blacksmith_forge',
        requiredTier: ItemQuality.NHAT_GIAI,
        requiredProfessionTier: ItemQuality.NHI_GIAI,
        cost: { 'stone': 50, 'spirit_stone': 200 },
        itemId: 'library_token_1'
    },
};
