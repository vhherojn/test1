import { ItemType, ItemQuality, EquipmentQuality, CultivationStage, Element } from "../types/index.ts";
import type { TechniqueItem } from '../types/index.ts';

export const SPELLS: { [id: string]: TechniqueItem } = {
    'kim_quang_quyet': {
        id: 'kim_quang_quyet',
        name: 'Kim Quang Quyết',
        type: ItemType.SPELL,
        quality: ItemQuality.NHAT_GIAI,
        equipmentQuality: EquipmentQuality.HA_PHAM,
        description: "Pháp quyết hệ Kim cơ bản, tạo ra một luồng kim quang sắc bén tấn công kẻ địch.",
        effects: { manaCost: 20, magicalAttackModifier: 1.2 }, // 20 mana cost, 120% magical attack
        requirements: {
            elements: [Element.METAL]
        }
    },
    'hoa_cau_thuong': {
        id: 'hoa_cau_thuong',
        name: 'Hỏa Cầu Thuật',
        type: ItemType.SPELL,
        quality: ItemQuality.NHAT_GIAI,
        equipmentQuality: EquipmentQuality.TRUNG_PHAM,
        description: "Pháp quyết hệ Hỏa sơ cấp, ngưng tụ một quả cầu lửa tấn công đối phương.",
        effects: { manaCost: 25, magicalAttackModifier: 1.3 },
        requirements: {
            elements: [Element.FIRE]
        }
    }
};