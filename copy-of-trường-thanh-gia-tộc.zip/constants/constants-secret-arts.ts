import { ItemType, ItemQuality, EquipmentQuality, CultivationStage, Element } from "../types/index.ts";
import type { TechniqueItem } from '../types/index.ts';

export const SECRET_ARTS: { [id: string]: TechniqueItem } = {
    'huyet_lau_chi_thuong': {
        id: 'huyet_lau_chi_thuong',
        name: 'Huyết Lão Chi Thuẫn',
        type: ItemType.SECRET_ART,
        quality: ItemQuality.NHI_GIAI,
        equipmentQuality: EquipmentQuality.TRUNG_PHAM,
        description: "Bí thuật phòng ngự, tiêu hao một lượng lớn khí huyết để tạo ra một tấm khiên máu chặn sát thương chí mạng.",
        effects: { healthCost: 0.2, temporaryDefense: 500 }, // 20% HP cost
        requirements: {
            cultivationStage: CultivationStage.FOUNDATION_ESTABLISHMENT
        }
    }
};