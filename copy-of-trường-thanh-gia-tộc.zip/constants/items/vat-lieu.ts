import { ItemQuality, ItemType, Resource } from '../../types/index.ts';

export const VAT_LIEU: { [key: string]: Resource } = {
    // Khoáng Thạch
    hac_thiet: { id: 'hac_thiet', name: 'Hắc Thiết', description: 'Kim loại Nhị Giai, cứng rắn và nặng.', quality: ItemQuality.NHI_GIAI, type: ItemType.MATERIAL, value: 15 },
    hoang_thiet: { id: 'hoang_thiet', name: 'Hoàng Thiết', description: 'Kim loại Tam Giai, có khả năng dung hợp linh khí Thổ.', quality: ItemQuality.TAM_GIAI, type: ItemType.MATERIAL, value: 50 },
    xich_dong: { id: 'xich_dong', name: 'Xích Đồng', description: 'Kim loại Tứ Giai, có khả năng dẫn nhiệt và linh khí Hỏa.', quality: ItemQuality.TU_GIAI, type: ItemType.MATERIAL, value: 200 },
    canh_kim: { id: 'canh_kim', name: 'Canh Kim', description: 'Kim loại Ngũ Giai cực kỳ sắc bén, tinh hoa của Kim thuộc tính.', quality: ItemQuality.NGU_GIAI, type: ItemType.MATERIAL, value: 1000 },

    // Yêu Thú - Yêu Đan
    yeu_dan_nhat_giai: { id: 'yeu_dan_nhat_giai', name: 'Yêu Đan Nhất Giai', description: 'Nội đan của yêu thú Nhất Giai.', quality: ItemQuality.NHAT_GIAI, type: ItemType.MATERIAL, value: 5 },
    yeu_dan_nhi_giai: { id: 'yeu_dan_nhi_giai', name: 'Yêu Đan Nhị Giai', description: 'Nội đan của yêu thú Nhị Giai.', quality: ItemQuality.NHI_GIAI, type: ItemType.MATERIAL, value: 25 },
    yeu_dan_tam_giai: { id: 'yeu_dan_tam_giai', name: 'Yêu Đan Tam Giai', description: 'Nội đan của yêu thú Tam Giai.', quality: ItemQuality.TAM_GIAI, type: ItemType.MATERIAL, value: 120 },
    yeu_dan_tu_giai: { id: 'yeu_dan_tu_giai', name: 'Yêu Đan Tứ Giai', description: 'Nội đan của yêu thú Tứ Giai.', quality: ItemQuality.TU_GIAI, type: ItemType.MATERIAL, value: 600 },
    yeu_dan_ngu_giai: { id: 'yeu_dan_ngu_giai', name: 'Yêu Đan Ngũ Giai', description: 'Nội đan của yêu thú Ngũ Giai.', quality: ItemQuality.NGU_GIAI, type: ItemType.MATERIAL, value: 3000 },

    // Yêu Thú - Yêu Cốt
    yeu_cot_nhat_giai: { id: 'yeu_cot_nhat_giai', name: 'Yêu Cốt Nhất Giai', description: 'Xương cốt của yêu thú Nhất Giai, dùng để luyện khí.', quality: ItemQuality.NHAT_GIAI, type: ItemType.MATERIAL, value: 2 },
    yeu_cot_nhi_giai: { id: 'yeu_cot_nhi_giai', name: 'Yêu Cốt Nhị Giai', description: 'Xương cốt của yêu thú Nhị Giai, dùng để luyện khí.', quality: ItemQuality.NHI_GIAI, type: ItemType.MATERIAL, value: 10 },
    yeu_cot_tam_giai: { id: 'yeu_cot_tam_giai', name: 'Yêu Cốt Tam Giai', description: 'Xương cốt của yêu thú Tam Giai, dùng để luyện khí.', quality: ItemQuality.TAM_GIAI, type: ItemType.MATERIAL, value: 40 },
    yeu_cot_tu_giai: { id: 'yeu_cot_tu_giai', name: 'Yêu Cốt Tứ Giai', description: 'Xương cốt của yêu thú Tứ Giai, dùng để luyện khí.', quality: ItemQuality.TU_GIAI, type: ItemType.MATERIAL, value: 180 },
    yeu_cot_ngu_giai: { id: 'yeu_cot_ngu_giai', name: 'Yêu Cốt Ngũ Giai', description: 'Xương cốt của yêu thú Ngũ Giai, dùng để luyện khí.', quality: ItemQuality.NGU_GIAI, type: ItemType.MATERIAL, value: 900 },

    // Yêu Thú - Yêu Bì
    yeu_bi_nhat_giai: { id: 'yeu_bi_nhat_giai', name: 'Yêu Bì Nhất Giai', description: 'Da của yêu thú Nhất Giai, dùng để chế phù.', quality: ItemQuality.NHAT_GIAI, type: ItemType.MATERIAL, value: 2 },
    yeu_bi_nhi_giai: { id: 'yeu_bi_nhi_giai', name: 'Yêu Bì Nhị Giai', description: 'Da của yêu thú Nhị Giai, dùng để chế phù.', quality: ItemQuality.NHI_GIAI, type: ItemType.MATERIAL, value: 10 },
    yeu_bi_tam_giai: { id: 'yeu_bi_tam_giai', name: 'Yêu Bì Tam Giai', description: 'Da của yêu thú Tam Giai, dùng để chế phù.', quality: ItemQuality.TAM_GIAI, type: ItemType.MATERIAL, value: 40 },
    yeu_bi_tu_giai: { id: 'yeu_bi_tu_giai', name: 'Yêu Bì Tứ Giai', description: 'Da của yêu thú Tứ Giai, dùng để chế phù.', quality: ItemQuality.TU_GIAI, type: ItemType.MATERIAL, value: 180 },
    yeu_bi_ngu_giai: { id: 'yeu_bi_ngu_giai', name: 'Yêu Bì Ngũ Giai', description: 'Da của yêu thú Ngũ Giai, dùng để chế phù.', quality: ItemQuality.NGU_GIAI, type: ItemType.MATERIAL, value: 900 },

    // Chế Phù - Chu Sa
    chu_sa_nhat_giai: { id: 'chu_sa_nhat_giai', name: 'Chu Sa Nhất Giai', description: 'Khoáng vật màu đỏ, dùng làm mực vẽ phù.', quality: ItemQuality.NHAT_GIAI, type: ItemType.MATERIAL, value: 3 },
    chu_sa_nhi_giai: { id: 'chu_sa_nhi_giai', name: 'Chu Sa Nhị Giai', description: 'Khoáng vật màu đỏ, dùng làm mực vẽ phù.', quality: ItemQuality.NHI_GIAI, type: ItemType.MATERIAL, value: 15 },
    chu_sa_tam_giai: { id: 'chu_sa_tam_giai', name: 'Chu Sa Tam Giai', description: 'Khoáng vật màu đỏ, dùng làm mực vẽ phù.', quality: ItemQuality.TAM_GIAI, type: ItemType.MATERIAL, value: 60 },
    chu_sa_tu_giai: { id: 'chu_sa_tu_giai', name: 'Chu Sa Tứ Giai', description: 'Khoáng vật màu đỏ, dùng làm mực vẽ phù.', quality: ItemQuality.TU_GIAI, type: ItemType.MATERIAL, value: 250 },
    chu_sa_ngu_giai: { id: 'chu_sa_ngu_giai', name: 'Chu Sa Ngũ Giai', description: 'Khoáng vật màu đỏ, dùng làm mực vẽ phù.', quality: ItemQuality.NGU_GIAI, type: ItemType.MATERIAL, value: 1200 },
};
