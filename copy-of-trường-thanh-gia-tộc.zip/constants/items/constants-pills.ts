import { ItemQuality, ItemType, Pill } from '../../types/index.ts';

export const PILLS: { [key: string]: Pill } = {
    hoi_nguyen_dan: {
        id: 'hoi_nguyen_dan',
        name: 'Hồi Nguyên Đan',
        description: 'Đan dược cấp thấp, giúp nhanh chóng hồi phục một lượng nhỏ linh lực.',
        quality: ItemQuality.NHAT_GIAI,
        type: ItemType.PILL,
        effects: { mana_recovery: 50 },
    },
    tu_luyen_dan: {
        id: 'tu_luyen_dan',
        name: 'Tụ Linh Tán',
        description: 'Tán dược giúp tu sĩ Luyện Khí Kỳ tăng nhanh tu vi.',
        quality: ItemQuality.NHAT_GIAI,
        type: ItemType.PILL,
        effects: { cultivation_progress_gain: 100 },
        impurity: 10,
    },
    tu_khi_dan: {
        id: 'tu_khi_dan',
        name: 'Tụ Khí Đan',
        description: 'Đan dược Nhất Giai, thành phẩm từ Nạp Khí Thảo, giúp tăng trưởng tu vi cho tu sĩ cấp thấp.',
        quality: ItemQuality.NHAT_GIAI,
        type: ItemType.PILL,
        effects: { cultivation_progress_gain: 120 },
        impurity: 8,
    },
    hoi_khi_dan: {
        id: 'hoi_khi_dan',
        name: 'Hồi Khí Đan',
        description: 'Đan dược Nhất Giai, thành phẩm từ Mạn Đà Căn, giúp hồi phục khí huyết sau khi bị thương.',
        quality: ItemQuality.NHAT_GIAI,
        type: ItemType.PILL,
        effects: { health_recovery: 80 },
    },
    truc_co_dan: {
        id: 'truc_co_dan',
        name: 'Trúc Cơ Đan',
        description: 'Đan dược tối quan trọng, giúp tu sĩ Luyện Khí Kỳ đỉnh phong có cơ hội Trúc Cơ thành công.',
        quality: ItemQuality.NHI_GIAI,
        type: ItemType.PILL,
        effects: {}, // The effect is handled by the breakthrough logic itself.
    },
};