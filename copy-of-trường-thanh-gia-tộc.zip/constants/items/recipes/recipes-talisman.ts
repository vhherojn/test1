import { ItemQuality } from '../../../types/index.ts';
import { Recipe } from '../../../types/index.ts';

export const TALISMAN_RECIPES: Record<string, Recipe> = {
    'craft_kim_quang_phu': {
        id: 'craft_kim_quang_phu',
        name: 'Chế tác Kim Quang Phù',
        building: 'talisman_house',
        requiredTier: ItemQuality.NHAT_GIAI,
        requiredProfessionTier: ItemQuality.NHAT_GIAI,
        cost: { 'yeu_bi_nhat_giai': 1, 'chu_sa_nhat_giai': 2 },
        itemId: 'kim_quang_phu',
    },
    'craft_loi_dinh_phu': {
        id: 'craft_loi_dinh_phu',
        name: 'Chế tác Lôi Đình Phù',
        building: 'talisman_house',
        requiredTier: ItemQuality.TAM_GIAI,
        requiredProfessionTier: ItemQuality.TAM_GIAI,
        cost: { 'yeu_bi_tam_giai': 1, 'chu_sa_tam_giai': 5, 'yeu_dan_tam_giai': 1 },
        itemId: 'loi_dinh_phu',
    },
};