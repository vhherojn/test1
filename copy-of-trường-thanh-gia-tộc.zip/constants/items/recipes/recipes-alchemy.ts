import { ItemQuality } from '../../../types/index.ts';
import { Recipe } from '../../../types/index.ts';

export const ALCHEMY_RECIPES: Record<string, Recipe> = {
    'craft_tu_khi_dan': {
        id: 'craft_tu_khi_dan',
        name: 'Luyện chế Tụ Khí Đan',
        building: 'alchemist_room',
        requiredTier: ItemQuality.NHAT_GIAI,
        requiredProfessionTier: ItemQuality.NHAT_GIAI,
        cost: { 'nap_khi_thao': 3 },
        itemId: 'tu_khi_dan',
        batchOutput: { min: 3, max: 6 },
    },
    'craft_hoi_khi_dan': {
        id: 'craft_hoi_khi_dan',
        name: 'Luyện chế Hồi Khí Đan',
        building: 'alchemist_room',
        requiredTier: ItemQuality.NHAT_GIAI,
        requiredProfessionTier: ItemQuality.NHAT_GIAI,
        cost: { 'man_da_can': 2, 'nap_khi_thao': 1 },
        itemId: 'hoi_khi_dan',
        batchOutput: { min: 3, max: 6 },
    },
    'craft_truc_co_dan': {
        id: 'craft_truc_co_dan',
        name: 'Luyện chế Trúc Cơ Đan',
        building: 'alchemist_room',
        requiredTier: ItemQuality.NHI_GIAI,
        requiredProfessionTier: ItemQuality.NHI_GIAI,
        cost: { 'yeu_dan_nhi_giai': 2, 'nap_khi_thao': 10 },
        itemId: 'truc_co_dan',
        batchOutput: { min: 1, max: 2 },
    },
};