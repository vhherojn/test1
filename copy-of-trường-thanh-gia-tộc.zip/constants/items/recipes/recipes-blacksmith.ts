import { ItemQuality } from '../../../types/index.ts';
import { Recipe } from '../../../types/index.ts';

export const BLACKSMITH_RECIPES: Record<string, Recipe> = {
    'craft_thiet_kiem': {
        id: 'craft_thiet_kiem',
        name: 'Rèn đúc Thiết Kiếm',
        building: 'blacksmith_forge',
        requiredTier: ItemQuality.NHAT_GIAI,
        requiredProfessionTier: ItemQuality.NHAT_GIAI,
        cost: { 'stone': 10, wood: 5 },
        itemId: 'thiet_kiem',
    },
     'craft_huyen_thiet_giap': {
        id: 'craft_huyen_thiet_giap',
        name: 'Rèn đúc Huyền Thiết Giáp',
        building: 'blacksmith_forge',
        requiredTier: ItemQuality.NHI_GIAI,
        requiredProfessionTier: ItemQuality.NHI_GIAI,
        cost: { 'stone': 250, 'yeu_dan_nhi_giai': 2 },
        itemId: 'huyen_thiet_giap',
    },
    'craft_hac_thiet_kiem': {
        id: 'craft_hac_thiet_kiem',
        name: 'Rèn đúc Hắc Thiết Kiếm',
        building: 'blacksmith_forge',
        requiredTier: ItemQuality.NHI_GIAI,
        requiredProfessionTier: ItemQuality.NHI_GIAI,
        cost: { 'hac_thiet': 5, 'yeu_cot_nhi_giai': 1 },
        itemId: 'hac_thiet_kiem',
    },
    'craft_hoang_thiet_giap': {
        id: 'craft_hoang_thiet_giap',
        name: 'Rèn đúc Hoàng Thiết Giáp',
        building: 'blacksmith_forge',
        requiredTier: ItemQuality.TAM_GIAI,
        requiredProfessionTier: ItemQuality.TAM_GIAI,
        cost: { 'hoang_thiet': 8, 'yeu_cot_tam_giai': 2 },
        itemId: 'hoang_thiet_giap',
    },
    'craft_library_token_1': {
        id: 'craft_library_token_1',
        name: 'Chế tạo Lệnh Bài Tầng 1',
        building: 'blacksmith_forge',
        requiredTier: ItemQuality.NHAT_GIAI,
        requiredProfessionTier: ItemQuality.NHI_GIAI,
        cost: { 'stone': 50, 'spirit_stone': 200 },
        itemId: 'library_token_1',
    },
};