
import { ItemQuality, ItemType } from '../../types/index.ts';
import type { Blueprint } from '../../types/index.ts';

export const BLUEPRINTS: { [key: string]: Blueprint } = {
    ban_ve_thiet_kiem: {
        id: 'ban_ve_thiet_kiem',
        name: 'Bản Vẽ: Thiết Kiếm',
        description: 'Bản vẽ chi tiết cách rèn đúc một thanh Thiết Kiếm cơ bản.',
        quality: ItemQuality.NHAT_GIAI,
        type: ItemType.BLUEPRINT,
        recipeId: 'craft_thiet_kiem'
    },
    ban_ve_huyen_thiet_giap: {
        id: 'ban_ve_huyen_thiet_giap',
        name: 'Bản Vẽ: Huyền Thiết Giáp',
        description: 'Bản vẽ chi tiết cách rèn đúc một bộ Huyền Thiết Giáp.',
        quality: ItemQuality.NHI_GIAI,
        type: ItemType.BLUEPRINT,
        recipeId: 'craft_huyen_thiet_giap'
    },
    ban_ve_hac_thiet_kiem: {
        id: 'ban_ve_hac_thiet_kiem',
        name: 'Bản Vẽ: Hắc Thiết Kiếm',
        description: 'Bản vẽ chi tiết cách rèn đúc một thanh Hắc Thiết Kiếm từ kim loại Nhị Giai.',
        quality: ItemQuality.NHI_GIAI,
        type: ItemType.BLUEPRINT,
        recipeId: 'craft_hac_thiet_kiem'
    },
    ban_ve_hoang_thiet_giap: {
        id: 'ban_ve_hoang_thiet_giap',
        name: 'Bản Vẽ: Hoàng Thiết Giáp',
        description: 'Bản vẽ chi tiết cách rèn đúc một bộ Hoàng Thiết Giáp từ kim loại Tam Giai.',
        quality: ItemQuality.TAM_GIAI,
        type: ItemType.BLUEPRINT,
        recipeId: 'craft_hoang_thiet_giap'
    },
};
