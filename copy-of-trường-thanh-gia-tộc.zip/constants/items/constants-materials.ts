
import { ItemQuality, ItemType, Resource } from '../../types/index.ts';

export const MATERIALS: { [key: string]: Resource } = {
    linh_khi: { id: 'linh_khi', name: 'Linh Khí', description: 'Năng lượng trời đất do Linh Mạch sản sinh, cần thiết cho việc tu luyện.', quality: ItemQuality.NHAT_GIAI, type: ItemType.RESOURCE, value: 0 },
    spirit_stone: { id: 'spirit_stone', name: 'Linh Thạch', description: 'Đơn vị tiền tệ cơ bản.', quality: ItemQuality.NHAT_GIAI, type: ItemType.RESOURCE, value: 1, },
    wood: { id: 'wood', name: 'Linh Mộc', description: 'Vật liệu xây dựng cơ bản.', quality: ItemQuality.NHAT_GIAI, type: ItemType.MATERIAL, value: 1, },
    stone: { id: 'stone', name: 'Linh Thạch Khoáng', description: 'Vật liệu xây dựng cơ bản.', quality: ItemQuality.NHAT_GIAI, type: ItemType.MATERIAL, value: 1, },
    spirit_herb: { id: 'spirit_herb', name: 'Linh Thảo', description: 'Dùng để luyện chế đan dược.', quality: ItemQuality.NHAT_GIAI, type: ItemType.HERB, value: 2, },
    nap_khi_thao: { id: 'nap_khi_thao', name: 'Nạp Khí Thảo', description: 'Linh thảo cơ bản, dùng để luyện chế Tụ Khí Đan.', quality: ItemQuality.NHAT_GIAI, type: ItemType.HERB, value: 3 },
    man_da_can: { id: 'man_da_can', name: 'Mạn Đà Căn', description: 'Linh thảo có độc tính nhẹ, dùng để luyện chế Hồi Khí Đan.', quality: ItemQuality.NHAT_GIAI, type: ItemType.HERB, value: 3 },
};
