
import { ItemQuality, EquipmentQuality, ItemType } from '../../types/index.ts';
import type { Talisman } from '../../types/index.ts';

export const TALISMANS: { [key: string]: Talisman } = {
    kim_quang_phu: {
        id: 'kim_quang_phu',
        name: 'Kim Quang Phù',
        description: 'Phù bảo sơ cấp, khi kích hoạt sẽ tạo một lớp khiên ánh sáng vàng bảo vệ, hấp thụ 100 sát thương. Tiêu hao sau khi dùng.',
        quality: ItemQuality.NHAT_GIAI,
        equipmentQuality: EquipmentQuality.TRUNG_PHAM,
        type: ItemType.TALISMAN,
        effects: { shield: 100 },
    },
    loi_dinh_phu: {
        id: 'loi_dinh_phu',
        name: 'Lôi Đình Phù',
        description: 'Phù bảo Tam Giai Thượng Phẩm, ẩn chứa một tia Lôi Đình chi lực, có thể gây ra 5000 sát thương Lôi. Tương đương một kích của Kết Đan hậu kỳ. Tiêu hao sau khi dùng.',
        quality: ItemQuality.TAM_GIAI,
        equipmentQuality: EquipmentQuality.THUONG_PHAM,
        type: ItemType.TALISMAN,
        effects: { damage: 5000 },
    }
};