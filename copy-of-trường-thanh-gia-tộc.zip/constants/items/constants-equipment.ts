
import { ItemQuality, EquipmentQuality, ItemType, Element, CultivationStage } from '../../types/index.ts';
import type { EquippableItem } from '../../types/index.ts';

export const EQUIPMENT: { [key: string]: EquippableItem } = {
    // ========== NHẤT GIAI ==========
    'da_thu_giap': {
        id: 'da_thu_giap',
        name: 'Da Thú Giáp',
        description: 'Áo giáp làm từ da của mãnh thú, cung cấp một chút phòng ngự cơ bản.',
        quality: ItemQuality.NHAT_GIAI,
        equipmentQuality: EquipmentQuality.HA_PHAM,
        type: ItemType.CHESTPLATE,
        effects: { physicalDefense: 25, magicalDefense: 10 },
    },
    'truong_sinh_phu': {
        id: 'truong_sinh_phu',
        name: 'Trường Sinh Phù (Trang Bị)',
        description: 'Một lá bùa bình an, nghe đồn có thể tăng một chút tuổi thọ cho người đeo.',
        quality: ItemQuality.NHAT_GIAI,
        equipmentQuality: EquipmentQuality.TRUNG_PHAM,
        type: ItemType.CHESTPLATE, // Placeholder type, should be accessory
        effects: { maxHealth: 50 },
    },

    // ========== NHỊ GIAI ==========
    'huyen_thiet_giap': {
        id: 'huyen_thiet_giap',
        name: 'Huyền Thiết Giáp',
        description: 'Bộ giáp nặng làm từ huyền thiết, phòng ngự vật lý cực cao nhưng làm giảm tốc độ.',
        quality: ItemQuality.NHI_GIAI,
        equipmentQuality: EquipmentQuality.TRUNG_PHAM,
        type: ItemType.CHESTPLATE,
        effects: { physicalDefense: 600, magicalDefense: 250, speed: -5 },
        requiredCultivation: CultivationStage.FOUNDATION_ESTABLISHMENT,
    },
    'thuy_van_phap_bao': {
        id: 'thuy_van_phap_bao',
        name: 'Thủy Vân Pháp Bào',
        description: 'Pháp bào được dệt từ tơ của Băng Tằm, phòng ngự ma pháp tốt và tăng tốc độ hồi phục linh lực.',
        quality: ItemQuality.NHI_GIAI,
        equipmentQuality: EquipmentQuality.THUONG_PHAM,
        type: ItemType.CHESTPLATE,
        effects: { physicalDefense: 250, magicalDefense: 550, manaRecoveryRate: 1.1 },
        elements: [Element.WATER, Element.ICE],
        requiredCultivation: CultivationStage.FOUNDATION_ESTABLISHMENT,
    },

    // ========== TAM GIAI ==========
    'hoang_thiet_giap': {
        id: 'hoang_thiet_giap',
        name: 'Hoàng Thiết Giáp',
        description: 'Bộ giáp được rèn từ Hoàng Thiết, hấp thụ linh khí Thổ, phòng ngự toàn diện, vững như bàn thạch.',
        quality: ItemQuality.TAM_GIAI,
        equipmentQuality: EquipmentQuality.TRUNG_PHAM,
        type: ItemType.CHESTPLATE,
        effects: { physicalDefense: 3000, magicalDefense: 2500 },
        requiredCultivation: CultivationStage.CORE_FORMATION,
    },
};
