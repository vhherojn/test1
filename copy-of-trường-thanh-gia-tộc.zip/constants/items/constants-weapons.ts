
import { ItemQuality, EquipmentQuality, ItemType, Element, CultivationStage, WeaponType } from '../../types/index.ts';
import type { EquippableItem } from '../../types/index.ts';

export const WEAPONS: { [key: string]: EquippableItem } = {
    // ========== NHẤT GIAI ==========
    'thiet_kiem': {
        id: 'thiet_kiem',
        name: 'Thiết Kiếm',
        description: 'Một thanh kiếm sắt bình thường, phù hợp cho tu sĩ cấp thấp.',
        quality: ItemQuality.NHAT_GIAI,
        type: ItemType.WEAPON,
        equipmentQuality: EquipmentQuality.HA_PHAM,
        weaponType: WeaponType.PHAP_KHI,
        effects: { physicalAttack: 20 },
    },
    'thiet_dao': {
        id: 'thiet_dao',
        name: 'Thiết Đao',
        description: 'Một thanh đao sắt, nặng hơn kiếm, uy lực mạnh hơn nhưng tốc độ chậm hơn.',
        quality: ItemQuality.NHAT_GIAI,
        type: ItemType.WEAPON,
        equipmentQuality: EquipmentQuality.TRUNG_PHAM,
        weaponType: WeaponType.PHAP_KHI,
        effects: { physicalAttack: 30, speed: -2 },
    },

    // ========== NHỊ GIAI ==========
    'hac_thiet_kiem': {
        id: 'hac_thiet_kiem',
        name: 'Hắc Thiết Kiếm',
        description: 'Kiếm được rèn từ Hắc Thiết, vô cùng cứng rắn và nặng nề, phù hợp để cận chiến.',
        quality: ItemQuality.NHI_GIAI,
        type: ItemType.WEAPON,
        equipmentQuality: EquipmentQuality.TRUNG_PHAM,
        weaponType: WeaponType.PHAP_KHI,
        effects: { physicalAttack: 450, physicalDefense: 50, speed: -3 },
        requiredCultivation: CultivationStage.FOUNDATION_ESTABLISHMENT,
    },
     'tinh_van_phien': {
        id: 'tinh_van_phien',
        name: 'Tinh Vân Phiến',
        description: 'Một chiếc quạt pháp khí, có thể phóng ra cương phong, vừa có thể tấn công vừa có thể phòng thủ.',
        quality: ItemQuality.NHI_GIAI,
        type: ItemType.WEAPON,
        equipmentQuality: EquipmentQuality.THUONG_PHAM,
        weaponType: WeaponType.PHAP_KHI,
        effects: { magicalAttack: 400, speed: 10 },
        elements: [Element.WIND],
        requiredCultivation: CultivationStage.FOUNDATION_ESTABLISHMENT,
    },

    // ========== TAM GIAI ==========
    'thanh_truc_phong_van_kiem': {
        id: 'thanh_truc_phong_van_kiem',
        name: 'Thanh Trúc Phong Vân Kiếm',
        description: 'Một thanh phi kiếm được luyện chế từ Thanh Lôi Trúc ngàn năm, ẩn chứa sức mạnh của Mộc và Lôi.',
        quality: ItemQuality.TAM_GIAI,
        equipmentQuality: EquipmentQuality.HA_PHAM,
        type: ItemType.WEAPON,
        weaponType: WeaponType.PHAP_KHI,
        effects: { physicalAttack: 600, magicalAttack: 1800 },
        elements: [Element.WOOD, Element.LIGHTNING],
        requiredCultivation: CultivationStage.CORE_FORMATION,
        history: 'Được luyện chế từ ngàn năm "Thanh Lôi trúc", 20 năm dùng lục dịch thúc chín, tổng cộng thúc chín được 6 cây. (Trích Phàm Nhân Tu Tiên truyện)'
    },
    'phan_hon_chuyen': {
        id: 'phan_hon_chuyen',
        name: 'Phệ Hồn Châm',
        description: 'Một bộ kim châm độc địa, chuyên dùng để tấn công nguyên thần của đối phương, vô cùng âm hiểm.',
        quality: ItemQuality.TAM_GIAI,
        equipmentQuality: EquipmentQuality.THUONG_PHAM,
        type: ItemType.WEAPON,
        weaponType: WeaponType.PHAP_KHI,
        effects: { magicalAttack: 2500, critChance: 0.15 },
        requiredCultivation: CultivationStage.CORE_FORMATION,
    },
};
