
import { ItemType, ItemQuality, EquipmentQuality, CultivationStage } from "../../../types/index.ts";
import type { TechniqueItem } from '../../../types/index.ts';

export const NGU_GIAI_CONG_PHAP: { [id: string]: TechniqueItem } = {
    'hon_don_thien_dao_quyet': {
        id: 'hon_don_thien_dao_quyet',
        name: 'Hỗn Độn Thiên Đạo Quyết',
        type: ItemType.CULTIVATION_METHOD,
        quality: ItemQuality.NGU_GIAI,
        equipmentQuality: EquipmentQuality.THUONG_PHAM,
        description: "Công pháp trong truyền thuyết, có nguồn gốc từ khí Hỗn Độn sơ khai, có thể tu luyện mọi loại linh khí, vạn pháp quy nhất.",
        effects: { cultivationSpeedModifier: 1.8, physicalAttack: 10000, magicalAttack: 10000, physicalDefense: 5000, magicalDefense: 5000 },
        requirements: {
            comprehension: 98,
            cultivationStage: CultivationStage.SOUL_FORMATION,
        }
    },
};
