
import { TechniqueMastery, ItemQuality } from "../types/index.ts";

export const TECHNIQUE_MASTERY_DATA: Record<TechniqueMastery, { name: string; effectMultiplier: number; costMultiplier: number; }> = {
    [TechniqueMastery.NHAP_MON]: {
        name: 'Nhập Môn',
        effectMultiplier: 1.0,
        costMultiplier: 1.0,
    },
    [TechniqueMastery.TIEU_THANH]: {
        name: 'Tiểu Thành',
        effectMultiplier: 1.0,
        costMultiplier: 0.85, // 15% cost reduction
    },
    [TechniqueMastery.DAI_THANH]: {
        name: 'Đại Thành',
        effectMultiplier: 1.25, // 25% effect increase
        costMultiplier: 0.85,
    },
    [TechniqueMastery.VIEN_MAN]: {
        name: 'Viên Mãn',
        effectMultiplier: 1.5, // Total 50% effect increase
        costMultiplier: 0.6, // Total 40% cost reduction
    },
};

export const MASTERY_EXP_REQUIREMENTS: Record<ItemQuality, Record<TechniqueMastery, number>> = {
    [ItemQuality.NHAT_GIAI]: {
        [TechniqueMastery.NHAP_MON]: 6,    // to Tieu Thanh
        [TechniqueMastery.TIEU_THANH]: 12,   // to Dai Thanh
        [TechniqueMastery.DAI_THANH]: 24,   // to Vien Man
        [TechniqueMastery.VIEN_MAN]: Infinity,
    },
    [ItemQuality.NHI_GIAI]: {
        [TechniqueMastery.NHAP_MON]: 12,
        [TechniqueMastery.TIEU_THANH]: 24,
        [TechniqueMastery.DAI_THANH]: 48,
        [TechniqueMastery.VIEN_MAN]: Infinity,
    },
    [ItemQuality.TAM_GIAI]: {
        [TechniqueMastery.NHAP_MON]: 48,
        [TechniqueMastery.TIEU_THANH]: 96,
        [TechniqueMastery.DAI_THANH]: 192,
        [TechniqueMastery.VIEN_MAN]: Infinity,
    },
    [ItemQuality.TU_GIAI]: {
        [TechniqueMastery.NHAP_MON]: 600,
        [TechniqueMastery.TIEU_THANH]: 1200,
        [TechniqueMastery.DAI_THANH]: 2400,
        [TechniqueMastery.VIEN_MAN]: Infinity,
    },
    [ItemQuality.NGU_GIAI]: {
        [TechniqueMastery.NHAP_MON]: 1200,
        [TechniqueMastery.TIEU_THANH]: 2400,
        [TechniqueMastery.DAI_THANH]: 4800,
        [TechniqueMastery.VIEN_MAN]: Infinity,
    },
};
