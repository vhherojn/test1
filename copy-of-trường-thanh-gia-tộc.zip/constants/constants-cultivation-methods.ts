
import { ItemType, ItemQuality, EquipmentQuality, CultivationStage, ProfessionType } from "../types/index.ts";
import type { TechniqueItem } from '../types/index.ts';

export const CULTIVATION_METHODS: { [id: string]: TechniqueItem } = {
    'truong_xuan_cong': {
        id: 'truong_xuan_cong',
        name: 'Trường Xuân Công',
        type: ItemType.CULTIVATION_METHOD,
        quality: ItemQuality.NHAT_GIAI,
        equipmentQuality: EquipmentQuality.TRUNG_PHAM,
        description: "Công pháp dưỡng sinh phổ biến, giúp khí huyết dồi dào, tu luyện ổn định, tăng nhẹ tuổi thọ.",
        effects: { cultivationSpeedModifier: 1.05, healthModifier: 1.05 },
        requirements: {}
    },
    'nguyen_khi_quyet': {
        id: 'nguyen_khi_quyet',
        name: 'Nguyên Khí Quyết',
        type: ItemType.CULTIVATION_METHOD,
        quality: ItemQuality.NHI_GIAI,
        equipmentQuality: EquipmentQuality.HA_PHAM,
        description: "Công pháp cơ bản giúp dẫn khí nhập thể, nền tảng cho mọi tu sĩ.",
        effects: { cultivationSpeedModifier: 1.1 },
        requirements: {
            cultivationStage: CultivationStage.QI_REFINEMENT
        }
    },
    'luyen_dan_co_so': {
        id: 'luyen_dan_co_so',
        name: 'Luyện Đan Cơ Sở',
        type: ItemType.SECRET_ART,
        quality: ItemQuality.NHAT_GIAI,
        equipmentQuality: EquipmentQuality.HA_PHAM,
        description: "Ghi lại những kiến thức nhập môn về dược lý và đan hỏa, là chìa khóa để trở thành Luyện Đan Sư.",
        effects: { professionUnlock: ProfessionType.ALCHEMIST },
        requirements: {}
    },
    'luyen_khi_nhap_mon': {
        id: 'luyen_khi_nhap_mon',
        name: 'Luyện Khí Nhập Môn',
        type: ItemType.SECRET_ART,
        quality: ItemQuality.NHAT_GIAI,
        equipmentQuality: EquipmentQuality.HA_PHAM,
        description: "Kiến thức vỡ lòng về các loại linh khoáng và cách thức rèn đúc pháp khí.",
        effects: { professionUnlock: ProfessionType.BLACKSMITH },
        requirements: {}
    },
    'luyen_phu_nhap_mon': {
        id: 'luyen_phu_nhap_mon',
        name: 'Luyện Phù Nhập Môn',
        type: ItemType.SECRET_ART,
        quality: ItemQuality.NHAT_GIAI,
        equipmentQuality: EquipmentQuality.HA_PHAM,
        description: "Dạy cách dẫn linh khí vào giấy bút, vẽ nên những đạo phù cơ bản nhất.",
        effects: { professionUnlock: ProfessionType.TALISMAN_MASTER },
        requirements: {}
    },
};