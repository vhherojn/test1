
import type { Location } from './types/index.ts';

export const PREDEFINED_LOCATIONS: Location[] = [
    { id: 'ancestral_land', name: 'Thanh Vân Sơn', x: 18, y: 50, isAncestral: true, prefab: 'mountains' },
    { id: 'loc_1', name: 'Lạc Nhật Thành', x: 25, y: 70, prefab: 'city' },
    { id: 'loc_2', name: 'Vạn Kiếm Cốc', x: 40, y: 60, prefab: 'ruins' },
    { id: 'loc_3', name: 'Hắc Ám Sâm Lâm', x: 65, y: 45, prefab: 'forest' },
    { id: 'loc_4', name: 'Thiên Ma Điện', x: 55, y: 85, prefab: 'palace' },
    { id: 'loc_5', name: 'Tinh Tú Hải', x: 75, y: 75, prefab: 'city' },
    { id: 'loc_6', name: 'Vô Cực Tông Phế Tích', x: 60, y: 30, prefab: 'ruins' },
    { id: 'loc_7', name: 'Linh Hư Sơn Mạch', x: 50, y: 15, prefab: 'mountains' },
    { id: 'loc_8', name: 'Thái Cực Môn', x: 40, y: 25, prefab: 'palace' },
];
