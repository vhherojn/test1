
import React, { useState, useMemo } from 'react';
import type { AnyItem } from '../types/index.ts';
import { ItemType, ItemQuality, PhysiqueTier } from '../types/index.ts';
import { CloseIcon, SecretRecordsIcon } from './Icons.tsx';
import { ALL_ITEMS, ITEM_QUALITY_COLORS, PHYSIQUES, CULTIVATION_STAGES, BUILDINGS, PHYSIQUE_TIER_COLORS, COMBAT_STAT_TRANSLATIONS } from '../constants.ts';
import ItemTooltip from './common/ItemTooltip.tsx';

interface SecretRecordsModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const TabButton: React.FC<{label: string, isActive: boolean, onClick: () => void}> = ({ label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`px-4 py-2 font-bold text-base transition-all duration-200 border-b-2 ${
            isActive ? 'text-amber-300 border-amber-300' : 'text-amber-200/60 hover:bg-black/20 border-transparent'
        }`}
    >
        {label}
    </button>
);

// =================================================================
//                 GUIDE CONTENT COMPONENTS
// =================================================================

const GuideSection: React.FC<{title: string, children: React.ReactNode}> = ({ title, children }) => (
    <div>
        <h4 className="font-bold text-amber-200 text-lg mb-2">{title}</h4>
        <div className="space-y-3 text-gray-300 text-sm leading-relaxed">{children}</div>
    </div>
);

const GuideIntroContent: React.FC = () => (
    <div className="space-y-4">
        <GuideSection title="Lời Mở Đầu">
            <p>Chào mừng Đạo hữu đã đến với thế giới tu tiên. Tại đây, ngươi sẽ gánh vác trọng trách dẫn dắt một gia tộc, từ những bước đi đầu tiên cho đến khi trở thành một thế lực hùng bá một phương. Con đường này đầy rẫy chông gai, đòi hỏi sự kiên nhẫn và quyết sách anh minh.</p>
        </GuideSection>
        <GuideSection title="Linh Căn & Thể Chất">
            <p>Linh căn là yếu tố quyết định thiên phú tu tiên. Linh căn càng ít thuộc tính (như Thiên Linh Căn - 1 thuộc tính) thì tốc độ tu luyện càng nhanh. Ngược lại, linh căn càng nhiều thuộc tính (Ngũ Hành Linh Căn - 5 thuộc tính) thì tu luyện càng khó khăn và chậm chạp hơn do sự xung khắc và khó khăn trong việc chuyển hóa linh khí.</p>
            <p>Thể chất là một loại thiên phú đặc biệt, mang lại các hiệu ứng mạnh mẽ như tăng tốc độ tu luyện, tăng mạnh khí huyết, hoặc thậm chí là miễn nhiễm độc tố.</p>
        </GuideSection>
        <GuideSection title="Tộc Nhân Tự Chủ">
            <p>Khi rảnh rỗi, các tộc nhân sẽ có những hành động tự chủ. Họ sẽ tự tìm trang bị tốt hơn, tự học công pháp trong túi đồ, và quan trọng nhất: tự dùng <span className="text-yellow-300 font-semibold">Lệnh Bài Tàng Kinh Các</span> để vào thư viện học tập. Hãy ban thưởng cho những tộc nhân có cống hiến để họ tự mình mạnh lên!</p>
            <p>Khi cảm thấy yếu kém, họ sẽ tự đến Huân Công Đường dùng điểm cống hiến để đổi vật phẩm. Khi thiếu điểm cống hiến, họ sẽ tự đến Sự Vụ Đường nhận nhiệm vụ.</p>
        </GuideSection>
    </div>
);

const GuideRealmsContent: React.FC = () => (
    <div className="space-y-4">
        <GuideSection title="Tổng Quan về Cảnh Giới">
            <p>Cảnh giới là thước đo sức mạnh tuyệt đối trong thế giới tu tiên. Mỗi một đại cảnh giới là một trời một vực, không thể dễ dàng vượt qua.</p>
        </GuideSection>
        <GuideSection title="Luyện Khí Kỳ">
            <p>Đây là cảnh giới nhập môn, mục tiêu chính là "dẫn khí nhập thể", cảm nhận linh khí và tích lũy nó trong đan điền. Tu sĩ Luyện Khí Kỳ có tuổi thọ cao hơn người thường một chút nhưng vẫn còn rất yếu đuối.</p>
            <p className="font-semibold text-red-400">Lưu ý: Nếu qua 65 tuổi mà vẫn không đột phá Trúc Cơ, khí huyết sẽ suy bại, tiên lộ gần như đoạn tuyệt, không thể tu luyện tiếp.</p>
            <p><span className="font-semibold text-yellow-300">Đột phá Trúc Cơ:</span> Đây là cửa ải đầu tiên trên con đường tu tiên. Thất bại là chuyện thường tình. Cần có <span className="font-semibold text-green-300">Trúc Cơ Đan</span> để tăng tỉ lệ thành công. Mỗi lần thất bại sẽ bị trọng thương, cần thời gian hồi phục.</p>
        </GuideSection>
        <GuideSection title="Trúc Cơ Kỳ">
            <p>Sau khi Trúc Cơ, linh khí trong cơ thể sẽ được nén lại thành dịch, sức mạnh và tuổi thọ tăng vọt, chính thức thoát khỏi vòng sinh lão bệnh tử của phàm nhân. Tu sĩ Trúc Cơ đã có thể sử dụng các pháp khí cao cấp và thi triển pháp thuật mạnh mẽ hơn.</p>
             <p><span className="font-semibold text-yellow-300">Đột phá Kết Đan:</span> Yêu cầu linh lực phải tích lũy đến cực hạn, là một quá trình nén linh dịch thành một viên Kim Đan rắn chắc. Tỉ lệ thành công phụ thuộc vào căn cơ, đạo tâm và khí vận.</p>
        </GuideSection>
        <GuideSection title="Kết Đan Kỳ & Nguyên Anh Kỳ">
            <p>Kết Đan và Nguyên Anh là hai đại cảnh giới cực kỳ quan trọng, đánh dấu một tu sĩ đã có chỗ đứng trong thế giới tu tiên. Sức mạnh của họ đã có thể "đốt sông nấu biển".</p>
            <p><span className="font-semibold text-yellow-300">Đột phá Kết Đan:</span> Đây là lần đầu tu sĩ đối mặt với <span className="font-semibold text-red-400">Tâm Ma Kiếp</span>. Những hối tiếc, sợ hãi trong lòng sẽ trỗi dậy quấy nhiễu tâm trí. Thất bại sẽ dẫn đến hậu quả nghiêm trọng.</p>
            <p><span className="font-semibold text-red-500">Đột phá Nguyên Anh:</span> Đây là thử thách sinh tử thực sự. Tu sĩ không chỉ đối mặt với Tâm Ma mà còn phải hứng chịu <span className="font-bold text-cyan-300">Lôi Kiếp</span> từ trời đất. Kẻ nghịch thiên sẽ bị trừng phạt. Sau khi cảm ứng được, tu sĩ sẽ có 3 tháng để chống đỡ Lôi Kiếp. Nếu thất bại, sẽ <span className="font-bold text-red-600">hình thần câu diệt</span>. Nếu thành công, mới có tư cách phá đan thành anh.</p>
        </GuideSection>
        <GuideSection title="Hóa Thần Kỳ">
            <p>Đây là cảnh giới đỉnh phong của nhân giới. Tu sĩ Hóa Thần có thể cảm ngộ và sơ bộ vận dụng một tia thiên địa pháp tắc, sức mạnh không thể tưởng tượng nổi. Tuy nhiên, thiên đạo có hạn, mỗi thế giới chỉ có thể dung chứa một số lượng Hóa Thần Kỳ nhất định.</p>
        </GuideSection>
    </div>
);

const GuidePhysiquesContent: React.FC = () => {
    const sortedPhysiques = useMemo(() => {
        const tierOrder = Object.values(PhysiqueTier);
        return Object.values(PHYSIQUES).sort((a, b) => {
             const tierIndexA = tierOrder.indexOf(a.tier);
             const tierIndexB = tierOrder.indexOf(b.tier);
             if (tierIndexA !== tierIndexB) return tierIndexB - tierIndexA;
             return a.name.localeCompare(b.name);
        });
    }, []);

    const formatModifier = (mod: number) => {
        if (mod === 1) return `Không đổi`;
        const percentage = Math.round((mod - 1) * 100);
        return `${percentage > 0 ? '+' : ''}${percentage}%`;
    };

    return (
        <div className="space-y-4">
            <GuideSection title="Tổng Quan về Thể Chất">
                <p>Thể chất là một loại thiên phú đặc biệt, bẩm sinh mà có, mang lại các hiệu ứng mạnh mẽ và ảnh hưởng sâu sắc đến con đường tu tiên của một người. Một thể chất tốt có thể giúp tu sĩ đi nhanh và xa hơn người khác rất nhiều.</p>
                <p>Thể chất được phân thành nhiều bậc, từ Phàm, Linh, Địa, Thiên, Thánh cho đến Thần Thể trong truyền thuyết. Thể chất càng cao thì hiệu quả càng mạnh mẽ.</p>
            </GuideSection>
            {sortedPhysiques.map(physique => (
                <div key={physique.name} className="p-3 bg-black/30 rounded-md">
                    <h5 className={`font-bold text-lg ${PHYSIQUE_TIER_COLORS[physique.tier]}`}>{physique.name} <span className="text-sm font-normal text-white/70">({physique.tier})</span></h5>
                    <p className="text-sm text-white/90 italic mt-1">"{physique.description}"</p>
                    <hr className="my-2 border-white/20" />
                    <h6 className="font-bold text-amber-300/90 text-sm mb-1">Hiệu Ứng Thể Chất:</h6>
                    <ul className="text-xs text-white/80 list-disc list-inside space-y-1">
                        <li>Tốc độ tu luyện: <span className="font-semibold text-green-400">{formatModifier(physique.effects.cultivationSpeedModifier)}</span></li>
                        <li>Khí Huyết: <span className="font-semibold text-red-400">{formatModifier(physique.effects.healthModifier)}</span></li>
                        <li>Linh Lực: <span className="font-semibold text-blue-400">{formatModifier(physique.effects.manaModifier)}</span></li>
                        <li>Tuổi Thọ: <span className="font-semibold text-yellow-400">{formatModifier(physique.effects.lifespanModifier)}</span></li>
                        {physique.effects.combatStatModifiers && Object.entries(physique.effects.combatStatModifiers).length > 0 && <li className="pt-1 text-amber-300/80">Chỉ số chiến đấu:</li>}
                        {physique.effects.combatStatModifiers && Object.entries(physique.effects.combatStatModifiers).map(([stat, mod]) => 
                            <li key={stat} className="pl-2">{COMBAT_STAT_TRANSLATIONS[stat] || stat}: <span className="font-semibold text-purple-400">{formatModifier(mod as number)}</span></li>
                        )}
                    </ul>
                </div>
            ))}
        </div>
    );
};


const GuideTechniquesContent: React.FC = () => (
    <div className="space-y-4">
        <GuideSection title="Tổng Quan">
            <p>Công pháp, bí thuật và pháp quyết là những phương tiện để tu sĩ vận dụng sức mạnh. Chúng có thể được học từ bí tịch trong túi đồ hoặc tham ngộ tại Tàng Kinh Các.</p>
        </GuideSection>
        <GuideSection title="Công Pháp (Cultivation Methods)">
            <p>Đây là nền tảng của mọi tu sĩ, là phương pháp cốt lõi để hấp thụ và vận hành linh khí. Mỗi tu sĩ chỉ có thể trang bị một <span className="font-semibold text-yellow-300">Công Pháp Chủ Tu</span>. Ngoài ra, họ có thể trang bị thêm 4 <span className="font-semibold text-purple-300">Công Pháp Phụ Tu</span> với hiệu quả giảm đi, giúp bổ trợ cho con đường chính.</p>
            <p>Chất lượng của Công Pháp ảnh hưởng trực tiếp đến tốc độ tu luyện và các chỉ số cơ bản. Một công pháp cao cấp có thể giúp tu sĩ đi nhanh hơn người khác rất nhiều.</p>
             <p>Mỗi công pháp có một giới hạn cảnh giới tối đa có thể tu luyện. Khi đạt đến giới hạn, tu sĩ sẽ bị kẹt bình cảnh và không thể tiến bộ nếu không thay đổi công pháp cao cấp hơn.</p>
        </GuideSection>
        <GuideSection title="Bí Thuật (Secret Arts)">
            <p>Là những kỹ năng đặc thù, thường không dùng để tấn công trực diện mà mang lại các hiệu ứng đặc biệt: phòng ngự, bỏ chạy, bùng nổ sức mạnh tạm thời, hoặc các khả năng phụ trợ khác.</p>
            <p>Sử dụng bí thuật thường phải trả một cái giá nhất định, ví dụ như tiêu hao khí huyết, linh lực, thậm chí là tuổi thọ.</p>
        </GuideSection>
         <GuideSection title="Pháp Quyết (Spells)">
            <p>Là những chiêu thức tấn công chính của tu sĩ, dùng để chiến đấu. Chúng thường tiêu tốn linh lực để tạo ra các hiệu ứng sát thương.</p>
            <p>Nhiều pháp quyết yêu cầu tu sĩ phải có linh căn thuộc tính tương ứng mới có thể tu luyện và phát huy tối đa uy lực.</p>
        </GuideSection>
        <GuideSection title="Công Pháp Nghề Nghiệp">
            <p>Đây là những bí tịch đặc thù, không dùng để chiến đấu mà để mở khóa và hỗ trợ các ngành nghề Bách Nghệ. Một số công pháp chỉ đơn giản là mở khóa nghề (ví dụ: Luyện Đan Cơ Sở), trong khi những công pháp cao cấp hơn sẽ giúp tăng tỷ lệ thành công và giảm thời gian chế tạo vật phẩm.</p>
        </GuideSection>
        <GuideSection title="Tu Luyện Độ Thành Thạo">
             <p>Bí Thuật và Pháp Quyết có thể được <span className="font-semibold text-purple-300">tu luyện độ thành thạo</span>. Khi một bí thuật/pháp quyết được chọn để tu luyện, nhân vật sẽ không thể nhận nhiệm vụ hay vào Tu Luyện Tháp. Khi độ thành thạo tăng (Nhập Môn → Tiểu Thành → Đại Thành → Viên Mãn), uy lực của kỹ năng sẽ tăng lên và lượng tiêu hao sẽ giảm xuống.</p>
        </GuideSection>
    </div>
);

const GuideProfessionsContent: React.FC = () => (
    <div className="space-y-4">
        <GuideSection title="Tổng Quan">
            <p>Ngoài việc chiến đấu, các công trình và ngành nghề phụ trợ (Bách Nghệ Tu Tiên) đóng vai trò cực kỳ quan trọng trong việc xây dựng và phát triển gia tộc.</p>
        </GuideSection>
        
        <GuideSection title="Linh Mạch - Nền Tảng Gia Tộc">
            <p><span className="font-semibold text-yellow-300">Công Năng:</span> Linh Mạch là trái tim của gia tộc, tự động sản sinh <span className="font-semibold text-cyan-300">Linh Khí</span> mỗi tháng để các tộc nhân tu luyện. Ngươi có thể phân công tộc nhân vào khai thác để thu được <span className="font-semibold text-amber-300">Linh Thạch</span>.</p>
            <p><span className="font-semibold text-yellow-300">Phát Triển:</span> Nâng cấp Linh Mạch là ưu tiên hàng đầu. Cấp bậc của nó quyết định sản lượng Linh Khí và tốc độ tu luyện cơ bản cho toàn gia tộc.</p>
        </GuideSection>

        <GuideSection title="Các Công Trình Quản Lý & Sự Vụ">
             <p><span className="font-semibold text-yellow-300">Từ Đường:</span> Nơi quản lý cấp bậc, bổng lộc, quy tắc tấn thăng, và tổ chức bầu chọn Thiếu Tộc Trưởng. Đây là trung tâm quyền lực chính trị của gia tộc.</p>
             <p><span className="font-semibold text-yellow-300">Sự Vụ Đường:</span> Nơi ban bố các nhiệm vụ. Tộc nhân sẽ tự đến đây nhận nhiệm vụ khi cần điểm cống hiến, giúp gia tộc thu về tài nguyên và vật phẩm.</p>
             <p><span className="font-semibold text-yellow-300">Huân Công Đường:</span> Cửa hàng nội bộ của gia tộc. Ngươi có thể đưa vật phẩm từ kho lên đây để bán cho tộc nhân lấy <span className="font-semibold text-cyan-400">điểm cống hiến</span>. Tộc nhân sẽ tự đến mua vật phẩm họ cần.</p>
             <p><span className="font-semibold text-yellow-300">Thăng Tiên Đài:</span> Sử dụng Linh Thạch để tìm kiếm các hài đồng có tư chất (Tiên Miêu) ở bên ngoài, giúp mở rộng và phát triển gia tộc.</p>
        </GuideSection>
        
        <GuideSection title="Các Công Trình Tu Luyện & Phát Triển">
             <p><span className="font-semibold text-yellow-300">Tàng Kinh Các:</span> Nơi lưu trữ các loại bí tịch công pháp. Tộc nhân có thể dùng <span className="font-semibold text-amber-300">Lệnh Bài Tàng Kinh Các</span> để tự vào đây học công pháp mới.</p>
             <p><span className="font-semibold text-yellow-300">Tu Luyện Tháp:</span> Một công trình đặc biệt giúp tăng tốc độ tu luyện lên rất nhiều. Tộc nhân có thể tiêu điểm cống hiến để vào đây bế quan trong một khoảng thời gian.</p>
             <p><span className="font-semibold text-yellow-300">Võ Đài:</span> Nơi để các tộc nhân tỷ thí võ nghệ, giúp tăng kinh nghiệm thực chiến và các chỉ số chiến đấu một cách an toàn.</p>
             <p><span className="font-semibold text-yellow-300">Trấn Yêu Đường:</span> Nơi tổ chức các đội săn bắn để tiêu diệt yêu thú, thu thập yêu đan, yêu cốt và các vật liệu quý giá. Nâng cấp công trình sẽ mở khóa các khu vực săn bắn cao cấp hơn và tăng số lượng vị trí trong đội.</p>
        </GuideSection>

        <GuideSection title="Các Công Trình Chuyên Môn (Bách Nghệ)">
            <p>Để một tộc nhân có thể làm nghề, họ cần học công pháp nhập môn tương ứng và được phân công vào công trình phù hợp.</p>
            {Object.values(BUILDINGS).filter(b => b.profession).map(building => {
                const profession = building.profession!;
                return (
                     <p key={building.id}><span className="font-semibold text-yellow-300">{building.name}:</span> {
                        profession === 'Luyện Đan Sư' ? 'Luyện chế các loại đan dược giúp tăng tu vi, hồi phục, hoặc hỗ trợ đột phá.' :
                        profession === 'Luyện Khí Sư' ? 'Rèn đúc các loại vũ khí, pháp bào, giáp trụ để tăng sức chiến đấu.' :
                        profession === 'Chế Phù Sư' ? 'Vẽ các loại phù lục với nhiều công năng khác nhau, sử dụng một lần.' :
                        profession === 'Linh Thực Sư' ? 'Trồng và thu hoạch các loại linh thảo, nguyên liệu không thể thiếu cho Luyện Đan Sư.' : ''
                    }</p>
                )
            })}
        </GuideSection>

        <GuideSection title="Nâng Cấp Công Trình">
             <p>Mỗi công trình có thể được nâng cấp để tăng <span className="text-yellow-300 font-semibold">Cấp (Level)</span>. Việc này sẽ dần dần cải thiện <span className="text-blue-400 font-semibold">Phẩm (Quality)</span> của công trình (từ Hạ Phẩm → Trung Phẩm → Thượng Phẩm), giúp tăng hiệu quả và các chỉ số cơ bản.</p>
            <p>Khi một công trình đạt đến cấp độ cao nhất trong Giai hiện tại, ngươi có thể tiến hành nâng cấp <span className="text-green-400 font-semibold">Giai (Tier)</span> cho nó (ví dụ: từ Nhất Giai lên Nhị Giai).</p>
            <p><span className="font-semibold text-green-400">Nâng Giai</span> là một bước tiến lớn, sẽ mở khóa các công thức chế tạo mạnh hơn, tăng đáng kể số lượng vị trí phân công, và mở ra các tính năng mới, nhưng cũng đòi hỏi lượng tài nguyên khổng lồ.</p>
        </GuideSection>
    </div>
);

const guideTopics = {
    intro: { label: 'Lời Mở Đầu', component: GuideIntroContent },
    realms: { label: 'Cảnh Giới', component: GuideRealmsContent },
    physiques: { label: 'Thể Chất', component: GuidePhysiquesContent },
    techniques: { label: 'Công Pháp & Bí Thuật', component: GuideTechniquesContent },
    professions: { label: 'Nghề Nghiệp & Công Trình', component: GuideProfessionsContent },
};

const GuideContent: React.FC = () => {
    const [activeTopic, setActiveTopic] = useState('intro');
    const ActiveComponent = guideTopics[activeTopic as keyof typeof guideTopics].component;

    return (
        <div className="flex gap-4 h-full">
            <nav className="w-1/4 flex flex-col gap-1 pr-2 overflow-y-auto scrollbar-thin scrollbar-thumb-amber-800/70 scrollbar-track-transparent">
                 {Object.entries(guideTopics).map(([key, { label }]) => (
                    <button 
                        key={key} 
                        onClick={() => setActiveTopic(key)}
                        className={`w-full text-left p-2 rounded-md font-semibold text-sm transition-all ${activeTopic === key ? 'text-amber-200 bg-black/40' : 'text-gray-400 hover:bg-black/20 hover:text-amber-300'}`}
                    >
                        {label}
                    </button>
                 ))}
            </nav>
            <main className="w-3/4 bg-black/20 rounded-lg p-3 overflow-y-auto scrollbar-thin scrollbar-thumb-amber-800/70 scrollbar-track-transparent">
                <ActiveComponent />
            </main>
        </div>
    );
};


const EncyclopediaContent: React.FC = () => {
    const encyclopediaCategories = {
        'Công Pháp & Bí Thuật': [ItemType.CULTIVATION_METHOD, ItemType.SECRET_ART, ItemType.SPELL],
        'Trang Bị & Vũ Khí': [ItemType.WEAPON, ItemType.CHESTPLATE, ItemType.HELMET, ItemType.BOOTS],
        'Phù Bảo': [ItemType.TALISMAN],
        'Trận Pháp': [ItemType.FORMATION],
        'Đan Dược': [ItemType.PILL],
        'Thiên Tài Địa Bảo': [ItemType.HERB, ItemType.MATERIAL, ItemType.SEED, ItemType.TOKEN, ItemType.RESOURCE]
    };

    const categorizedItems = useMemo(() => {
        const result: Record<string, Record<string, AnyItem[]>> = {};
        for (const [categoryName, itemTypes] of Object.entries(encyclopediaCategories)) {
            const itemsInCategory = Object.values(ALL_ITEMS).filter(item => item && itemTypes.includes(item.type));
            
            const groupedByTier = itemsInCategory.reduce((acc, item) => {
                const tier = item.quality;
                if (!acc[tier]) acc[tier] = [];
                acc[tier]!.push(item);
                return acc;
            }, {} as Record<string, AnyItem[]>);

            result[categoryName] = groupedByTier;
        }
        return result;
    }, []);

    const categoryOrder = Object.keys(encyclopediaCategories);
    const [activeCategory, setActiveCategory] = useState(categoryOrder[0] || '');

    const getSortableName = (item: any): string => {
        if (item && item.name) return item.name;
        if (item && item.stage) return item.stage;
        return '';
    };

    const renderItem = (item: AnyItem) => (
        <ItemTooltip key={item.id} item={item}>
            <div className="p-2 bg-stone-900/70 rounded-md border border-white/10">
                <p className={`font-semibold truncate ${ITEM_QUALITY_COLORS[item.quality] || 'text-white'}`}>
                    {item.name}
                </p>
            </div>
        </ItemTooltip>
    );

    const renderContent = () => {
        const categoryData = categorizedItems[activeCategory];
        if (!categoryData) return <p className="text-gray-400 italic text-center">Không có dữ liệu.</p>;

        const tierOrder = Object.values(ItemQuality);

        return tierOrder.map(tier => {
            const itemsInTier = categoryData[tier];
            if (!itemsInTier || itemsInTier.length === 0) return null;

            return (
                <div key={tier}>
                    <h4 className="text-lg font-bold text-amber-300 mt-4 mb-2 pl-1">{tier} ({itemsInTier.length})</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                       {itemsInTier.sort((a,b) => getSortableName(a).localeCompare(getSortableName(b))).map(renderItem)}
                    </div>
                </div>
            );
        });
    };

    return (
        <div className="flex gap-4 h-full">
            <nav className="w-1/4 flex flex-col gap-1 pr-2 overflow-y-auto scrollbar-thin scrollbar-thumb-amber-800/70 scrollbar-track-transparent">
                {categoryOrder.map(cat => (
                    <button 
                        key={cat} 
                        onClick={() => setActiveCategory(cat)}
                        className={`w-full text-left p-2 rounded-md font-semibold text-sm transition-all ${activeCategory === cat ? 'text-amber-200 bg-black/40' : 'text-gray-400 hover:bg-black/20 hover:text-amber-300'}`}
                    >
                        {cat}
                    </button>
                ))}
            </nav>
            <main className="w-3/4 bg-black/20 rounded-lg p-3 overflow-y-auto scrollbar-thin scrollbar-thumb-amber-800/70 scrollbar-track-transparent">
                {renderContent()}
            </main>
        </div>
    );
};


const SecretRecordsModal: React.FC<SecretRecordsModalProps> = ({ isOpen, onClose }) => {
    const [activeTab, setActiveTab] = useState<'guide' | 'encyclopedia'>('guide');

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div 
                className="relative w-full max-w-7xl h-[90vh] bg-gradient-to-b from-[var(--color-wood-dark)] to-[#2a201c] rounded-2xl p-2 flex flex-col" 
                onClick={(e) => e.stopPropagation()} 
                style={{ boxShadow: '0 0 0 3px #1d1d1d, 0 0 0 7px var(--color-wood-medium), 0 25px 60px 15px rgba(0,0,0,0.8)' }}
            >
                <div className="bg-gradient-to-t from-stone-800/80 to-stone-900/90 rounded-lg p-6 border-2 border-amber-400/20 relative flex flex-col flex-grow min-h-0">
                    <button onClick={onClose} className="absolute top-4 right-4 text-white bg-black/50 p-1 rounded-full hover:bg-[var(--color-text-accent)] transition-colors z-20" aria-label="Đóng"><CloseIcon /></button>
                    
                    <div className="flex items-center gap-4 border-b-2 border-amber-400/20 pb-4 mb-4 flex-shrink-0">
                        <SecretRecordsIcon className="w-12 h-12 text-amber-300" />
                        <h2 className="text-4xl font-bold text-[var(--color-gold-light)]" style={{ fontFamily: "'Noto Serif SC', serif" }}>Trường Thanh Bí Lục</h2>
                    </div>
                    
                    <div className="flex border-b border-amber-300/20 mb-4 flex-shrink-0">
                        <TabButton label="Cơ Chế Hướng Dẫn" isActive={activeTab === 'guide'} onClick={() => setActiveTab('guide')} />
                        <TabButton label="Vạn Vật Đồ Giám" isActive={activeTab === 'encyclopedia'} onClick={() => setActiveTab('encyclopedia')} />
                    </div>

                    <div className="flex-grow min-h-0">
                         {activeTab === 'guide' ? <GuideContent /> : <EncyclopediaContent />}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SecretRecordsModal;
