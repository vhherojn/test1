


import React from 'react';
import type { Location, LocationData } from '../types/index.ts';
import { CloseIcon, ScrollIcon, FamilyIcon, ResourceIcon, SpiritVeinIcon } from './Icons.tsx';

interface LocationModalProps {
  location: Location;
  onClose: () => void;
  data: LocationData | null | undefined;
  isLoading: boolean;
  error: string | null;
  clanName?: string;
}

const LoadingSpinner: React.FC = () => (
    <div className="flex flex-col items-center justify-center h-full text-[var(--color-text-main)]">
        <svg className="animate-spin h-12 w-12 text-[var(--color-text-accent)]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <p className="mt-4 text-lg font-semibold">Đang phân tích địa thế, dò xét thiên cơ...</p>
    </div>
);

const ScrollEnd: React.FC<{className?: string}> = ({className}) => (
    <div className={`absolute left-0 w-full h-8 bg-gradient-to-b from-[#6b5b4c] to-[#3c3836] ${className}`}
        style={{
            boxShadow: '0 4px 8px rgba(0,0,0,0.5), inset 0 2px 2px rgba(255,255,255,0.2)'
        }}
    >
        <div className="absolute inset-0 bg-repeat-x opacity-10" style={{backgroundImage: 'url(https://www.transparenttextures.com/patterns/wood-pattern.png)'}}></div>
    </div>
);

const LocationModal: React.FC<LocationModalProps> = ({ location, onClose, data, isLoading, error, clanName }) => {
  const isAncestral = location.isAncestral;
  const title = isAncestral && clanName ? `${clanName} Tổ Địa` : location.name;
  const descriptionTitle = isAncestral && clanName ? `${clanName} Ký` : "Lãnh Địa Ký";


  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div 
        className="relative w-full max-w-2xl h-auto max-h-[90vh] bg-gradient-to-b from-[var(--color-paper-light)] to-[var(--color-paper-dark)] rounded-lg flex flex-col pt-12 pb-12"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-labelledby="location-modal-title"
        aria-modal="true"
        style={{
          boxShadow: '0 0 0 5px var(--color-wood-medium), 0 0 0 8px var(--color-wood-dark), 0 15px 50px 10px rgba(0,0,0,0.7)',
          filter: 'drop-shadow(0 0 15px black)',
        }}
      >
        <ScrollEnd className="-top-4 rounded-t-full" />

        <button onClick={onClose} className="absolute top-4 right-4 text-white bg-black/50 p-1 rounded-full hover:bg-[var(--color-text-accent)] transition-colors z-20" aria-label="Đóng">
            <CloseIcon />
        </button>

        <div className="w-full text-center mb-4 px-6">
           <h2 id="location-modal-title" className="text-4xl font-bold text-[var(--color-text-main)]" style={{fontFamily: "'Noto Serif SC', serif", textShadow: '1px 1px 2px rgba(0,0,0,0.2)'}}>{title}</h2>
        </div>

        <div className="w-full flex-grow overflow-y-auto px-6 scrollbar-thin scrollbar-thumb-amber-800/70 scrollbar-track-transparent">
          {isLoading && <LoadingSpinner />}
          {error && !isLoading && <div className="text-center text-red-700 font-bold">{error}</div>}
          {data && !isLoading && !error && (
            <div className="space-y-4 text-[var(--color-text-main)]">
              <div>
                <h3 className="text-xl font-bold mb-3 flex items-center gap-2 text-[var(--color-text-accent)]"><ScrollIcon /> {descriptionTitle}</h3>
                <p className="text-base leading-relaxed whitespace-pre-wrap p-4 bg-black/5 rounded-md border border-black/10 shadow-inner">{data.description}</p>
              </div>
              <div className="decorative-line"></div>
               <div>
                  <h3 className="text-xl font-bold mb-3 flex items-center gap-2 text-[var(--color-text-accent)]"><SpiritVeinIcon /> {isAncestral ? "Tổ Địa Linh Mạch & Tài Sản" : "Linh Khí & Tài Nguyên"}</h3>
                   <div className="p-3 bg-gradient-to-br from-green-100 to-green-200 text-green-900 rounded-md border-2 border-green-300 mb-4 shadow-md">
                    <strong className="font-semibold">Phẩm chất Linh Khí:</strong> {data.linh_khi}
                  </div>
                  <ul className="list-none space-y-2">
                      {data.tai_nguyen.map((resource, index) => (
                      <li key={index} className="flex items-center gap-2 p-3 bg-gradient-to-br from-yellow-50 to-amber-100 text-amber-900 rounded-md border-2 border-amber-200 shadow-md"><ResourceIcon /> {resource}</li>
                      ))}
                  </ul>
              </div>
              <div className="decorative-line"></div>
              <div>
                  <h3 className="text-xl font-bold mb-3 flex items-center gap-2 text-[var(--color-text-accent)]"><FamilyIcon /> {isAncestral ? "Thành Viên Sáng Lập" : "Các Gia Tộc Ảnh Hưởng"}</h3>
                  <ul className="list-none space-y-2">
                      {data.gia_toc_anh_huong.map((figure, index) => (
                      <li key={index} className="p-3 bg-gradient-to-br from-stone-100 to-stone-200 text-stone-800 rounded-md border-2 border-stone-300 shadow-md">{figure}</li>
                      ))}
                  </ul>
              </div>
            </div>
          )}
        </div>
        
        <ScrollEnd className="-bottom-4 rounded-b-full" />
      </div>
    </div>
  );
};

export default React.memo(LocationModal);
