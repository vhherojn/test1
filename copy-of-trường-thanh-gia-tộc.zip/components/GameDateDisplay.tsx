


import React from 'react';
import type { GameDate } from '../types/index.ts';

interface GameDateDisplayProps {
  date: GameDate;
}

const GameDateDisplay: React.FC<GameDateDisplayProps> = ({ date }) => {
  return (
    <div className="absolute top-4 right-4 z-10 flex flex-col items-center"
      style={{
        filter: 'drop-shadow(0 5px 8px rgba(0,0,0,0.4))'
      }}
    >
      <div 
        className="bg-gradient-to-b from-[#6b5b4c] to-[#3c3836] text-[var(--color-gold-light)] px-5 py-2 border-2 border-[#282828] shadow-lg rounded-t-lg"
        style={{
          boxShadow: 'inset 0 1px 1px rgba(255,255,255,0.2), 0 2px 3px rgba(0,0,0,0.4)'
        }}
      >
        <div className="text-center">
          <span className="font-bold text-xl tracking-wider" style={{fontFamily: "'Noto Serif SC', serif", textShadow: '1px 1px 2px #000'}}>Năm {date.year}</span>
        </div>
      </div>
      <div
        className="w-0 h-0 border-l-[65px] border-l-transparent border-r-[65px] border-r-transparent border-t-[20px] border-t-[#3c3836]"
      ></div>
       <div 
        className="absolute bottom-[-18px] bg-gradient-to-b from-[var(--color-jade)] to-[var(--color-jade-dark)] text-white px-4 py-1 rounded-full text-center shadow-lg border-2 border-black/30"
        style={{
          boxShadow: 'inset 0 1px 1px rgba(255,255,255,0.4), 0 2px 3px rgba(0,0,0,0.4)'
        }}
      >
        <span className="font-semibold text-sm drop-shadow-sm" style={{textShadow: '1px 1px 1px #000'}}>Tháng {date.month}</span>
      </div>
    </div>
  );
};

export default React.memo(GameDateDisplay);
