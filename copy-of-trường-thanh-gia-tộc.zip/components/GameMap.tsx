
import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { Location, Force } from '../types/index.ts';
import { PalaceIcon, MountainsIcon, CityIcon, ForestIcon, RuinsIcon, RighteousForceIcon, EvilForceIcon } from './Icons.tsx';
import { GAME_MAP_BACKGROUND_BASE64 } from './GameMap.constants.ts';

interface GameMapProps {
  locations: Location[];
  forces: Force[];
  onSelectLocation: (location: Location) => void;
  onSelectForce: (force: Force) => void;
}

const PREFAB_LOCATION_ICONS: { [key: string]: React.FC<{className?: string}> } = {
    palace: PalaceIcon,
    mountains: MountainsIcon,
    city: CityIcon,
    forest: ForestIcon,
    ruins: RuinsIcon,
};

const PREFAB_FORCE_ICONS: { [key: string]: React.FC<{className?: string}> } = {
    righteous: RighteousForceIcon,
    evil: EvilForceIcon
};

const Scenery: React.FC = React.memo(() => (
    <img
        src={GAME_MAP_BACKGROUND_BASE64}
        alt="Game World Map"
        width={1920}
        height={1080}
        className="absolute top-0 left-0"
        aria-hidden="true"
        style={{ pointerEvents: 'none' }}
    />
));


const Hotspot: React.FC<{ location: Location; onSelect: (location: Location) => void }> = ({ location, onSelect }) => {
  const isAncestral = location.isAncestral;
  const IconComponent = PREFAB_LOCATION_ICONS[location.prefab || 'city'];

  return (
    <div
      className="absolute group flex flex-col items-center transform -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10"
      style={{ top: `${location.y}%`, left: `${location.x}%` }}
      onClick={(e) => { e.stopPropagation(); onSelect(location); }}
      role="button"
      aria-label={`Mở thông tin cho ${location.name}`}
    >
      <div className="w-16 h-16 p-1 bg-gradient-to-br from-[#fbf1c7] to-[#d5c4a1] rounded-full border-2 border-transparent flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-hover:shadow-2xl group-hover:border-yellow-300"
        style={{
          boxShadow: '0 8px 15px rgba(0,0,0,0.3), inset 0 2px 2px rgba(255,255,255,0.5)',
          backgroundClip: 'padding-box',
          borderColor: '#66503c'
        }}
      >
          <IconComponent className="w-10 h-10 text-[var(--color-wood-dark)] drop-shadow-lg transition-transform duration-300 group-hover:scale-105" />
      </div>
      <div 
        className="mt-2 text-sm text-center font-bold text-white px-3 py-1 rounded-md bg-black/60 backdrop-blur-sm transition-all duration-300 group-hover:bg-black/80" 
        style={{
            fontFamily: "'Noto Serif SC', serif",
            textShadow: '1px 1px 3px black',
            boxShadow: '0 2px 4px rgba(0,0,0,0.5)'
        }}
      >
        {location.name}
      </div>
      {isAncestral && (
        <div 
          className="mt-1 text-xs text-center font-semibold text-yellow-300 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-sm"
          style={{
              fontFamily: "'Noto Serif SC', serif",
              textShadow: '1px 1px 3px black',
              boxShadow: '0 2px 4px rgba(0,0,0,0.5)'
          }}
        >
          Gia Tộc Tổ Địa
        </div>
      )}
    </div>
  );
};

const ForceHotspot: React.FC<{ force: Force; onSelect: (force: Force) => void }> = ({ force, onSelect }) => {
  const IconComponent = PREFAB_FORCE_ICONS[force.icon];

  return (
    <div
      className="absolute group flex flex-col items-center transform -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10"
      style={{ top: `${force.y}%`, left: `${force.x}%` }}
      onClick={(e) => { e.stopPropagation(); onSelect(force); }}
      role="button"
      aria-label={`Mở thông tin cho ${force.name}`}
    >
      <div className="w-12 h-14 bg-gradient-to-br from-stone-600 to-stone-800 rounded-b-lg border-2 border-transparent flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-hover:shadow-2xl group-hover:border-amber-400"
        style={{
          boxShadow: '0 8px 15px rgba(0,0,0,0.3), inset 0 2px 2px rgba(255,255,255,0.1)',
          borderTop: '5px solid #4a423b',
          clipPath: 'polygon(0 0, 100% 0, 100% 100%, 50% 90%, 0 100%)',
          borderColor: '#4a423b'
        }}
      >
          <IconComponent className="w-8 h-8 text-[var(--color-paper-main)] drop-shadow-lg transition-transform duration-300 group-hover:scale-105" />
      </div>
      <div 
        className="mt-2 text-sm text-center font-bold text-white px-3 py-1 rounded-md bg-black/60 backdrop-blur-sm transition-all duration-300 group-hover:bg-black/80" 
        style={{
            fontFamily: "'Noto Serif SC', serif",
            textShadow: '1px 1px 3px black',
            boxShadow: '0 2px 4px rgba(0,0,0,0.5)'
        }}
      >
        {force.name}
      </div>
    </div>
  );
};

const MAP_WIDTH = 1920;
const MAP_HEIGHT = 1080;

const GameMap: React.FC<GameMapProps> = ({ locations, forces, onSelectLocation, onSelectForce }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [viewportSize, setViewportSize] = useState({ width: 0, height: 0 });
  const pressedKeys = useRef(new Set<string>());
  const zoom = 1; // Zoom is now fixed

  const clampPosition = useCallback((pos: {x: number, y: number}) => {
    const { width: vw, height: vh } = viewportSize;
    if (vw === 0 || vh === 0) return pos;

    const minX = Math.min(0, vw - MAP_WIDTH);
    const maxX = 0;
    const minY = Math.min(0, vh - MAP_HEIGHT);
    const maxY = 0;
    
    return {
        x: vw >= MAP_WIDTH ? (vw - MAP_WIDTH) / 2 : Math.max(minX, Math.min(maxX, pos.x)),
        y: vh >= MAP_HEIGHT ? (vh - MAP_HEIGHT) / 2 : Math.max(minY, Math.min(maxY, pos.y)),
    };
  }, [viewportSize]);


  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    const startPos = { x: e.clientX, y: e.clientY };
    const startPosition = { ...position };

    const handleMouseMove = (moveEvent: MouseEvent) => {
        const dx = moveEvent.clientX - startPos.x;
        const dy = moveEvent.clientY - startPos.y;
        setPosition(clampPosition({ x: startPosition.x + dx, y: startPosition.y + dy }));
    };

    const handleMouseUp = () => {
        setIsDragging(false);
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  }, [position, clampPosition]);

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault(); // Disable scroll-to-zoom
  };

  // Set up viewport size observer
  useEffect(() => {
    const mapEl = mapRef.current;
    if (mapEl) {
        const resizeObserver = new ResizeObserver(entries => {
            for (const entry of entries) {
                const { width, height } = entry.contentRect;
                setViewportSize({ width, height });
            }
        });
        resizeObserver.observe(mapEl);
        return () => resizeObserver.disconnect();
    }
  }, []);

  // Set initial position based on viewport
  useEffect(() => {
      setPosition(pos => clampPosition(pos));
  }, [viewportSize, clampPosition]);

  // Smooth keyboard movement loop
  useEffect(() => {
    let animationFrameId: number;
    const moveLoop = () => {
        setPosition(prev => {
            if (pressedKeys.current.size === 0) return prev;
            
            const moveSpeed = 15;
            let newX = prev.x;
            let newY = prev.y;

            if (pressedKeys.current.has('w')) newY += moveSpeed;
            if (pressedKeys.current.has('s')) newY -= moveSpeed;
            if (pressedKeys.current.has('a')) newX += moveSpeed;
            if (pressedKeys.current.has('d')) newX -= moveSpeed;

            if (newX === prev.x && newY === prev.y) return prev;
            
            return clampPosition({ x: newX, y: newY });
        });
        animationFrameId = requestAnimationFrame(moveLoop);
    };
    
    moveLoop();

    const handleKeyDown = (e: KeyboardEvent) => {
        const key = e.key.toLowerCase();
        if (['w', 'a', 's', 'd'].includes(key)) {
            e.preventDefault();
            pressedKeys.current.add(key);
        }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
        pressedKeys.current.delete(e.key.toLowerCase());
    };

    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('keyup', handleKeyUp);
    
    return () => {
        cancelAnimationFrame(animationFrameId);
        document.removeEventListener('keydown', handleKeyDown);
        document.removeEventListener('keyup', handleKeyUp);
    };
  }, [clampPosition]);
  
  const mapStyle: React.CSSProperties = {
      backgroundColor: 'var(--color-paper-main)',
  };

  return (
    <div 
      ref={mapRef}
      className={`w-full h-full overflow-hidden ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
      style={mapStyle}
      onMouseDown={handleMouseDown}
      onWheel={handleWheel}
      tabIndex={0} // Make div focusable for keyboard events
    >
      <div 
        className="relative"
        style={{ 
          width: `${MAP_WIDTH}px`,
          height: `${MAP_HEIGHT}px`,
          transform: `translate(${position.x}px, ${position.y}px) scale(${zoom})`,
          transition: isDragging ? 'none' : 'transform 0.1s linear',
        }}
      >
        <Scenery />
        {locations.map((loc) => (
          <Hotspot key={loc.id} location={loc} onSelect={onSelectLocation} />
        ))}
        {forces.map((force) => (
            <ForceHotspot key={force.id} force={force} onSelect={onSelectForce} />
        ))}
      </div>
    </div>
  );
};

export default React.memo(GameMap);
