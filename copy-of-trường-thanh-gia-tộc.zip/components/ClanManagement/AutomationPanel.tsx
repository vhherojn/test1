import React from 'react';

// This component is now obsolete due to the new crafting station system.
// It is kept as an empty shell to prevent import errors but should be removed in the future.
const AutomationPanel: React.FC = () => {
    return null;
};

export default AutomationPanel;